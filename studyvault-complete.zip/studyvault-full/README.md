# 📚 StudyVault — College Knowledge Repository

A full-stack student platform for Indian colleges.  
Browse study resources, watch recorded lectures, and take subject tests — all in one place.

---

## 🗂 Project Structure

```
studyvault/
├── index.html              # Single-page app shell
├── css/
│   └── styles.css          # All styling
├── js/
│   └── main.js             # All frontend logic
├── server/
│   └── server.js           # Express + MongoDB API
├── package.json
├── .env                    # ← create this locally (see below)
└── .gitignore
```

---

## ✨ Features

| Feature | Description |
|---|---|
| 🏛 **675+ Colleges** | All IITs, NITs, IIMs, AIIMS, NLUs + global universities |
| 📂 **Resources** | Upload, search & filter notes, past papers, slides |
| 🎬 **Recorded Classes** | Real YouTube lectures (MIT, 3Blue1Brown, Khan Academy…) per college & subject |
| 📝 **Tests & Quizzes** | MCQ tests with live timer, instant grades, answer explanations |
| 🔐 **Auth** | Email/password + 8 social providers (Google, GitHub, Apple…) + Phone OTP |
| 💾 **PDF Download** | Client-side PDF generation for any resource |
| 👤 **Profile** | Edit details, view uploads & saved items |
| 🛠 **Admin** | Manage resources, view platform stats |

---

## 🚀 Getting Started

### 1. Clone & Install

```bash
git clone https://github.com/YOUR_USERNAME/studyvault.git
cd studyvault
npm install
```

### 2. Set up `.env`

Create a `.env` file in the project root:

```env
MONGO_URI=mongodb://127.0.0.1:27017/studyvault
PORT=5000
```

> For cloud MongoDB use your **MongoDB Atlas** connection string instead.

### 3. Run

```bash
# Production
npm start

# Development (auto-restart)
npm run dev
```

Open **http://localhost:5000**

---

## 🔌 API Endpoints

### Auth
| Method | Route | Description |
|---|---|---|
| POST | `/api/signup` | Register with email & password |
| POST | `/api/login` | Login with email & password |
| POST | `/api/social-login` | Social provider login / register |
| PUT | `/api/profile` | Update profile (auth required) |

### Resources
| Method | Route | Description |
|---|---|---|
| GET | `/api/resources` | List all (supports `?college=&subject=&type=&search=`) |
| GET | `/api/resources/:id` | Get single resource |
| POST | `/api/resources` | Upload resource (auth required) |
| DELETE | `/api/resources/:id` | Delete resource (author only) |
| POST | `/api/resources/:id/download` | Increment download counter |

### Saved Items
| Method | Route | Description |
|---|---|---|
| GET | `/api/saved` | Get my saved resources (auth required) |
| POST | `/api/saved/:resourceId` | Toggle save/unsave (auth required) |

### Tests
| Method | Route | Description |
|---|---|---|
| POST | `/api/test-results` | Save a test result (auth required) |
| GET | `/api/test-results` | Get my test history (auth required) |
| GET | `/api/test-results/:testId/best` | Get best score for a test |

### Admin
| Method | Route | Description |
|---|---|---|
| GET | `/api/admin/stats` | Platform stats (resources, users, downloads) |
| GET | `/api/admin/users` | List all users |

---

## 🛠 Tech Stack

**Frontend**
- HTML5 + CSS3 + Vanilla JavaScript (no framework)
- YouTube IFrame API for embedded lectures
- jsPDF for client-side PDF generation
- Google Fonts (Playfair Display, DM Mono, Fraunces)

**Backend**
- Node.js + Express
- MongoDB + Mongoose
- bcrypt for password hashing
- dotenv for environment config

---

## ☁️ Deploy to Production

### Render / Railway / Fly.io
1. Push to GitHub
2. Connect repo in dashboard
3. Set environment variable: `MONGO_URI=<your Atlas URI>`
4. Build command: `npm install`
5. Start command: `npm start`

### GitHub Pages (frontend only)
If you only want the static frontend:
- Go to **Settings → Pages → Source: main branch**
- The app works fully client-side (sessionStorage) without the backend

---

## 📝 Notes

- Authentication uses a simple `x-user-id` header for demo purposes — replace with **JWT** for production
- Social login is simulated on the frontend — integrate real OAuth providers for production
- Files are stored as metadata only — integrate **Cloudinary / AWS S3** for real file uploads

---

## 📄 License

MIT — free to use, modify and distribute.
