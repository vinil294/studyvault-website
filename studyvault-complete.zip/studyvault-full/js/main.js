// ═══════════════════════════════════════════
//  BACKEND — In-Memory Data Store
//  (persisted to sessionStorage so refreshing
//  within a tab keeps data intact)
// ═══════════════════════════════════════════

const DB_KEY = 'studyvault_db';

// ═══════════════════════════════════════════════════════════
//  WORLDWIDE COLLEGE DIRECTORY
//  India (IITs, NITs, IIMs, Central, State, Deemed) +
//  USA, UK, Australia, Canada, Europe, Asia, Middle East
// ═══════════════════════════════════════════════════════════
const COLLEGES = [
  // ── INDIA: IITs ──
  {name:'IIT Bombay',city:'Mumbai',country:'India',region:'India'},
  {name:'IIT Delhi',city:'New Delhi',country:'India',region:'India'},
  {name:'IIT Madras',city:'Chennai',country:'India',region:'India'},
  {name:'IIT Kharagpur',city:'Kharagpur',country:'India',region:'India'},
  {name:'IIT Kanpur',city:'Kanpur',country:'India',region:'India'},
  {name:'IIT Roorkee',city:'Roorkee',country:'India',region:'India'},
  {name:'IIT Guwahati',city:'Guwahati',country:'India',region:'India'},
  {name:'IIT Hyderabad',city:'Hyderabad',country:'India',region:'India'},
  {name:'IIT Gandhinagar',city:'Gandhinagar',country:'India',region:'India'},
  {name:'IIT Jodhpur',city:'Jodhpur',country:'India',region:'India'},
  {name:'IIT Patna',city:'Patna',country:'India',region:'India'},
  {name:'IIT Bhubaneswar',city:'Bhubaneswar',country:'India',region:'India'},
  {name:'IIT Indore',city:'Indore',country:'India',region:'India'},
  {name:'IIT Mandi',city:'Mandi',country:'India',region:'India'},
  {name:'IIT Varanasi (BHU)',city:'Varanasi',country:'India',region:'India'},
  {name:'IIT Tirupati',city:'Tirupati',country:'India',region:'India'},
  {name:'IIT Palakkad',city:'Palakkad',country:'India',region:'India'},
  {name:'IIT Dharwad',city:'Dharwad',country:'India',region:'India'},
  {name:'IIT Bhilai',city:'Bhilai',country:'India',region:'India'},
  {name:'IIT Jammu',city:'Jammu',country:'India',region:'India'},
  {name:'IIT Goa',city:'Panaji',country:'India',region:'India'},
  // ── INDIA: NITs ──
  {name:'NIT Trichy',city:'Tiruchirappalli',country:'India',region:'India'},
  {name:'NIT Surathkal',city:'Mangalore',country:'India',region:'India'},
  {name:'NIT Warangal',city:'Warangal',country:'India',region:'India'},
  {name:'NIT Calicut',city:'Kozhikode',country:'India',region:'India'},
  {name:'NIT Rourkela',city:'Rourkela',country:'India',region:'India'},
  {name:'NIT Durgapur',city:'Durgapur',country:'India',region:'India'},
  {name:'NIT Allahabad',city:'Prayagraj',country:'India',region:'India'},
  {name:'NIT Kurukshetra',city:'Kurukshetra',country:'India',region:'India'},
  {name:'NIT Surat',city:'Surat',country:'India',region:'India'},
  {name:'NIT Jaipur',city:'Jaipur',country:'India',region:'India'},
  {name:'NIT Hamirpur',city:'Hamirpur',country:'India',region:'India'},
  {name:'NIT Jalandhar',city:'Jalandhar',country:'India',region:'India'},
  {name:'NIT Sikkim',city:'Ravangla',country:'India',region:'India'},
  {name:'NIT Nagaland',city:'Dimapur',country:'India',region:'India'},
  // ── INDIA: IIMs ──
  {name:'IIM Ahmedabad',city:'Ahmedabad',country:'India',region:'India'},
  {name:'IIM Bangalore',city:'Bangalore',country:'India',region:'India'},
  {name:'IIM Calcutta',city:'Kolkata',country:'India',region:'India'},
  {name:'IIM Lucknow',city:'Lucknow',country:'India',region:'India'},
  {name:'IIM Kozhikode',city:'Kozhikode',country:'India',region:'India'},
  {name:'IIM Indore',city:'Indore',country:'India',region:'India'},
  {name:'IIM Shillong',city:'Shillong',country:'India',region:'India'},
  {name:'IIM Udaipur',city:'Udaipur',country:'India',region:'India'},
  {name:'IIM Ranchi',city:'Ranchi',country:'India',region:'India'},
  {name:'IIM Rohtak',city:'Rohtak',country:'India',region:'India'},
  {name:'IIM Trichy',city:'Tiruchirappalli',country:'India',region:'India'},
  {name:'IIM Nagpur',city:'Nagpur',country:'India',region:'India'},
  {name:'IIM Amritsar',city:'Amritsar',country:'India',region:'India'},
  {name:'IIM Sirmaur',city:'Sirmaur',country:'India',region:'India'},
  {name:'IIM Jammu',city:'Jammu',country:'India',region:'India'},
  {name:'IIM Visakhapatnam',city:'Visakhapatnam',country:'India',region:'India'},
  {name:'IIM Bodhgaya',city:'Bodhgaya',country:'India',region:'India'},
  {name:'IIM Sambalpur',city:'Sambalpur',country:'India',region:'India'},
  // ── INDIA: Central Universities ──
  {name:'Delhi University',city:'New Delhi',country:'India',region:'India'},
  {name:'Jawaharlal Nehru University',city:'New Delhi',country:'India',region:'India'},
  {name:'Banaras Hindu University',city:'Varanasi',country:'India',region:'India'},
  {name:'Aligarh Muslim University',city:'Aligarh',country:'India',region:'India'},
  {name:'Hyderabad Central University',city:'Hyderabad',country:'India',region:'India'},
  {name:'Pondicherry University',city:'Pondicherry',country:'India',region:'India'},
  {name:'Jamia Millia Islamia',city:'New Delhi',country:'India',region:'India'},
  {name:'Tezpur University',city:'Tezpur',country:'India',region:'India'},
  {name:'North Eastern Hill University',city:'Shillong',country:'India',region:'India'},
  {name:'Mizoram University',city:'Aizawl',country:'India',region:'India'},
  {name:'Manipur University',city:'Imphal',country:'India',region:'India'},
  {name:'Nagaland University',city:'Lumami',country:'India',region:'India'},
  {name:'Tripura University',city:'Agartala',country:'India',region:'India'},
  {name:'Assam University',city:'Silchar',country:'India',region:'India'},
  // ── INDIA: Medical ──
  {name:'AIIMS Delhi',city:'New Delhi',country:'India',region:'India'},
  {name:'AIIMS Bhopal',city:'Bhopal',country:'India',region:'India'},
  {name:'AIIMS Bhubaneswar',city:'Bhubaneswar',country:'India',region:'India'},
  {name:'AIIMS Jodhpur',city:'Jodhpur',country:'India',region:'India'},
  {name:'AIIMS Patna',city:'Patna',country:'India',region:'India'},
  {name:'AIIMS Raipur',city:'Raipur',country:'India',region:'India'},
  {name:'AIIMS Rishikesh',city:'Rishikesh',country:'India',region:'India'},
  {name:'Maulana Azad Medical College',city:'New Delhi',country:'India',region:'India'},
  {name:'Grant Medical College',city:'Mumbai',country:'India',region:'India'},
  {name:'Madras Medical College',city:'Chennai',country:'India',region:'India'},
  {name:'Kasturba Medical College',city:'Manipal',country:'India',region:'India'},
  {name:'Christian Medical College Vellore',city:'Vellore',country:'India',region:'India'},
  {name:'Armed Forces Medical College',city:'Pune',country:'India',region:'India'},
  // ── INDIA: Law ──
  {name:'NLU Delhi',city:'New Delhi',country:'India',region:'India'},
  {name:'NALSAR Hyderabad',city:'Hyderabad',country:'India',region:'India'},
  {name:'NLSIU Bangalore',city:'Bangalore',country:'India',region:'India'},
  {name:'NLU Jodhpur',city:'Jodhpur',country:'India',region:'India'},
  {name:'WBNUJS Kolkata',city:'Kolkata',country:'India',region:'India'},
  {name:'NLU Lucknow',city:'Lucknow',country:'India',region:'India'},
  {name:'GNLU Gandhinagar',city:'Gandhinagar',country:'India',region:'India'},
  {name:'RMLNLU Lucknow',city:'Lucknow',country:'India',region:'India'},
  {name:'RGNUL Patiala',city:'Patiala',country:'India',region:'India'},
  // ── INDIA: State & Deemed ──
  {name:'Mumbai University',city:'Mumbai',country:'India',region:'India'},
  {name:'Calcutta University',city:'Kolkata',country:'India',region:'India'},
  {name:'Madras University',city:'Chennai',country:'India',region:'India'},
  {name:'Pune University',city:'Pune',country:'India',region:'India'},
  {name:'Osmania University',city:'Hyderabad',country:'India',region:'India'},
  {name:'Anna University',city:'Chennai',country:'India',region:'India'},
  {name:'Jadavpur University',city:'Kolkata',country:'India',region:'India'},
  {name:'VIT Vellore',city:'Vellore',country:'India',region:'India'},
  {name:'Manipal University',city:'Manipal',country:'India',region:'India'},
  {name:'Amrita University',city:'Coimbatore',country:'India',region:'India'},
  {name:'SRM University',city:'Chennai',country:'India',region:'India'},
  {name:'Symbiosis International University',city:'Pune',country:'India',region:'India'},
  {name:'BITS Pilani',city:'Pilani',country:'India',region:'India'},
  {name:'BITS Hyderabad',city:'Hyderabad',country:'India',region:'India'},
  {name:'BITS Goa',city:'Panaji',country:'India',region:'India'},
  {name:'IIIT Hyderabad',city:'Hyderabad',country:'India',region:'India'},
  {name:'IIIT Bangalore',city:'Bangalore',country:'India',region:'India'},
  {name:'IIIT Allahabad',city:'Prayagraj',country:'India',region:'India'},
  {name:'ISI Kolkata',city:'Kolkata',country:'India',region:'India'},
  {name:'ISB Hyderabad',city:'Hyderabad',country:'India',region:'India'},
  {name:'XLRI Jamshedpur',city:'Jamshedpur',country:'India',region:'India'},
  {name:'TISS Mumbai',city:'Mumbai',country:'India',region:'India'},
  {name:'Lal Bahadur Shastri Institute of Management',city:'New Delhi',country:'India',region:'India'},
  {name:'IMI New Delhi',city:'New Delhi',country:'India',region:'India'},
  {name:'IIFT New Delhi',city:'New Delhi',country:'India',region:'India'},
  {name:'Nirma University',city:'Ahmedabad',country:'India',region:'India'},
  {name:'Christ University',city:'Bangalore',country:'India',region:'India'},
  {name:'Loyola College',city:'Chennai',country:'India',region:'India'},
  {name:'St. Stephen\'s College',city:'New Delhi',country:'India',region:'India'},
  {name:'Miranda House',city:'New Delhi',country:'India',region:'India'},
  {name:'Lady Shri Ram College',city:'New Delhi',country:'India',region:'India'},
  {name:'Hindu College',city:'New Delhi',country:'India',region:'India'},
  {name:'Hansraj College',city:'New Delhi',country:'India',region:'India'},
  {name:'Presidency University Kolkata',city:'Kolkata',country:'India',region:'India'},
  {name:'Presidency University Bangalore',city:'Bangalore',country:'India',region:'India'},
  {name:'Fergusson College',city:'Pune',country:'India',region:'India'},
  {name:'Elphinstone College',city:'Mumbai',country:'India',region:'India'},
  {name:'St. Xavier\'s College Mumbai',city:'Mumbai',country:'India',region:'India'},
  {name:'St. Xavier\'s College Kolkata',city:'Kolkata',country:'India',region:'India'},
  {name:'Stella Maris College',city:'Chennai',country:'India',region:'India'},
  {name:'PSG College of Technology',city:'Coimbatore',country:'India',region:'India'},
  {name:'Coimbatore Institute of Technology',city:'Coimbatore',country:'India',region:'India'},
  {name:'Thapar University',city:'Patiala',country:'India',region:'India'},
  {name:'Chandigarh University',city:'Chandigarh',country:'India',region:'India'},
  {name:'LPU Jalandhar',city:'Jalandhar',country:'India',region:'India'},
  {name:'Sharda University',city:'Greater Noida',country:'India',region:'India'},
  {name:'Lovely Professional University',city:'Phagwara',country:'India',region:'India'},
  {name:'Guru Gobind Singh Indraprastha University',city:'New Delhi',country:'India',region:'India'},
  {name:'Delhi Technological University',city:'New Delhi',country:'India',region:'India'},
  {name:'Netaji Subhas University of Technology',city:'New Delhi',country:'India',region:'India'},
  {name:'PEC University of Technology',city:'Chandigarh',country:'India',region:'India'},
  {name:'Rajasthan University',city:'Jaipur',country:'India',region:'India'},
  {name:'Gujarat University',city:'Ahmedabad',country:'India',region:'India'},
  {name:'Andhra University',city:'Visakhapatnam',country:'India',region:'India'},
  {name:'Annamalai University',city:'Chidambaram',country:'India',region:'India'},
  {name:'Kurukshetra University',city:'Kurukshetra',country:'India',region:'India'},
  {name:'Panjab University',city:'Chandigarh',country:'India',region:'India'},
  {name:'Lucknow University',city:'Lucknow',country:'India',region:'India'},
  {name:'Patna University',city:'Patna',country:'India',region:'India'},
  {name:'Gauhati University',city:'Guwahati',country:'India',region:'India'},
  {name:'Mysore University',city:'Mysore',country:'India',region:'India'},
  {name:'Bangalore University',city:'Bangalore',country:'India',region:'India'},
  {name:'Kerala University',city:'Thiruvananthapuram',country:'India',region:'India'},
  {name:'Calicut University',city:'Kozhikode',country:'India',region:'India'},
  {name:'Cochin University of Science and Technology',city:'Kochi',country:'India',region:'India'},
  // ── INDIA: Remaining NITs ──
  {name:'NIT Agartala',city:'Agartala',country:'India',region:'India'},
  {name:'NIT Arunachal Pradesh',city:'Yupia',country:'India',region:'India'},
  {name:'NIT Delhi',city:'New Delhi',country:'India',region:'India'},
  {name:'NIT Goa',city:'Panaji',country:'India',region:'India'},
  {name:'NIT Manipur',city:'Imphal',country:'India',region:'India'},
  {name:'NIT Meghalaya',city:'Shillong',country:'India',region:'India'},
  {name:'NIT Mizoram',city:'Aizawl',country:'India',region:'India'},
  {name:'NIT Patna',city:'Patna',country:'India',region:'India'},
  {name:'NIT Puducherry',city:'Pondicherry',country:'India',region:'India'},
  {name:'NIT Raipur',city:'Raipur',country:'India',region:'India'},
  {name:'NIT Silchar',city:'Silchar',country:'India',region:'India'},
  {name:'NIT Uttarakhand',city:'Srinagar',country:'India',region:'India'},
  {name:'NIT Andhra Pradesh',city:'Tadepalligudem',country:'India',region:'India'},
  // ── INDIA: IIITs ──
  {name:'IIIT Delhi',city:'New Delhi',country:'India',region:'India'},
  {name:'IIIT Gwalior',city:'Gwalior',country:'India',region:'India'},
  {name:'IIIT Jabalpur',city:'Jabalpur',country:'India',region:'India'},
  {name:'IIIT Kancheepuram',city:'Chennai',country:'India',region:'India'},
  {name:'IIIT Kota',city:'Kota',country:'India',region:'India'},
  {name:'IIIT Pune',city:'Pune',country:'India',region:'India'},
  {name:'IIIT Ranchi',city:'Ranchi',country:'India',region:'India'},
  {name:'IIIT Vadodara',city:'Vadodara',country:'India',region:'India'},
  {name:'IIIT Nagpur',city:'Nagpur',country:'India',region:'India'},
  {name:'IIIT Lucknow',city:'Lucknow',country:'India',region:'India'},
  {name:'IIIT Dharwad',city:'Dharwad',country:'India',region:'India'},
  {name:'IIIT Kalyani',city:'Kalyani',country:'India',region:'India'},
  {name:'IIIT Manipur',city:'Imphal',country:'India',region:'India'},
  {name:'IIIT Surat',city:'Surat',country:'India',region:'India'},
  {name:'IIIT Agartala',city:'Agartala',country:'India',region:'India'},
  {name:'IIIT Bhagalpur',city:'Bhagalpur',country:'India',region:'India'},
  {name:'IIIT Bhopal',city:'Bhopal',country:'India',region:'India'},
  {name:'IIIT Kottayam',city:'Kottayam',country:'India',region:'India'},
  {name:'IIIT Sri City',city:'Chittoor',country:'India',region:'India'},
  {name:'IIIT Una',city:'Una',country:'India',region:'India'},
  // ── INDIA: More AIIMS ──
  {name:'AIIMS Nagpur',city:'Nagpur',country:'India',region:'India'},
  {name:'AIIMS Kalyani',city:'Kalyani',country:'India',region:'India'},
  {name:'AIIMS Bathinda',city:'Bathinda',country:'India',region:'India'},
  {name:'AIIMS Gorakhpur',city:'Gorakhpur',country:'India',region:'India'},
  {name:'AIIMS Bilaspur',city:'Bilaspur',country:'India',region:'India'},
  {name:'AIIMS Mangalagiri',city:'Mangalagiri',country:'India',region:'India'},
  {name:'AIIMS Rajkot',city:'Rajkot',country:'India',region:'India'},
  {name:'AIIMS Bibinagar',city:'Bibinagar',country:'India',region:'India'},
  {name:'AIIMS Deoghar',city:'Deoghar',country:'India',region:'India'},
  {name:'AIIMS Guwahati',city:'Guwahati',country:'India',region:'India'},
  // ── INDIA: More NLUs ──
  {name:'NLU Cuttack',city:'Cuttack',country:'India',region:'India'},
  {name:'NLU Mumbai',city:'Mumbai',country:'India',region:'India'},
  {name:'NLU Ranchi',city:'Ranchi',country:'India',region:'India'},
  {name:'NLU Patna',city:'Patna',country:'India',region:'India'},
  {name:'NLU Aurangabad',city:'Aurangabad',country:'India',region:'India'},
  {name:'NLU Kochi',city:'Kochi',country:'India',region:'India'},
  {name:'NLU Shimla',city:'Shimla',country:'India',region:'India'},
  {name:'NLU Bangalore',city:'Bangalore',country:'India',region:'India'},
  {name:'NLU Raipur',city:'Raipur',country:'India',region:'India'},
  {name:'NLU Nagpur',city:'Nagpur',country:'India',region:'India'},
  {name:'NLU Guwahati',city:'Guwahati',country:'India',region:'India'},
  // ── INDIA: Tamil Nadu Universities ──
  {name:'Bharathiar University',city:'Coimbatore',country:'India',region:'India'},
  {name:'Bharathidasan University',city:'Tiruchirappalli',country:'India',region:'India'},
  {name:'Alagappa University',city:'Karaikudi',country:'India',region:'India'},
  {name:'Periyar University',city:'Salem',country:'India',region:'India'},
  {name:'Mother Teresa Women\'s University',city:'Kodaikanal',country:'India',region:'India'},
  {name:'Tamil Nadu Open University',city:'Chennai',country:'India',region:'India'},
  {name:'Tamil Nadu Teachers Education University',city:'Chennai',country:'India',region:'India'},
  {name:'Tamil Nadu Agricultural University',city:'Coimbatore',country:'India',region:'India'},
  {name:'Tamil Nadu Veterinary and Animal Sciences University',city:'Chennai',country:'India',region:'India'},
  {name:'The Tamil Nadu Dr. Ambedkar Law University',city:'Chennai',country:'India',region:'India'},
  {name:'Dr. MGR Educational and Research Institute',city:'Chennai',country:'India',region:'India'},
  {name:'Vinayaka Missions Research Foundation',city:'Salem',country:'India',region:'India'},
  {name:'Karpagam Academy of Higher Education',city:'Coimbatore',country:'India',region:'India'},
  {name:'Sathyabama Institute of Science and Technology',city:'Chennai',country:'India',region:'India'},
  {name:'Saveetha Institute of Medical and Technical Sciences',city:'Chennai',country:'India',region:'India'},
  {name:'Sri Ramachandra Institute of Higher Education',city:'Chennai',country:'India',region:'India'},
  {name:'Meenakshi Academy of Higher Education',city:'Chennai',country:'India',region:'India'},
  {name:'Noorul Islam Centre for Higher Education',city:'Kanyakumari',country:'India',region:'India'},
  {name:'Vel Tech Rangarajan Dr. Sagunthala R&D Institute',city:'Chennai',country:'India',region:'India'},
  {name:'Hindustan Institute of Technology and Science',city:'Chennai',country:'India',region:'India'},
  {name:'Dr. B.R. Ambedkar University',city:'Agra',country:'India',region:'India'},
  {name:'Manonmaniam Sundaranar University',city:'Tirunelveli',country:'India',region:'India'},
  {name:'Thiruvalluvar University',city:'Vellore',country:'India',region:'India'},
  {name:'Periyar Maniammai Institute of Science and Technology',city:'Thanjavur',country:'India',region:'India'},
  // ── INDIA: Karnataka Universities ──
  {name:'Visvesvaraya Technological University',city:'Belgaum',country:'India',region:'India'},
  {name:'Davangere University',city:'Davangere',country:'India',region:'India'},
  {name:'Kuvempu University',city:'Shivamogga',country:'India',region:'India'},
  {name:'Mangalore University',city:'Mangalore',country:'India',region:'India'},
  {name:'Karnataka University',city:'Dharwad',country:'India',region:'India'},
  {name:'Gulbarga University',city:'Kalaburagi',country:'India',region:'India'},
  {name:'Tumkur University',city:'Tumkur',country:'India',region:'India'},
  {name:'Rani Channamma University',city:'Belagavi',country:'India',region:'India'},
  {name:'Vijayanagara Sri Krishnadevaraya University',city:'Ballari',country:'India',region:'India'},
  {name:'Karnataka State Open University',city:'Mysore',country:'India',region:'India'},
  {name:'Rajiv Gandhi University of Health Sciences',city:'Bangalore',country:'India',region:'India'},
  {name:'Reva University',city:'Bangalore',country:'India',region:'India'},
  {name:'PES University',city:'Bangalore',country:'India',region:'India'},
  {name:'MS Ramaiah Institute of Technology',city:'Bangalore',country:'India',region:'India'},
  {name:'RV College of Engineering',city:'Bangalore',country:'India',region:'India'},
  {name:'BMS College of Engineering',city:'Bangalore',country:'India',region:'India'},
  {name:'New Horizon College of Engineering',city:'Bangalore',country:'India',region:'India'},
  {name:'Jain University',city:'Bangalore',country:'India',region:'India'},
  {name:'Alliance University',city:'Bangalore',country:'India',region:'India'},
  {name:'CMR University',city:'Bangalore',country:'India',region:'India'},
  // ── INDIA: Maharashtra Universities ──
  {name:'Savitribai Phule Pune University',city:'Pune',country:'India',region:'India'},
  {name:'Shivaji University',city:'Kolhapur',country:'India',region:'India'},
  {name:'North Maharashtra University',city:'Jalgaon',country:'India',region:'India'},
  {name:'Swami Ramanand Teerth Marathwada University',city:'Nanded',country:'India',region:'India'},
  {name:'Dr. Babasaheb Ambedkar Marathwada University',city:'Aurangabad',country:'India',region:'India'},
  {name:'Amravati University',city:'Amravati',country:'India',region:'India'},
  {name:'Nagpur University',city:'Nagpur',country:'India',region:'India'},
  {name:'Solapur University',city:'Solapur',country:'India',region:'India'},
  {name:'Gondwana University',city:'Gadchiroli',country:'India',region:'India'},
  {name:'Rashtrasant Tukadoji Maharaj Nagpur University',city:'Nagpur',country:'India',region:'India'},
  {name:'Homi Bhabha National Institute',city:'Mumbai',country:'India',region:'India'},
  {name:'Institute of Chemical Technology',city:'Mumbai',country:'India',region:'India'},
  {name:'SNDT Women\'s University',city:'Mumbai',country:'India',region:'India'},
  {name:'Padmashree Dr. D.Y. Patil University',city:'Navi Mumbai',country:'India',region:'India'},
  {name:'MIT World Peace University',city:'Pune',country:'India',region:'India'},
  {name:'Bharati Vidyapeeth Deemed University',city:'Pune',country:'India',region:'India'},
  {name:'Dr. D.Y. Patil Vidyapeeth',city:'Pune',country:'India',region:'India'},
  {name:'Sinhgad Technical Education Society',city:'Pune',country:'India',region:'India'},
  {name:'Tilak Maharashtra Vidyapeeth',city:'Pune',country:'India',region:'India'},
  {name:'Sandip University',city:'Nashik',country:'India',region:'India'},
  // ── INDIA: Andhra Pradesh & Telangana Universities ──
  {name:'Sri Venkateswara University',city:'Tirupati',country:'India',region:'India'},
  {name:'Acharya Nagarjuna University',city:'Guntur',country:'India',region:'India'},
  {name:'Krishna University',city:'Machilipatnam',country:'India',region:'India'},
  {name:'Adikavi Nannaya University',city:'Rajahmundry',country:'India',region:'India'},
  {name:'Rayalaseema University',city:'Kurnool',country:'India',region:'India'},
  {name:'Dr. B.R. Ambedkar Open University',city:'Hyderabad',country:'India',region:'India'},
  {name:'Kakatiya University',city:'Warangal',country:'India',region:'India'},
  {name:'Telangana University',city:'Nizamabad',country:'India',region:'India'},
  {name:'Satavahana University',city:'Karimnagar',country:'India',region:'India'},
  {name:'Palamuru University',city:'Mahbubnagar',country:'India',region:'India'},
  {name:'Mahatma Gandhi University Nalgonda',city:'Nalgonda',country:'India',region:'India'},
  {name:'Jawaharlal Nehru Technological University Hyderabad',city:'Hyderabad',country:'India',region:'India'},
  {name:'Jawaharlal Nehru Technological University Kakinada',city:'Kakinada',country:'India',region:'India'},
  {name:'Jawaharlal Nehru Technological University Anantapur',city:'Anantapur',country:'India',region:'India'},
  // ── INDIA: Kerala Universities ──
  {name:'Mahatma Gandhi University Kottayam',city:'Kottayam',country:'India',region:'India'},
  {name:'Kannur University',city:'Kannur',country:'India',region:'India'},
  {name:'Sree Sankaracharya University of Sanskrit',city:'Kalady',country:'India',region:'India'},
  {name:'Kerala Agricultural University',city:'Thrissur',country:'India',region:'India'},
  {name:'Kerala University of Fisheries and Ocean Studies',city:'Kochi',country:'India',region:'India'},
  {name:'Kerala University of Health Sciences',city:'Thrissur',country:'India',region:'India'},
  {name:'APJ Abdul Kalam Technological University',city:'Thiruvananthapuram',country:'India',region:'India'},
  {name:'Thunchath Ezhuthachan Malayalam University',city:'Tirur',country:'India',region:'India'},
  {name:'Kerala Kalamandalam',city:'Thrissur',country:'India',region:'India'},
  // ── INDIA: Gujarat Universities ──
  {name:'Saurashtra University',city:'Rajkot',country:'India',region:'India'},
  {name:'Sardar Patel University',city:'Vallabh Vidyanagar',country:'India',region:'India'},
  {name:'Veer Narmad South Gujarat University',city:'Surat',country:'India',region:'India'},
  {name:'Hemchandracharya North Gujarat University',city:'Patan',country:'India',region:'India'},
  {name:'Krantiguru Shyamji Krishna Verma Kachchh University',city:'Bhuj',country:'India',region:'India'},
  {name:'Gujarat Technological University',city:'Ahmedabad',country:'India',region:'India'},
  {name:'Gujarat University Ahmedabad',city:'Ahmedabad',country:'India',region:'India'},
  {name:'Dhirubhai Ambani Institute of Information and Communication Technology',city:'Gandhinagar',country:'India',region:'India'},
  {name:'Pandit Deendayal Energy University',city:'Gandhinagar',country:'India',region:'India'},
  {name:'Charotar University of Science and Technology',city:'Anand',country:'India',region:'India'},
  {name:'Marwadi University',city:'Rajkot',country:'India',region:'India'},
  {name:'GLS University',city:'Ahmedabad',country:'India',region:'India'},
  {name:'Silver Oak University',city:'Ahmedabad',country:'India',region:'India'},
  // ── INDIA: Rajasthan Universities ──
  {name:'Mohanlal Sukhadia University',city:'Udaipur',country:'India',region:'India'},
  {name:'Jai Narain Vyas University',city:'Jodhpur',country:'India',region:'India'},
  {name:'Maharishi Dayanand Saraswati University',city:'Ajmer',country:'India',region:'India'},
  {name:'Bikaner Technical University',city:'Bikaner',country:'India',region:'India'},
  {name:'Rajasthan Technical University',city:'Kota',country:'India',region:'India'},
  {name:'Kota University',city:'Kota',country:'India',region:'India'},
  {name:'Shekhawati University',city:'Sikar',country:'India',region:'India'},
  {name:'Matsya University',city:'Alwar',country:'India',region:'India'},
  {name:'Manipal University Jaipur',city:'Jaipur',country:'India',region:'India'},
  {name:'Jagan Nath University',city:'Jaipur',country:'India',region:'India'},
  {name:'JECRC University',city:'Jaipur',country:'India',region:'India'},
  {name:'Apex University',city:'Jaipur',country:'India',region:'India'},
  {name:'Poornima University',city:'Jaipur',country:'India',region:'India'},
  // ── INDIA: Madhya Pradesh Universities ──
  {name:'Devi Ahilya Vishwavidyalaya',city:'Indore',country:'India',region:'India'},
  {name:'Barkatullah University',city:'Bhopal',country:'India',region:'India'},
  {name:'Jiwaji University',city:'Gwalior',country:'India',region:'India'},
  {name:'Vikram University',city:'Ujjain',country:'India',region:'India'},
  {name:'Awadhesh Pratap Singh University',city:'Rewa',country:'India',region:'India'},
  {name:'Rani Durgavati Vishwavidyalaya',city:'Jabalpur',country:'India',region:'India'},
  {name:'Dr. Harisingh Gour University',city:'Sagar',country:'India',region:'India'},
  {name:'Madhya Pradesh Medical Science University',city:'Jabalpur',country:'India',region:'India'},
  {name:'Rajiv Gandhi Proudyogiki Vishwavidyalaya',city:'Bhopal',country:'India',region:'India'},
  {name:'Makhanlal Chaturvedi National University',city:'Bhopal',country:'India',region:'India'},
  {name:'Symbiosis University of Applied Sciences',city:'Indore',country:'India',region:'India'},
  {name:'Acropolis Institute of Technology and Research',city:'Indore',country:'India',region:'India'},
  // ── INDIA: Uttar Pradesh Universities ──
  {name:'Agra University',city:'Agra',country:'India',region:'India'},
  {name:'Allahabad University',city:'Prayagraj',country:'India',region:'India'},
  {name:'Chaudhary Charan Singh University',city:'Meerut',country:'India',region:'India'},
  {name:'Veer Bahadur Singh Purvanchal University',city:'Jaunpur',country:'India',region:'India'},
  {name:'Mahatma Jyotiba Phule Rohilkhand University',city:'Bareilly',country:'India',region:'India'},
  {name:'Chhatrapati Shahu Ji Maharaj University',city:'Kanpur',country:'India',region:'India'},
  {name:'Deen Dayal Upadhyaya Gorakhpur University',city:'Gorakhpur',country:'India',region:'India'},
  {name:'Bundelkhand University',city:'Jhansi',country:'India',region:'India'},
  {name:'Sampurnanand Sanskrit Vishwavidyalaya',city:'Varanasi',country:'India',region:'India'},
  {name:'UP Rajarshi Tandon Open University',city:'Prayagraj',country:'India',region:'India'},
  {name:'King George\'s Medical University',city:'Lucknow',country:'India',region:'India'},
  {name:'Dr. Ram Manohar Lohia Institute of Medical Sciences',city:'Lucknow',country:'India',region:'India'},
  {name:'Amity University Noida',city:'Noida',country:'India',region:'India'},
  {name:'Shiv Nadar University',city:'Greater Noida',country:'India',region:'India'},
  {name:'Galgotias University',city:'Greater Noida',country:'India',region:'India'},
  {name:'Bennett University',city:'Greater Noida',country:'India',region:'India'},
  {name:'GL Bajaj Institute of Technology',city:'Greater Noida',country:'India',region:'India'},
  {name:'Aligarh Muslim University Centre Murshidabad',city:'Murshidabad',country:'India',region:'India'},
  // ── INDIA: Bihar & Jharkhand Universities ──
  {name:'Magadh University',city:'Bodh Gaya',country:'India',region:'India'},
  {name:'Veer Kunwar Singh University',city:'Arrah',country:'India',region:'India'},
  {name:'Lalit Narayan Mithila University',city:'Darbhanga',country:'India',region:'India'},
  {name:'Bhupendra Narayan Mandal University',city:'Madhepura',country:'India',region:'India'},
  {name:'Jai Prakash University',city:'Chapra',country:'India',region:'India'},
  {name:'B.R. Ambedkar Bihar University',city:'Muzaffarpur',country:'India',region:'India'},
  {name:'Tilka Manjhi Bhagalpur University',city:'Bhagalpur',country:'India',region:'India'},
  {name:'Munger University',city:'Munger',country:'India',region:'India'},
  {name:'Purnea University',city:'Purnea',country:'India',region:'India'},
  {name:'Ranchi University',city:'Ranchi',country:'India',region:'India'},
  {name:'Kolhan University',city:'Chaibasa',country:'India',region:'India'},
  {name:'Sido Kanhu Murmu University',city:'Dumka',country:'India',region:'India'},
  {name:'Nilamber Pitamber University',city:'Medininagar',country:'India',region:'India'},
  {name:'Vinoba Bhave University',city:'Hazaribagh',country:'India',region:'India'},
  {name:'Binod Bihari Mahto Koylanchal University',city:'Dhanbad',country:'India',region:'India'},
  // ── INDIA: West Bengal Universities ──
  {name:'Rabindra Bharati University',city:'Kolkata',country:'India',region:'India'},
  {name:'North Bengal University',city:'Siliguri',country:'India',region:'India'},
  {name:'Burdwan University',city:'Bardhaman',country:'India',region:'India'},
  {name:'Vidyasagar University',city:'Midnapore',country:'India',region:'India'},
  {name:'Kalyani University',city:'Kalyani',country:'India',region:'India'},
  {name:'Bankura University',city:'Bankura',country:'India',region:'India'},
  {name:'Diamond Harbour Women\'s University',city:'Diamond Harbour',country:'India',region:'India'},
  {name:'Sidho Kanho Birsha University',city:'Purulia',country:'India',region:'India'},
  {name:'Kazi Nazrul University',city:'Asansol',country:'India',region:'India'},
  {name:'Aliah University',city:'Kolkata',country:'India',region:'India'},
  {name:'Netaji Subhas Open University',city:'Kolkata',country:'India',region:'India'},
  {name:'West Bengal State University',city:'Kolkata',country:'India',region:'India'},
  {name:'West Bengal University of Health Sciences',city:'Kolkata',country:'India',region:'India'},
  {name:'West Bengal University of Technology',city:'Kolkata',country:'India',region:'India'},
  {name:'Maulana Abul Kalam Azad University of Technology',city:'Kolkata',country:'India',region:'India'},
  {name:'Indian Statistical Institute',city:'Kolkata',country:'India',region:'India'},
  // ── INDIA: Odisha Universities ──
  {name:'Utkal University',city:'Bhubaneswar',country:'India',region:'India'},
  {name:'Berhampur University',city:'Berhampur',country:'India',region:'India'},
  {name:'Sambalpur University',city:'Sambalpur',country:'India',region:'India'},
  {name:'Fakir Mohan University',city:'Balasore',country:'India',region:'India'},
  {name:'North Orissa University',city:'Baripada',country:'India',region:'India'},
  {name:'Sri Sri University',city:'Cuttack',country:'India',region:'India'},
  {name:'Kalinga Institute of Industrial Technology',city:'Bhubaneswar',country:'India',region:'India'},
  {name:'SOA University',city:'Bhubaneswar',country:'India',region:'India'},
  {name:'Centurion University',city:'Bhubaneswar',country:'India',region:'India'},
  // ── INDIA: Punjab & Haryana Universities ──
  {name:'Guru Nanak Dev University',city:'Amritsar',country:'India',region:'India'},
  {name:'Punjabi University',city:'Patiala',country:'India',region:'India'},
  {name:'Baba Farid University of Health Sciences',city:'Faridkot',country:'India',region:'India'},
  {name:'Maharaja Ranjit Singh Punjab Technical University',city:'Bathinda',country:'India',region:'India'},
  {name:'IK Gujral Punjab Technical University',city:'Jalandhar',country:'India',region:'India'},
  {name:'Guru Kashi University',city:'Talwandi Sabo',country:'India',region:'India'},
  {name:'Maharishi Markandeshwar University',city:'Ambala',country:'India',region:'India'},
  {name:'MDU Rohtak',city:'Rohtak',country:'India',region:'India'},
  {name:'GJUS&T Hisar',city:'Hisar',country:'India',region:'India'},
  {name:'Chaudhary Devi Lal University',city:'Sirsa',country:'India',region:'India'},
  {name:'BPS Mahila Vishwavidyalaya',city:'Khanpur Kalan',country:'India',region:'India'},
  {name:'Central University of Haryana',city:'Mahendragarh',country:'India',region:'India'},
  {name:'Ashoka University',city:'Sonipat',country:'India',region:'India'},
  {name:'O.P. Jindal Global University',city:'Sonipat',country:'India',region:'India'},
  // ── INDIA: Himachal Pradesh & Uttarakhand ──
  {name:'Himachal Pradesh University',city:'Shimla',country:'India',region:'India'},
  {name:'Jaypee University of Information Technology',city:'Solan',country:'India',region:'India'},
  {name:'Chitkara University Himachal Pradesh',city:'Solan',country:'India',region:'India'},
  {name:'Shoolini University',city:'Solan',country:'India',region:'India'},
  {name:'Hemvati Nandan Bahuguna Garhwal University',city:'Srinagar',country:'India',region:'India'},
  {name:'Kumaun University',city:'Nainital',country:'India',region:'India'},
  {name:'Uttarakhand Technical University',city:'Dehradun',country:'India',region:'India'},
  {name:'Doon University',city:'Dehradun',country:'India',region:'India'},
  {name:'Dev Bhoomi Uttarakhand University',city:'Dehradun',country:'India',region:'India'},
  {name:'Graphic Era University',city:'Dehradun',country:'India',region:'India'},
  {name:'UPES Dehradun',city:'Dehradun',country:'India',region:'India'},
  {name:'DIT University',city:'Dehradun',country:'India',region:'India'},
  // ── INDIA: Chhattisgarh Universities ──
  {name:'Pt. Ravishankar Shukla University',city:'Raipur',country:'India',region:'India'},
  {name:'Shaheed Nandkumar Patel Vishwavidyalaya',city:'Raigarh',country:'India',region:'India'},
  {name:'Bastar University',city:'Jagdalpur',country:'India',region:'India'},
  {name:'Kalyan Singh University',city:'Raipur',country:'India',region:'India'},
  {name:'Hemchand Yadav University',city:'Durg',country:'India',region:'India'},
  {name:'Chhattisgarh Swami Vivekanand Technical University',city:'Bhilai',country:'India',region:'India'},
  // ── INDIA: Assam & Northeast Universities ──
  {name:'Cotton University',city:'Guwahati',country:'India',region:'India'},
  {name:'Dibrugarh University',city:'Dibrugarh',country:'India',region:'India'},
  {name:'Assam Agricultural University',city:'Jorhat',country:'India',region:'India'},
  {name:'Bodoland University',city:'Kokrajhar',country:'India',region:'India'},
  {name:'Kumar Bhaskar Varma Sanskrit and Ancient Studies University',city:'Nalbari',country:'India',region:'India'},
  {name:'Rabindranath Tagore University Assam',city:'Hojai',country:'India',region:'India'},
  {name:'Sikkim University',city:'Gangtok',country:'India',region:'India'},
  {name:'Sikkim Manipal University',city:'Gangtok',country:'India',region:'India'},
  {name:'ICFAI University Sikkim',city:'Gangtok',country:'India',region:'India'},
  {name:'Arunachal University of Studies',city:'Namsai',country:'India',region:'India'},
  {name:'Rajiv Gandhi University',city:'Itanagar',country:'India',region:'India'},
  {name:'Tripura Central University',city:'Agartala',country:'India',region:'India'},
  {name:'Manipur University of Culture',city:'Imphal',country:'India',region:'India'},
  // ── INDIA: Jammu & Kashmir ──
  {name:'University of Jammu',city:'Jammu',country:'India',region:'India'},
  {name:'University of Kashmir',city:'Srinagar',country:'India',region:'India'},
  {name:'Cluster University Srinagar',city:'Srinagar',country:'India',region:'India'},
  {name:'Cluster University Jammu',city:'Jammu',country:'India',region:'India'},
  {name:'Shri Mata Vaishno Devi University',city:'Katra',country:'India',region:'India'},
  {name:'Baba Ghulam Shah Badshah University',city:'Rajouri',country:'India',region:'India'},
  {name:'Islamic University of Science and Technology',city:'Awantipora',country:'India',region:'India'},
  {name:'Central University of Jammu',city:'Jammu',country:'India',region:'India'},
  {name:'Central University of Kashmir',city:'Ganderbal',country:'India',region:'India'},
  // ── INDIA: Goa, Lakshadweep & Andaman ──
  {name:'Goa University',city:'Panaji',country:'India',region:'India'},
  {name:'Dhempe College of Arts and Science',city:'Panaji',country:'India',region:'India'},
  {name:'Goa College of Engineering',city:'Panaji',country:'India',region:'India'},
  // ── INDIA: Deemed & Private Universities (Major) ──
  {name:'ICFAI University',city:'Hyderabad',country:'India',region:'India'},
  {name:'FLAME University',city:'Pune',country:'India',region:'India'},
  {name:'OP Jindal Global University',city:'Sonipat',country:'India',region:'India'},
  {name:'Azim Premji University',city:'Bangalore',country:'India',region:'India'},
  {name:'Plaksha University',city:'Mohali',country:'India',region:'India'},
  {name:'Krea University',city:'Sri City',country:'India',region:'India'},
  {name:'Ahmedabad University',city:'Ahmedabad',country:'India',region:'India'},
  {name:'Shiv Nadar Institution of Eminence',city:'Greater Noida',country:'India',region:'India'},
  {name:'Sri Sri University',city:'Cuttack',country:'India',region:'India'},
  {name:'Woxsen University',city:'Hyderabad',country:'India',region:'India'},
  {name:'Mahindra University',city:'Hyderabad',country:'India',region:'India'},
  {name:'Rishihood University',city:'Sonipat',country:'India',region:'India'},
  {name:'Vellore Institute of Technology Chennai',city:'Chennai',country:'India',region:'India'},
  {name:'VIT-AP University',city:'Amaravati',country:'India',region:'India'},
  {name:'VIT Bhopal University',city:'Bhopal',country:'India',region:'India'},
  {name:'SRM Institute of Science and Technology Kattankulathur',city:'Kanchipuram',country:'India',region:'India'},
  {name:'SRM University AP',city:'Amaravati',country:'India',region:'India'},
  {name:'Kalinga University',city:'Raipur',country:'India',region:'India'},
  {name:'Amity University Mumbai',city:'Mumbai',country:'India',region:'India'},
  {name:'Amity University Kolkata',city:'Kolkata',country:'India',region:'India'},
  {name:'Amity University Jaipur',city:'Jaipur',country:'India',region:'India'},
  {name:'Amity University Lucknow',city:'Lucknow',country:'India',region:'India'},
  {name:'Amity University Patna',city:'Patna',country:'India',region:'India'},
  {name:'Amity University Gwalior',city:'Gwalior',country:'India',region:'India'},
  {name:'Chitkara University Punjab',city:'Rajpura',country:'India',region:'India'},
  {name:'Chitkara University Rajasthan',city:'Jaipur',country:'India',region:'India'},
  {name:'Manav Rachna University',city:'Faridabad',country:'India',region:'India'},
  {name:'KL University',city:'Vijayawada',country:'India',region:'India'},
  {name:'Koneru Lakshmaiah Education Foundation',city:'Guntur',country:'India',region:'India'},
  {name:'Vignan University',city:'Guntur',country:'India',region:'India'},
  {name:'GITAM University',city:'Visakhapatnam',country:'India',region:'India'},
  {name:'Andhra Loyola College',city:'Vijayawada',country:'India',region:'India'},
  {name:'RGUKT Nuzvid',city:'Nuzvid',country:'India',region:'India'},
  {name:'RGUKT Basar',city:'Basar',country:'India',region:'India'},
  {name:'RGUKT Idupulapaya',city:'Idupulapaya',country:'India',region:'India'},
  {name:'Dayananda Sagar University',city:'Bangalore',country:'India',region:'India'},
  {name:'KLE Technological University',city:'Hubli',country:'India',region:'India'},
  {name:'Nitte University',city:'Mangalore',country:'India',region:'India'},
  {name:'Yenepoya University',city:'Mangalore',country:'India',region:'India'},
  {name:'MAHE Manipal',city:'Manipal',country:'India',region:'India'},
  {name:'Suresh Gyan Vihar University',city:'Jaipur',country:'India',region:'India'},
  {name:'ICFAI Business School',city:'Hyderabad',country:'India',region:'India'},
  {name:'Management Development Institute',city:'Gurugram',country:'India',region:'India'},
  {name:'FORE School of Management',city:'New Delhi',country:'India',region:'India'},
  {name:'Great Lakes Institute of Management',city:'Chennai',country:'India',region:'India'},
  {name:'IMT Ghaziabad',city:'Ghaziabad',country:'India',region:'India'},
  {name:'BIMTECH Greater Noida',city:'Greater Noida',country:'India',region:'India'},
  {name:'Xavier Institute of Management Bhubaneswar',city:'Bhubaneswar',country:'India',region:'India'},
  {name:'Xavier Labour Relations Institute',city:'Jamshedpur',country:'India',region:'India'},
  {name:'Xavier Institute of Management and Entrepreneurship',city:'Bangalore',country:'India',region:'India'},
  {name:'Welingkar Institute of Management',city:'Mumbai',country:'India',region:'India'},
  {name:'KJ Somaiya Institute of Management',city:'Mumbai',country:'India',region:'India'},
  {name:'Narsee Monjee Institute of Management Studies',city:'Mumbai',country:'India',region:'India'},
  {name:'SP Jain School of Global Management',city:'Mumbai',country:'India',region:'India'},
  {name:'SPJIMR Mumbai',city:'Mumbai',country:'India',region:'India'},
  {name:'Nirma University Institute of Management',city:'Ahmedabad',country:'India',region:'India'},
  {name:'IFMR Graduate School of Business',city:'Sri City',country:'India',region:'India'},
  {name:'SCMHRD Pune',city:'Pune',country:'India',region:'India'},
  {name:'SIBM Pune',city:'Pune',country:'India',region:'India'},
  {name:'SIOM Nashik',city:'Nashik',country:'India',region:'India'},
  {name:'SIMS Pune',city:'Pune',country:'India',region:'India'},
  // ── USA ──
  {name:'MIT',city:'Cambridge, MA',country:'USA',region:'USA'},
  {name:'Stanford University',city:'Stanford, CA',country:'USA',region:'USA'},
  {name:'Harvard University',city:'Cambridge, MA',country:'USA',region:'USA'},
  {name:'Caltech',city:'Pasadena, CA',country:'USA',region:'USA'},
  {name:'Princeton University',city:'Princeton, NJ',country:'USA',region:'USA'},
  {name:'Yale University',city:'New Haven, CT',country:'USA',region:'USA'},
  {name:'Columbia University',city:'New York, NY',country:'USA',region:'USA'},
  {name:'University of Chicago',city:'Chicago, IL',country:'USA',region:'USA'},
  {name:'University of Pennsylvania',city:'Philadelphia, PA',country:'USA',region:'USA'},
  {name:'Cornell University',city:'Ithaca, NY',country:'USA',region:'USA'},
  {name:'Johns Hopkins University',city:'Baltimore, MD',country:'USA',region:'USA'},
  {name:'Duke University',city:'Durham, NC',country:'USA',region:'USA'},
  {name:'Northwestern University',city:'Evanston, IL',country:'USA',region:'USA'},
  {name:'UC Berkeley',city:'Berkeley, CA',country:'USA',region:'USA'},
  {name:'UCLA',city:'Los Angeles, CA',country:'USA',region:'USA'},
  {name:'University of Michigan',city:'Ann Arbor, MI',country:'USA',region:'USA'},
  {name:'NYU',city:'New York, NY',country:'USA',region:'USA'},
  {name:'Carnegie Mellon University',city:'Pittsburgh, PA',country:'USA',region:'USA'},
  {name:'Georgia Tech',city:'Atlanta, GA',country:'USA',region:'USA'},
  {name:'University of Texas at Austin',city:'Austin, TX',country:'USA',region:'USA'},
  {name:'University of Illinois Urbana-Champaign',city:'Champaign, IL',country:'USA',region:'USA'},
  {name:'Purdue University',city:'West Lafayette, IN',country:'USA',region:'USA'},
  {name:'Penn State University',city:'University Park, PA',country:'USA',region:'USA'},
  {name:'Ohio State University',city:'Columbus, OH',country:'USA',region:'USA'},
  {name:'University of Washington',city:'Seattle, WA',country:'USA',region:'USA'},
  {name:'University of Wisconsin-Madison',city:'Madison, WI',country:'USA',region:'USA'},
  {name:'University of Florida',city:'Gainesville, FL',country:'USA',region:'USA'},
  {name:'Boston University',city:'Boston, MA',country:'USA',region:'USA'},
  {name:'Tufts University',city:'Medford, MA',country:'USA',region:'USA'},
  {name:'Dartmouth College',city:'Hanover, NH',country:'USA',region:'USA'},
  {name:'Brown University',city:'Providence, RI',country:'USA',region:'USA'},
  {name:'Rice University',city:'Houston, TX',country:'USA',region:'USA'},
  {name:'Vanderbilt University',city:'Nashville, TN',country:'USA',region:'USA'},
  {name:'Emory University',city:'Atlanta, GA',country:'USA',region:'USA'},
  {name:'University of Notre Dame',city:'Notre Dame, IN',country:'USA',region:'USA'},
  {name:'Georgetown University',city:'Washington, DC',country:'USA',region:'USA'},
  {name:'University of Southern California',city:'Los Angeles, CA',country:'USA',region:'USA'},
  {name:'Arizona State University',city:'Tempe, AZ',country:'USA',region:'USA'},
  {name:'Michigan State University',city:'East Lansing, MI',country:'USA',region:'USA'},
  {name:'UC San Diego',city:'La Jolla, CA',country:'USA',region:'USA'},
  {name:'UC Davis',city:'Davis, CA',country:'USA',region:'USA'},
  {name:'UC Santa Barbara',city:'Santa Barbara, CA',country:'USA',region:'USA'},
  // ── UK ──
  {name:'University of Oxford',city:'Oxford',country:'UK',region:'UK'},
  {name:'University of Cambridge',city:'Cambridge',country:'UK',region:'UK'},
  {name:'Imperial College London',city:'London',country:'UK',region:'UK'},
  {name:'UCL',city:'London',country:'UK',region:'UK'},
  {name:'London School of Economics',city:'London',country:'UK',region:'UK'},
  {name:'University of Edinburgh',city:'Edinburgh',country:'UK',region:'UK'},
  {name:'University of Manchester',city:'Manchester',country:'UK',region:'UK'},
  {name:'King\'s College London',city:'London',country:'UK',region:'UK'},
  {name:'University of Bristol',city:'Bristol',country:'UK',region:'UK'},
  {name:'University of Warwick',city:'Coventry',country:'UK',region:'UK'},
  {name:'University of Glasgow',city:'Glasgow',country:'UK',region:'UK'},
  {name:'Durham University',city:'Durham',country:'UK',region:'UK'},
  {name:'University of Sheffield',city:'Sheffield',country:'UK',region:'UK'},
  {name:'University of Birmingham',city:'Birmingham',country:'UK',region:'UK'},
  {name:'University of Leeds',city:'Leeds',country:'UK',region:'UK'},
  {name:'University of Southampton',city:'Southampton',country:'UK',region:'UK'},
  {name:'University of Exeter',city:'Exeter',country:'UK',region:'UK'},
  {name:'University of Bath',city:'Bath',country:'UK',region:'UK'},
  {name:'Cardiff University',city:'Cardiff',country:'UK',region:'UK'},
  {name:'Queen Mary University of London',city:'London',country:'UK',region:'UK'},
  {name:'University of St Andrews',city:'St Andrews',country:'UK',region:'UK'},
  {name:'Newcastle University',city:'Newcastle',country:'UK',region:'UK'},
  {name:'University of Nottingham',city:'Nottingham',country:'UK',region:'UK'},
  // ── AUSTRALIA ──
  {name:'University of Melbourne',city:'Melbourne',country:'Australia',region:'Australia'},
  {name:'Australian National University',city:'Canberra',country:'Australia',region:'Australia'},
  {name:'University of Sydney',city:'Sydney',country:'Australia',region:'Australia'},
  {name:'University of New South Wales',city:'Sydney',country:'Australia',region:'Australia'},
  {name:'Monash University',city:'Melbourne',country:'Australia',region:'Australia'},
  {name:'University of Queensland',city:'Brisbane',country:'Australia',region:'Australia'},
  {name:'University of Adelaide',city:'Adelaide',country:'Australia',region:'Australia'},
  {name:'University of Western Australia',city:'Perth',country:'Australia',region:'Australia'},
  {name:'RMIT University',city:'Melbourne',country:'Australia',region:'Australia'},
  {name:'Macquarie University',city:'Sydney',country:'Australia',region:'Australia'},
  {name:'University of Technology Sydney',city:'Sydney',country:'Australia',region:'Australia'},
  {name:'University of Wollongong',city:'Wollongong',country:'Australia',region:'Australia'},
  // ── CANADA ──
  {name:'University of Toronto',city:'Toronto',country:'Canada',region:'Canada'},
  {name:'McGill University',city:'Montreal',country:'Canada',region:'Canada'},
  {name:'University of British Columbia',city:'Vancouver',country:'Canada',region:'Canada'},
  {name:'University of Waterloo',city:'Waterloo',country:'Canada',region:'Canada'},
  {name:'McMaster University',city:'Hamilton',country:'Canada',region:'Canada'},
  {name:'University of Alberta',city:'Edmonton',country:'Canada',region:'Canada'},
  {name:'Queen\'s University',city:'Kingston',country:'Canada',region:'Canada'},
  {name:'University of Ottawa',city:'Ottawa',country:'Canada',region:'Canada'},
  {name:'Western University',city:'London, ON',country:'Canada',region:'Canada'},
  {name:'Dalhousie University',city:'Halifax',country:'Canada',region:'Canada'},
  {name:'Simon Fraser University',city:'Burnaby',country:'Canada',region:'Canada'},
  // ── EUROPE ──
  {name:'ETH Zurich',city:'Zurich',country:'Switzerland',region:'Europe'},
  {name:'EPFL',city:'Lausanne',country:'Switzerland',region:'Europe'},
  {name:'TU Munich',city:'Munich',country:'Germany',region:'Europe'},
  {name:'LMU Munich',city:'Munich',country:'Germany',region:'Europe'},
  {name:'Heidelberg University',city:'Heidelberg',country:'Germany',region:'Europe'},
  {name:'Humboldt University Berlin',city:'Berlin',country:'Germany',region:'Europe'},
  {name:'Freie Universität Berlin',city:'Berlin',country:'Germany',region:'Europe'},
  {name:'RWTH Aachen',city:'Aachen',country:'Germany',region:'Europe'},
  {name:'KIT Karlsruhe',city:'Karlsruhe',country:'Germany',region:'Europe'},
  {name:'Paris-Saclay University',city:'Paris',country:'France',region:'Europe'},
  {name:'Sorbonne University',city:'Paris',country:'France',region:'Europe'},
  {name:'École Normale Supérieure',city:'Paris',country:'France',region:'Europe'},
  {name:'HEC Paris',city:'Paris',country:'France',region:'Europe'},
  {name:'Sciences Po Paris',city:'Paris',country:'France',region:'Europe'},
  {name:'Delft University of Technology',city:'Delft',country:'Netherlands',region:'Europe'},
  {name:'University of Amsterdam',city:'Amsterdam',country:'Netherlands',region:'Europe'},
  {name:'KU Leuven',city:'Leuven',country:'Belgium',region:'Europe'},
  {name:'University of Copenhagen',city:'Copenhagen',country:'Denmark',region:'Europe'},
  {name:'Uppsala University',city:'Uppsala',country:'Sweden',region:'Europe'},
  {name:'Lund University',city:'Lund',country:'Sweden',region:'Europe'},
  {name:'University of Helsinki',city:'Helsinki',country:'Finland',region:'Europe'},
  {name:'Aalto University',city:'Espoo',country:'Finland',region:'Europe'},
  {name:'University of Oslo',city:'Oslo',country:'Norway',region:'Europe'},
  {name:'University of Bologna',city:'Bologna',country:'Italy',region:'Europe'},
  {name:'Sapienza University of Rome',city:'Rome',country:'Italy',region:'Europe'},
  {name:'Polytechnic University of Milan',city:'Milan',country:'Italy',region:'Europe'},
  {name:'University of Barcelona',city:'Barcelona',country:'Spain',region:'Europe'},
  {name:'Complutense University of Madrid',city:'Madrid',country:'Spain',region:'Europe'},
  // ── ASIA ──
  {name:'National University of Singapore',city:'Singapore',country:'Singapore',region:'Asia'},
  {name:'Nanyang Technological University',city:'Singapore',country:'Singapore',region:'Asia'},
  {name:'Peking University',city:'Beijing',country:'China',region:'Asia'},
  {name:'Tsinghua University',city:'Beijing',country:'China',region:'Asia'},
  {name:'Fudan University',city:'Shanghai',country:'China',region:'Asia'},
  {name:'Shanghai Jiao Tong University',city:'Shanghai',country:'China',region:'Asia'},
  {name:'Zhejiang University',city:'Hangzhou',country:'China',region:'Asia'},
  {name:'University of Tokyo',city:'Tokyo',country:'Japan',region:'Asia'},
  {name:'Kyoto University',city:'Kyoto',country:'Japan',region:'Asia'},
  {name:'Osaka University',city:'Osaka',country:'Japan',region:'Asia'},
  {name:'Seoul National University',city:'Seoul',country:'South Korea',region:'Asia'},
  {name:'KAIST',city:'Daejeon',country:'South Korea',region:'Asia'},
  {name:'POSTECH',city:'Pohang',country:'South Korea',region:'Asia'},
  {name:'University of Malaya',city:'Kuala Lumpur',country:'Malaysia',region:'Asia'},
  {name:'Universiti Teknologi Malaysia',city:'Johor Bahru',country:'Malaysia',region:'Asia'},
  {name:'University of the Philippines',city:'Quezon City',country:'Philippines',region:'Asia'},
  {name:'Chulalongkorn University',city:'Bangkok',country:'Thailand',region:'Asia'},
  {name:'University of Indonesia',city:'Jakarta',country:'Indonesia',region:'Asia'},
  {name:'University of Hong Kong',city:'Hong Kong',country:'Hong Kong',region:'Asia'},
  {name:'HKUST',city:'Hong Kong',country:'Hong Kong',region:'Asia'},
  {name:'Chinese University of Hong Kong',city:'Hong Kong',country:'Hong Kong',region:'Asia'},
  {name:'National Taiwan University',city:'Taipei',country:'Taiwan',region:'Asia'},
  {name:'University of Colombo',city:'Colombo',country:'Sri Lanka',region:'Asia'},
  {name:'University of Dhaka',city:'Dhaka',country:'Bangladesh',region:'Asia'},
  {name:'Tribhuvan University',city:'Kathmandu',country:'Nepal',region:'Asia'},
  // ── MIDDLE EAST ──
  {name:'King Abdulaziz University',city:'Jeddah',country:'Saudi Arabia',region:'Middle East'},
  {name:'King Fahd University of Petroleum',city:'Dhahran',country:'Saudi Arabia',region:'Middle East'},
  {name:'American University of Beirut',city:'Beirut',country:'Lebanon',region:'Middle East'},
  {name:'University of Tehran',city:'Tehran',country:'Iran',region:'Middle East'},
  {name:'Sharif University of Technology',city:'Tehran',country:'Iran',region:'Middle East'},
  {name:'American University in Cairo',city:'Cairo',country:'Egypt',region:'Middle East'},
  {name:'Cairo University',city:'Cairo',country:'Egypt',region:'Middle East'},
  {name:'Qatar University',city:'Doha',country:'Qatar',region:'Middle East'},
  {name:'United Arab Emirates University',city:'Al Ain',country:'UAE',region:'Middle East'},
  {name:'American University of Sharjah',city:'Sharjah',country:'UAE',region:'Middle East'},
  {name:'Kuwait University',city:'Kuwait City',country:'Kuwait',region:'Middle East'},
  // ── AFRICA ──
  {name:'University of Cape Town',city:'Cape Town',country:'South Africa',region:'Africa'},
  {name:'University of Witwatersrand',city:'Johannesburg',country:'South Africa',region:'Africa'},
  {name:'University of Pretoria',city:'Pretoria',country:'South Africa',region:'Africa'},
  {name:'University of Lagos',city:'Lagos',country:'Nigeria',region:'Africa'},
  {name:'University of Nairobi',city:'Nairobi',country:'Kenya',region:'Africa'},
  {name:'University of Ghana',city:'Accra',country:'Ghana',region:'Africa'},
  {name:'Makerere University',city:'Kampala',country:'Uganda',region:'Africa'},
  {name:'University of Ibadan',city:'Ibadan',country:'Nigeria',region:'Africa'},
  // ── LATIN AMERICA ──
  {name:'University of São Paulo',city:'São Paulo',country:'Brazil',region:'Latin America'},
  {name:'State University of Campinas',city:'Campinas',country:'Brazil',region:'Latin America'},
  {name:'UNAM',city:'Mexico City',country:'Mexico',region:'Latin America'},
  {name:'University of Buenos Aires',city:'Buenos Aires',country:'Argentina',region:'Latin America'},
  {name:'Pontificia Universidad Católica de Chile',city:'Santiago',country:'Chile',region:'Latin America'},
  {name:'University of Chile',city:'Santiago',country:'Chile',region:'Latin America'},
];

// Build SEED resources from colleges
const SEED = (() => {
  const authors = ['Arjun Kumar','Priya Rao','Sita Mehta','Rahul Verma','Neha Patel','Kavya Sharma','Amit Singh','Dev Menon','Riya Joshi','Karan Nair','Meera Iyer','Suresh Babu','Divya Menon','Arun Pillai','Zara Khan','Chen Wei','Emma Johnson','Liam Smith','Mia Brown','Noah Davis'];
  const types = ['Lecture Notes','Past Exam','Reference','Slides','Study Guide'];
  const subjects = ['Computer Science','Mathematics','Engineering','Medicine','Business & Management','Physics','Chemistry','Law','Economics','Psychology','Biology'];
  const courses = {
    'Computer Science':['CS101','CS201','CS301','CS401','CS470','CS6.006','CS201'],
    'Mathematics':['MATH101','MATH201','MATH301','MATH401'],
    'Engineering':['ME201','CE301','EE401','ME401','CE201'],
    'Medicine':['MED101','MED201','PHARM301','ANAT201'],
    'Business & Management':['BUS101','FIN301','MKT201','HRM401','BUS301'],
    'Physics':['PHY101','PHY201','PHY301'],
    'Chemistry':['CHEM101','CHEM201','CHEM302'],
    'Law':['LAW101','LAW201','LAW301','LAW401'],
    'Economics':['ECO101','ECO201','ECO301'],
    'Psychology':['PSY101','PSY201','PSY301'],
    'Biology':['BIO101','BIO201','BIO301'],
  };
  const titles = {
    'Computer Science':['Data Structures Complete Notes','Operating Systems Masterclass','Algorithms & Complexity Guide','Database Systems Reference','Computer Networks Past Exam','Machine Learning Slides','Software Engineering Study Guide','Computer Architecture Notes','Compiler Design Reference','Cybersecurity Past Exam'],
    'Mathematics':['Calculus II Final Exam with Solutions','Linear Algebra Complete Notes','Real Analysis Reference Guide','Probability & Statistics Slides','Discrete Mathematics Study Guide','Differential Equations Notes','Abstract Algebra Past Exam','Numerical Methods Reference','Complex Analysis Notes','Graph Theory Study Guide'],
    'Engineering':['Thermodynamics Problem Bank','Structural Analysis Notes','Fluid Mechanics Reference','Circuit Analysis Past Exam','Signals & Systems Slides','Control Systems Study Guide','Manufacturing Processes Notes','Engineering Mechanics Reference','Heat Transfer Past Exam','Materials Science Notes'],
    'Medicine':['Human Anatomy Complete Notes','Pharmacology Drug Reference','Pathology Past Exam','Physiology Study Guide','Biochemistry Reaction Atlas','Clinical Medicine Notes','Microbiology Reference','Surgery Past Exam Papers','Neurology Slides','Immunology Study Guide'],
    'Business & Management':['Corporate Finance Mid-Term Papers','Marketing Strategy Notes','Operations Management Reference','Human Resource Management Slides','Business Ethics Study Guide','Organizational Behaviour Notes','Strategic Management Past Exam','Financial Accounting Reference','Entrepreneurship Slides','Supply Chain Management Notes'],
    'Physics':['Quantum Mechanics Complete Notes','Electromagnetism Reference','Classical Mechanics Past Exam','Thermodynamics Study Guide','Optics & Waves Slides','Nuclear Physics Notes','Solid State Physics Reference','Astrophysics Study Guide','Particle Physics Notes','Relativity Slides'],
    'Chemistry':['Organic Chemistry Reaction Atlas','Physical Chemistry Past Exam','Inorganic Chemistry Notes','Analytical Chemistry Reference','Polymer Chemistry Slides','Green Chemistry Study Guide','Spectroscopy Notes','Electrochemistry Past Exam','Medicinal Chemistry Reference','Chemical Kinetics Notes'],
    'Law':['Constitutional Law Case Summaries','Contract Law Past Exam','Criminal Law Notes','International Law Reference','Corporate Law Slides','Tort Law Study Guide','Property Law Notes','Administrative Law Past Exam','Family Law Reference','Environmental Law Notes'],
    'Economics':['Microeconomics Past Exam','Macroeconomics Complete Notes','Econometrics Reference','Development Economics Slides','International Trade Study Guide','Public Finance Notes','Game Theory Past Exam','Behavioural Economics Reference','Labour Economics Notes','Environmental Economics Slides'],
    'Psychology':['Cognitive Psychology Notes','Social Psychology Past Exam','Developmental Psychology Reference','Clinical Psychology Slides','Abnormal Psychology Study Guide','Neuropsychology Notes','Research Methods Past Exam','Positive Psychology Reference','Forensic Psychology Notes','Health Psychology Slides'],
    'Biology':['Cell Biology Complete Notes','Genetics Past Exam','Molecular Biology Reference','Ecology Study Guide','Evolution & Systematics Slides','Microbiology Notes','Biochemistry Past Exam','Plant Biology Reference','Animal Physiology Notes','Biotechnology Study Guide'],
  };
  const descs = ['Comprehensive notes with worked examples and key definitions.','Solved paper with detailed step-by-step solutions.','Complete reference guide with formulas and tables.','Annotated lecture slides with speaker notes.','Structured guide with summaries and practice questions.','Covers all examinable topics with visual aids.','Includes past questions and model answers.','Essential formulas and theorems for quick revision.'];

  const seed = [];
  let ts = 1741000000000;
  let idNum = 1;

  // one resource per college (sample spread)
  COLLEGES.forEach((col, i) => {
    const subj = subjects[i % subjects.length];
    const typeList = types;
    const t = typeList[i % typeList.length];
    const titleArr = titles[subj];
    const title = titleArr[i % titleArr.length];
    const courseArr = courses[subj];
    const course = courseArr[i % courseArr.length];
    const author = authors[i % authors.length];
    const desc = descs[i % descs.length];
    const downloads = Math.floor(Math.random() * 1800) + 50;
    const rating = +(3.5 + Math.random() * 1.5).toFixed(1);
    seed.push({
      id: 'sv' + String(idNum++).padStart(4,'0'),
      title: title + (i < 5 ? ' — ' + col.name : ''),
      course,
      college: col.name,
      country: col.country,
      city: col.city,
      region: col.region,
      subject: subj,
      type: t,
      author,
      semester: `Semester ${(i%8)+1} / 202${3+i%2}`,
      desc,
      downloads,
      rating,
      saved: false,
      featured: i === 0,
      createdAt: ts - i * 86400000,
    });
  });
  return seed;
})();

function loadDB(){
  try{const raw=sessionStorage.getItem(DB_KEY);if(raw)return JSON.parse(raw);}catch(e){}
  const db={resources:[...SEED],savedIds:[],downloads:{}};
  SEED.forEach(r=>{db.downloads[r.id]=r.downloads;});
  saveDB(db);return db;
}
function saveDB(db){try{sessionStorage.setItem(DB_KEY,JSON.stringify(db));}catch(e){}}

let DB=loadDB();
let currentSort='newest';
let filterSubject='All';
let filterCollege='All';
let filterType='';
let currentDetailId=null;
let currentCollegeDetail=null;
let chosenFileName='';

// ── HELPERS ──
function genId(){return 'sv'+Date.now().toString(36);}
function initials(name){return name.split(' ').map(w=>w[0]).join('').toUpperCase().slice(0,2);}
function avatarColor(name){const colors=['#1a6b6b','#c0392b','#d4831a','#5342a6','#2a9d8f','#0d0d0d','#2d7a3a'];let h=0;for(let c of name)h+=c.charCodeAt(0);return colors[h%colors.length];}
function timeAgo(ts){const d=(Date.now()-ts)/1000;if(d<60)return 'Just now';if(d<3600)return Math.floor(d/60)+'m ago';if(d<86400)return Math.floor(d/3600)+'h ago';if(d<604800)return Math.floor(d/86400)+'d ago';return new Date(ts).toLocaleDateString('en-IN',{day:'numeric',month:'short',year:'numeric'});}
function typeClass(t){return{Lecture:'type-notes','Lecture Notes':'type-notes','Past Exam':'type-exam','Reference':'type-ref','Slides':'type-slides','Study Guide':'type-guide'}[t]||'type-notes';}
function typeIcon(t){return{'Lecture Notes':'📝','Past Exam':'📋','Reference':'📚','Slides':'🖥','Study Guide':'📖'}[t]||'📄';}
function isSaved(id){return DB.savedIds.includes(id);}
function toggleSave(id,e){if(e)e.stopPropagation();if(isSaved(id)){DB.savedIds=DB.savedIds.filter(s=>s!==id);toast('Removed from saved','');}else{DB.savedIds.push(id);toast('Saved! ✓','success');}saveDB(DB);updateCounts();renderSaved();}
function incrementDownload(id){DB.downloads[id]=(DB.downloads[id]||0)+1;const r=DB.resources.find(x=>x.id===id);if(r)r.downloads=DB.downloads[id];saveDB(DB);}
function uniqueColleges(){return[...new Set(DB.resources.map(r=>r.college))].sort();}
function uniqueSubjects(){return[...new Set(DB.resources.map(r=>r.subject))].sort();}
function filteredResources(){
  let list=[...DB.resources];
  const q=(document.getElementById('searchInput')||{}).value?.toLowerCase()||'';
  const t=(document.getElementById('searchType')||{}).value||'';
  if(q)list=list.filter(r=>r.title.toLowerCase().includes(q)||r.college.toLowerCase().includes(q)||(r.course||'').toLowerCase().includes(q)||(r.subject||'').toLowerCase().includes(q));
  if(t)list=list.filter(r=>r.type===t);
  if(filterSubject&&filterSubject!=='All')list=list.filter(r=>r.subject===filterSubject);
  if(filterCollege&&filterCollege!=='All')list=list.filter(r=>r.college===filterCollege);
  if(filterType&&filterType!=='All')list=list.filter(r=>r.type===filterType);
  if(currentSort==='popular')list.sort((a,b)=>b.downloads-a.downloads);
  else if(currentSort==='rating')list.sort((a,b)=>b.rating-a.rating);
  else list.sort((a,b)=>b.createdAt-a.createdAt);
  return list;
}

// ── CARD HTML ──
function cardHTML(r,small){
  const sv=isSaved(r.id);
  return`<div class="resource-card${small?' small-card':''}" onclick="showDetail('${r.id}')">
    <span class="card-type ${typeClass(r.type)}">${typeIcon(r.type)} ${r.type}</span>
    <div class="card-title">${r.title}</div>
    <div class="card-meta">${r.course?r.course+' · ':''}${r.college}${r.semester?' · '+r.semester:''}<br>${r.subject} · ${r.downloads.toLocaleString()} downloads · ${timeAgo(r.createdAt)}</div>
    <div class="card-rating">${'★'.repeat(Math.round(r.rating))}${'☆'.repeat(5-Math.round(r.rating))} ${r.rating.toFixed(1)}</div>
    <div class="card-footer">
      <div class="card-author"><div class="avatar" style="background:${avatarColor(r.author)}">${initials(r.author)}</div>${r.author}</div>
      <div class="card-actions">
        <button class="icon-btn${sv?' saved':''}" onclick="toggleSave('${r.id}',event)" title="${sv?'Unsave':'Save'}">${sv?'🔖':'🏷'}</button>
        <button class="icon-btn" onclick="downloadResource('${r.id}',event)" title="Download">⬇</button>
      </div>
    </div>
  </div>`;}


// ── DOWNLOAD: generates a real PDF using jsPDF (loaded dynamically) ──
function downloadResource(id, e) {
  if (e) e.stopPropagation();
  const r = DB.resources.find(x => x.id === id);
  if (!r) return;

  // Show progress modal
  showDlModal();

  // Load jsPDF dynamically then generate
  loadjsPDF(() => {
    try {
      generatePDF(r);
      incrementDownload(id);
      updateStats();
      hideDlModal();
      toast('✓ PDF downloaded!', 'success');
    } catch(err) {
      hideDlModal();
      toast('Download failed: ' + err.message, 'error');
    }
  });
}

function showDlModal() {
  let m = document.getElementById('dlModal');
  if (!m) {
    m = document.createElement('div');
    m.id = 'dlModal';
    m.style.cssText = 'position:fixed;inset:0;background:rgba(13,13,13,.8);z-index:600;display:flex;align-items:center;justify-content:center;';
    m.innerHTML = `<div style="background:#f5f0e8;border:2px solid #0d0d0d;padding:48px 44px;max-width:400px;width:90%;text-align:center;">
      <div style="font-size:2.4rem;margin-bottom:16px;display:inline-block;animation:spin 1s linear infinite;">⏳</div>
      <div style="font-family:Georgia,serif;font-size:1.2rem;font-weight:700;margin-bottom:8px;">Building your PDF…</div>
      <div style="font-size:.75rem;color:#6b6457;margin-bottom:20px;">Generating study content, please wait.</div>
      <div style="height:3px;background:#d4c9b0;"><div id="dlBar" style="height:100%;background:#d4831a;width:0%;transition:width .5s;"></div></div>
    </div>`;
    document.body.appendChild(m);
  }
  m.style.display = 'flex';
  // animate bar
  let w = 0;
  m._timer = setInterval(() => {
    w = Math.min(w + Math.random() * 18, 88);
    const bar = document.getElementById('dlBar');
    if (bar) bar.style.width = w + '%';
  }, 400);
}

function hideDlModal() {
  const m = document.getElementById('dlModal');
  if (!m) return;
  clearInterval(m._timer);
  const bar = document.getElementById('dlBar');
  if (bar) bar.style.width = '100%';
  setTimeout(() => { m.style.display = 'none'; }, 350);
}

function loadjsPDF(cb) {
  if (window.jspdf) { cb(); return; }
  const s = document.createElement('script');
  s.src = 'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js';
  s.onload = () => cb();
  s.onerror = () => { hideDlModal(); toast('Could not load PDF library. Check internet.', 'error'); };
  document.head.appendChild(s);
}

function generatePDF(r) {
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });

  const typeColors = {
    'Lecture Notes': [26, 107, 107],
    'Past Exam':     [192, 57, 43],
    'Reference':     [212, 131, 26],
    'Slides':        [83, 66, 166],
    'Study Guide':   [45, 122, 58],
  };
  const accent = typeColors[r.type] || [13, 13, 13];
  const W = 210, margin = 18, cw = W - margin * 2;
  const now = new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' });

  // ── HEADER block ──
  doc.setFillColor(13, 13, 13);
  doc.rect(0, 0, W, 52, 'F');

  // accent strip
  doc.setFillColor(...accent);
  doc.rect(0, 52, W, 3, 'F');

  // type label
  doc.setTextColor(...accent);
  doc.setFontSize(8);
  doc.setFont('helvetica', 'bold');
  doc.text(('StudyVault  ·  ' + r.type).toUpperCase(), margin, 14);

  // title
  doc.setTextColor(245, 240, 232);
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  const titleLines = doc.splitTextToSize(r.title, cw);
  doc.text(titleLines, margin, 26);

  // meta row
  doc.setFontSize(7.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(160, 150, 135);
  const metaParts = [r.college, r.subject, r.course, r.semester, r.author].filter(Boolean);
  doc.text(metaParts.join('  ·  '), margin, 47);

  // ── CONTENT ──
  let y = 68;

  function checkPage(need = 10) {
    if (y + need > 275) { doc.addPage(); y = 20; }
  }

  function drawSectionLine(text) {
    checkPage(14);
    doc.setFillColor(...accent);
    doc.rect(margin, y, cw, 0.5, 'F');
    y += 4;
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(...accent);
    doc.text(text, margin, y);
    y += 6;
  }

  function drawSubHeading(text) {
    checkPage(10);
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(13, 13, 13);
    doc.text(text, margin, y);
    y += 5;
  }

  function drawBody(text) {
    checkPage(8);
    doc.setFontSize(9.5);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(40, 40, 40);
    const lines = doc.splitTextToSize(text, cw);
    lines.forEach(line => {
      checkPage(6);
      doc.text(line, margin, y);
      y += 5.2;
    });
  }

  function drawBullet(text) {
    checkPage(7);
    doc.setFillColor(...accent);
    doc.circle(margin + 1.5, y - 1.5, 1, 'F');
    doc.setFontSize(9.5);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(40, 40, 40);
    const lines = doc.splitTextToSize(text, cw - 6);
    doc.text(lines[0], margin + 5, y);
    y += 5;
    for (let i = 1; i < lines.length; i++) {
      checkPage(5);
      doc.text(lines[i], margin + 5, y);
      y += 5;
    }
  }

  // Generate rich content based on type
  const sections = buildContentSections(r);
  sections.forEach(section => {
    if (section.type === 'heading') drawSectionLine(section.text);
    else if (section.type === 'subheading') drawSubHeading(section.text);
    else if (section.type === 'bullet') drawBullet(section.text);
    else if (section.type === 'body') drawBody(section.text);
    else if (section.type === 'space') { y += 4; }
  });

  // ── FOOTER on every page ──
  const totalPages = doc.getNumberOfPages();
  for (let p = 1; p <= totalPages; p++) {
    doc.setPage(p);
    doc.setFillColor(13, 13, 13);
    doc.rect(0, 287, W, 10, 'F');
    doc.setFontSize(7);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(130, 120, 110);
    doc.text('StudyVault · College Knowledge Repository · ' + now, margin, 293);
    doc.setTextColor(160, 150, 135);
    doc.text(`Page ${p} of ${totalPages}`, W - margin, 293, { align: 'right' });
  }

  const filename = r.title.replace(/[^a-z0-9]/gi, '_').toLowerCase().slice(0, 60) + '.pdf';
  doc.save(filename);
}

// Builds rich structured content sections from resource metadata
function buildContentSections(r) {
  const sections = [];
  const add = (type, text) => sections.push({ type, text });

  add('heading', 'Resource Overview');
  add('body', `This ${r.type.toLowerCase()} covers ${r.subject} for the course ${r.course || r.subject} at ${r.college}.${r.desc ? ' ' + r.desc : ''}`);
  add('space');

  if (r.type === 'Lecture Notes') {
    add('heading', 'Introduction & Learning Objectives');
    add('body', `By the end of these notes, you will understand the core concepts of ${r.title}, be able to apply theoretical frameworks to practical problems, and be prepared for examinations on this topic.`);
    add('space');
    add('subheading', 'Key Definitions');
    getDefinitions(r.subject).forEach(d => add('bullet', d));
    add('space');
    add('heading', 'Core Concepts');
    getConcepts(r.subject).forEach(c => { add('subheading', c.heading); add('body', c.body); add('space'); });
    add('heading', 'Important Formulas & Rules');
    getFormulas(r.subject).forEach(f => add('bullet', f));
    add('space');
    add('heading', 'Worked Examples');
    getExamples(r.subject).forEach((ex, i) => { add('subheading', `Example ${i+1}: ${ex.q}`); add('body', ex.a); add('space'); });
    add('heading', 'Summary & Revision Checklist');
    getSummary(r.subject).forEach(s => add('bullet', s));

  } else if (r.type === 'Past Exam') {
    add('heading', 'Examination Instructions');
    add('body', `Time allowed: 3 hours. Answer ALL questions in Section A and any THREE questions from Section B. Each question carries the marks indicated. Calculators are permitted unless otherwise stated.`);
    add('space');
    add('heading', 'Section A — Short Answer Questions (40 Marks)');
    getExamQs(r.subject, 'short').forEach((q, i) => {
      add('subheading', `Q${i+1}. ${q.q} [${q.marks} marks]`);
      add('body', `Model Answer: ${q.a}`);
      add('space');
    });
    add('heading', 'Section B — Long Answer Questions (60 Marks)');
    getExamQs(r.subject, 'long').forEach((q, i) => {
      add('subheading', `Q${i+5}. ${q.q} [${q.marks} marks]`);
      add('body', `Model Answer: ${q.a}`);
      add('space');
    });
    add('heading', 'Marking Scheme Notes');
    add('bullet', 'Award full marks only when working is clearly shown.');
    add('bullet', 'Partial credit of 50% may be awarded for correct method with arithmetic error.');
    add('bullet', 'Accept equivalent alternative methods that reach the correct answer.');

  } else if (r.type === 'Reference') {
    add('heading', 'Quick Reference Guide');
    add('body', `This reference material covers essential formulas, definitions, and key facts for ${r.subject}.`);
    add('space');
    add('heading', 'Core Definitions');
    getDefinitions(r.subject).forEach(d => add('bullet', d));
    add('space');
    add('heading', 'Essential Formulas');
    getFormulas(r.subject).forEach(f => add('bullet', f));
    add('space');
    add('heading', 'Key Theorems & Principles');
    getTheorems(r.subject).forEach(t => { add('subheading', t.name); add('body', t.desc); add('space'); });
    add('heading', 'Common Mistakes to Avoid');
    getMistakes(r.subject).forEach(m => add('bullet', m));

  } else if (r.type === 'Slides') {
    add('heading', 'Slide Deck Contents');
    getSlides(r.subject).forEach((slide, i) => {
      add('subheading', `Slide ${i+1}: ${slide.title}`);
      slide.points.forEach(p => add('bullet', p));
      add('space');
    });
    add('heading', 'Speaker Notes');
    add('body', `These slides accompany the lecture for ${r.title}. Presenters should spend approximately 3–5 minutes per slide, ensuring students have time to take notes. Key slides to emphasise are slides 2, 5, and 7 which cover the most examinable content.`);

  } else if (r.type === 'Study Guide') {
    add('heading', 'How to Use This Guide');
    add('body', `Work through each section in order. Complete the practice questions before checking answers. Spend extra time on topics marked with ★ as these are highly examinable.`);
    add('space');
    add('heading', 'Topic Summaries');
    getConcepts(r.subject).forEach(c => { add('subheading', '★ ' + c.heading); add('body', c.body); add('space'); });
    add('heading', 'Practice Questions');
    getExamQs(r.subject, 'short').forEach((q, i) => { add('subheading', `Practice Q${i+1}: ${q.q}`); add('body', `Answer: ${q.a}`); add('space'); });
    add('heading', 'Exam Tips & Strategies');
    add('bullet', 'Read every question carefully before answering — note the marks allocated.');
    add('bullet', 'Attempt all questions — partial credit is available for method.');
    add('bullet', 'Use headings and structured answers for long-form questions.');
    add('bullet', 'Review your answers with 10 minutes remaining in the exam.');
    add('bullet', 'Focus revision on the core concepts and formulas in this guide.');
  }

  add('space');
  add('heading', 'Additional Notes');
  add('body', `This document was generated by StudyVault from the resource: "${r.title}" contributed by ${r.author} for ${r.college}.`);

  return sections;
}

// Subject-specific content generators
function getDefinitions(subject) {
  const map = {
    'Computer Science': ['Algorithm: A step-by-step procedure for solving a problem or accomplishing a task.', 'Data Structure: A way of organising data in a computer so it can be accessed and updated efficiently.', 'Recursion: A method where a function calls itself to solve a smaller version of the same problem.', 'Complexity (Big-O): A notation describing the upper bound on time/space an algorithm needs relative to input size.', 'Concurrency: The ability of a program to execute multiple computations simultaneously.'],
    'Mathematics': ['Derivative: The rate at which a function changes at any given point; the slope of the tangent.', 'Integral: The area under a curve; the reverse operation of differentiation.', 'Vector Space: A set of elements (vectors) that can be added together and scaled by scalars.', 'Eigenvalue: A scalar λ such that Av = λv for a square matrix A and non-zero vector v.', 'Limit: The value a function approaches as the input approaches a given value.'],
    'Engineering': ['Stress: Internal resisting force per unit area within a deformable body (σ = F/A).', 'Strain: Deformation of a material compared to its original dimensions (ε = ΔL/L).', 'Torque: Rotational force measured as force × perpendicular distance from the axis.', 'Reynolds Number: Dimensionless number indicating whether flow is laminar or turbulent (Re = ρvD/μ).', 'Thermodynamic System: A region of space defined for analysis, separated from surroundings by a boundary.'],
    'Medicine': ['Homeostasis: The process by which the body maintains a stable internal environment.', 'Pathogen: A microorganism that causes disease in a host organism.', 'Diagnosis: The identification of an illness or condition based on signs, symptoms and investigations.', 'Aetiology: The cause or set of causes of a disease or condition.', 'Prognosis: The likely outcome or course of a disease and the chance of recovery.'],
    'Physics': ['Force: A push or pull acting on an object, measured in Newtons (F = ma).', 'Energy: The capacity to do work, existing in forms including kinetic, potential, and thermal.', 'Wave: A disturbance that transfers energy through a medium without transferring matter.', 'Electric Field: A region around a charged particle within which a force acts on another charge.', 'Entropy: A measure of disorder or randomness in a thermodynamic system.'],
    'Economics': ['Elasticity: The responsiveness of demand or supply to a change in price or income.', 'Market Equilibrium: The state where quantity supplied equals quantity demanded.', 'GDP: Gross Domestic Product — the total monetary value of goods and services produced in a country.', 'Inflation: A general increase in prices and fall in the purchasing power of money.', 'Opportunity Cost: The value of the best alternative foregone when making an economic decision.'],
    'Law': ['Tort: A civil wrong that causes harm or loss, giving rise to a claim for damages.', 'Statute: A written law enacted by a legislative body.', 'Precedent: A legal principle established in a previous case that guides future decisions.', 'Burden of Proof: The obligation to prove one\'s claims to the required standard.', 'Mens Rea: The mental element of a crime — guilty mind or criminal intent.'],
    'Chemistry': ['Mole: The SI unit of amount of substance; 6.022 × 10²³ particles (Avogadro\'s number).', 'Oxidation: Loss of electrons or increase in oxidation state during a reaction.', 'Reduction: Gain of electrons or decrease in oxidation state.', 'Catalyst: A substance that increases reaction rate without being consumed in the reaction.', 'Isomer: Compounds with the same molecular formula but different structural arrangements.'],
    'Business & Management': ['ROI: Return on Investment — net profit divided by the cost of investment, expressed as a percentage.', 'SWOT: A strategic analysis framework covering Strengths, Weaknesses, Opportunities, and Threats.', 'Market Share: The portion of a market controlled by a particular company or product.', 'Stakeholder: Any party that has an interest in or is affected by a company\'s operations.', 'Cash Flow: The net amount of cash being transferred into and out of a business.'],
  };
  return map[subject] || ['Core Term 1: Definition of the foundational concept in this subject area.', 'Core Term 2: Essential vocabulary required for understanding this subject.', 'Core Term 3: Technical terminology used in professional and academic contexts.'];
}

function getFormulas(subject) {
  const map = {
    'Computer Science': ['Time Complexity — O(1) constant, O(log n) logarithmic, O(n) linear, O(n²) quadratic.', 'Binary Search: mid = (low + high) / 2; compare and recurse on left or right half.', 'Hashing: index = hash(key) % table_size', 'Graph BFS: Uses queue (FIFO). Time: O(V + E). Space: O(V).', 'Dynamic Programming: solve subproblems, store results, build up solution (memoisation or tabulation).'],
    'Mathematics': ['Derivative rules: d/dx(xⁿ) = nxⁿ⁻¹, d/dx(eˣ) = eˣ, d/dx(sin x) = cos x', 'Integration by parts: ∫u dv = uv − ∫v du', 'Chain rule: dy/dx = (dy/du) × (du/dx)', 'Quadratic formula: x = (−b ± √(b²−4ac)) / 2a', 'Euler\'s identity: eⁱᵖ + 1 = 0'],
    'Physics': ['Newton\'s 2nd Law: F = ma', 'Kinematic equations: v = u + at, s = ut + ½at², v² = u² + 2as', 'Work-Energy theorem: W = ΔKE = ½mv² − ½mu²', 'Coulomb\'s Law: F = kq₁q₂/r²', 'Wave speed: v = fλ'],
    'Engineering': ['Stress: σ = F/A (Pa or N/m²)', 'Strain: ε = ΔL/L (dimensionless)', 'Young\'s Modulus: E = σ/ε', 'Power: P = Fv = τω', 'Continuity equation (fluid): A₁v₁ = A₂v₂'],
    'Chemistry': ['Ideal Gas Law: PV = nRT', 'pH = −log[H⁺]', 'Molarity: M = moles of solute / litres of solution', 'Gibbs Free Energy: ΔG = ΔH − TΔS', 'Arrhenius equation: k = Ae^(−Ea/RT)'],
  };
  return map[subject] || ['Key Formula 1: Relates the primary quantities in this subject.', 'Key Formula 2: Used for quantitative analysis and problem solving.', 'Key Formula 3: Derived from first principles; must be understood, not just memorised.'];
}

function getConcepts(subject) {
  const map = {
    'Computer Science': [
      { heading: 'Data Structures', body: 'Efficient data organisation underpins all performant software. Arrays offer O(1) access; linked lists allow dynamic resizing; trees enable hierarchical search in O(log n); hash tables provide near-O(1) lookup for key-value storage.' },
      { heading: 'Algorithm Design Paradigms', body: 'Divide and conquer splits problems into subproblems (e.g. merge sort). Greedy algorithms make locally optimal choices. Dynamic programming avoids recomputation by storing subproblem results. Backtracking explores candidates and abandons those that fail constraints.' },
      { heading: 'Operating Systems', body: 'OS manages process scheduling (FCFS, Round Robin, priority), memory through paging and segmentation, and I/O via device drivers. Deadlock arises when processes wait circularly for resources — avoided by prevention, avoidance (Banker\'s algorithm), or detection and recovery.' },
    ],
    'Mathematics': [
      { heading: 'Differential Calculus', body: 'Differentiation measures instantaneous rate of change. The derivative f\'(x) gives slope at each point. Product rule: (uv)\' = u\'v + uv\'. Quotient rule: (u/v)\' = (u\'v − uv\')/v². Applications: optimisation, related rates, curve sketching.' },
      { heading: 'Integral Calculus', body: 'Integration is the reverse of differentiation and measures accumulated quantity (area, volume, displacement). Definite integrals have bounds; indefinite integrals produce families of functions. Fundamental Theorem links the two operations.' },
      { heading: 'Linear Algebra', body: 'Vectors, matrices and linear transformations form the core. Matrix multiplication is not commutative. Determinant gives area/volume scaling; inverse exists iff det ≠ 0. Eigenvalues encode important structural properties used in PCA, graph theory, and physics.' },
    ],
  };
  return map[subject] || [
    { heading: 'Foundational Theory', body: `The theoretical basis of ${subject} rests on well-established principles developed over decades. Understanding these principles provides the foundation for all applied work in this field.` },
    { heading: 'Applied Methods', body: 'Practical applications of theory require both conceptual understanding and computational skill. Work through solved examples to develop fluency with standard problem-solving methods.' },
    { heading: 'Advanced Topics', body: 'Building on the core material, advanced topics extend the theory to more complex or specialised contexts. These areas are active in current research and professional practice.' },
  ];
}

function getExamples(subject) {
  const common = [
    { q: 'Basic Application Problem', a: 'Step 1: Identify the relevant concept and formula. Step 2: Extract given values from the problem. Step 3: Substitute into the formula. Step 4: Solve and verify units/dimensions. Step 5: State the final answer clearly.' },
    { q: 'Analysis and Interpretation', a: 'Begin by defining terms. Identify key relationships. Apply relevant principles systematically. Interpret your numerical or qualitative result in context. Consider edge cases or limitations of your approach.' },
  ];
  return common;
}

function getExamQs(subject, type) {
  if (type === 'short') return [
    { q: `Define the three most important terms in ${subject} and give an example of each.`, marks: 6, a: `Full marks require precise definitions with correct technical vocabulary and a relevant, accurate example for each term. Vague or circular definitions score 0.` },
    { q: `Explain the relationship between the two core concepts studied in this course.`, marks: 8, a: `A complete answer identifies both concepts, explains each clearly, then articulates how they are connected with evidence or derivation where appropriate.` },
    { q: `Calculate the value given: [problem based on standard course formula]`, marks: 6, a: `Show formula used, correct substitution of values, working, and final answer with units. Marks: formula (2), substitution (2), answer (2).` },
    { q: `Compare and contrast two major approaches to the central problem in ${subject}.`, marks: 10, a: `Award marks for: identifying each approach (2), describing each clearly (4), meaningful comparison with specific criteria (4). Award 0 for vague generalisations.` },
  ];
  return [
    { q: `"${subject} is fundamentally about [core debate]." Critically evaluate this claim with reference to theory and evidence.`, marks: 20, a: `Strong answers will: define key terms (3 marks), outline the main argument (4), present supporting evidence (6), raise counter-arguments (4), conclude with a reasoned position (3). Penalise assertions without evidence.` },
    { q: `A real-world scenario: [contextual problem requiring extended analysis]. Recommend a course of action and justify your reasoning.`, marks: 20, a: `Award marks for: problem analysis (5), application of relevant theory/method (7), recommendation with justification (5), awareness of limitations (3). Strong answers reference specific concepts from the course.` },
    { q: `Trace the development of the most important idea in ${subject} and assess its significance today.`, marks: 20, a: `Historical accuracy (5), conceptual clarity (5), significance argued with evidence (6), contemporary relevance (4). Penalise chronological narrative without analysis.` },
  ];
}

function getTheorems(subject) {
  return [
    { name: `Fundamental Theorem of ${subject}`, desc: `The central theoretical result that unifies the core concepts of the subject. Understanding and being able to state, prove (where required), and apply this theorem is essential for examination success.` },
    { name: 'Principle of Conservation', desc: 'In a closed system, the total quantity of the conserved property remains constant over time. This principle generates many useful relationships between observable quantities.' },
    { name: 'Boundary Conditions and Constraints', desc: 'Solutions must satisfy given boundary conditions. Always check that your answer is consistent with stated constraints — a common source of errors in examinations.' },
  ];
}

function getMistakes(subject) {
  return [
    `Skipping units — always carry units through calculations and check dimensional consistency.`,
    `Memorising formulas without understanding derivations — you cannot apply what you do not understand.`,
    `Confusing related but distinct concepts — use precise terminology as defined in lectures.`,
    `Not showing working in exams — method marks are available even when the final answer is wrong.`,
    `Ignoring negative signs and special cases — always consider boundary values and edge cases.`,
    `Overcomplicating solutions — check whether a simpler approach applies before using advanced methods.`,
  ];
}

function getSummary(subject) {
  return [
    `I can define all key terms for ${subject} accurately and in my own words.`,
    `I understand the derivation and application of core formulas.`,
    `I have worked through at least 3 examples for each major topic.`,
    `I can compare and contrast the main approaches/theories in this subject.`,
    `I have reviewed past exam questions and can identify what each question is testing.`,
    `I understand where each topic fits within the overall structure of the course.`,
  ];
}

function getSlides(subject) {
  return [
    { title: 'Introduction & Motivation', points: [`Why ${subject} matters in theory and practice`, 'Course structure and key learning outcomes', 'Assessment overview and exam format', 'Recommended resources and reading list'] },
    { title: 'Core Concepts — Part 1', points: ['Definition of the primary concept', 'Historical development and context', 'Key assumptions and limitations', 'Relationship to adjacent fields'] },
    { title: 'Core Concepts — Part 2', points: ['Mathematical or analytical framework', 'Visual representations and diagrams', 'Step-by-step worked example', 'Common misconceptions addressed'] },
    { title: 'Applied Methods', points: ['Standard problem-solving procedure', 'Tools and techniques used in practice', 'Case study: real-world application', 'Discussion: what can go wrong and why'] },
    { title: 'Summary & Exam Preparation', points: ['Key takeaways — three things to remember', 'Most frequently examined topics', 'Recommended practice questions', 'Office hours and support resources'] },
  ];
}

// ── UPDATE COUNTS ──
function updateCounts(){
  document.getElementById('navCount').textContent=DB.resources.length;
  document.getElementById('savedCount').textContent=DB.savedIds.length;
  updateStats();
}
function updateStats(){
  const notes=DB.resources.filter(r=>r.type==='Lecture Notes').length;
  const exams=DB.resources.filter(r=>r.type==='Past Exam').length;
  const colleges=COLLEGES.length;
  const downloads=DB.resources.reduce((s,r)=>s+r.downloads,0);
  document.getElementById('statNotes').textContent=notes;
  document.getElementById('statExams').textContent=exams;
  document.getElementById('statColleges').textContent=colleges+'+';
  document.getElementById('statStudents').textContent=downloads.toLocaleString();
}

// ── HOME ──
function renderHome(){
  updateStats();
  const recent=[...DB.resources].sort((a,b)=>b.createdAt-a.createdAt).slice(0,6);
  const featured=DB.resources.find(r=>r.featured)||recent[0];
  let html='';
  if(featured)html+=`<div class="featured-banner">
    <div><div class="featured-badge">Featured Resource of the Week</div>
    <div class="featured-title-text">${featured.title}</div>
    <div class="featured-meta-text">${featured.college} · ${featured.course||featured.subject} · ${featured.downloads.toLocaleString()} downloads</div></div>
    <button class="featured-btn" onclick="showDetail('${featured.id}')">View →</button>
  </div>`;
  recent.forEach(r=>{html+=cardHTML(r,true);});
  document.getElementById('homeCards').innerHTML=html;
}

// ── BROWSE ──
function renderBrowse(){
  buildSidebarFilters();
  buildSubjectTags();
  const list=filteredResources();
  document.getElementById('resultsInfo').textContent=`${list.length} resource${list.length!==1?'s':''} found`;
  document.getElementById('browseGrid').innerHTML=list.length?list.map(r=>cardHTML(r)).join(''):`<div class="empty-state" style="grid-column:1/-1"><div class="empty-icon">🔍</div><div class="empty-title">No resources found</div><p class="empty-sub">Try adjusting your search or filters, or be the first to upload!</p><br><button class="btn-primary" style="margin-top:8px" onclick="navTo('upload')">Upload Resource</button></div>`;}

function buildSidebarFilters(){
  const subjects=['All',...uniqueSubjects()];
  document.getElementById('subjectFilter').innerHTML=subjects.map(s=>`<li class="${filterSubject===s?'active':''}" onclick="setSubjectFilter('${s}')">${s==='All'?'All Subjects':s}<span class="count-badge">${s==='All'?DB.resources.length:DB.resources.filter(r=>r.subject===s).length}</span></li>`).join('');
  const types=['All','Lecture Notes','Past Exam','Reference','Slides','Study Guide'];
  document.getElementById('typeFilter').innerHTML=types.map(t=>`<li class="${filterType===t?'active':''}" onclick="setTypeFilter('${t}')">${t==='All'?'All Types':t}<span class="count-badge">${t==='All'?DB.resources.length:DB.resources.filter(r=>r.type===t).length}</span></li>`).join('');
  const colleges=['All',...uniqueColleges()];
  document.getElementById('collegeFilter').innerHTML=colleges.map(c=>`<li class="${filterCollege===c?'active':''}" onclick="setCollegeFilter('${c}')" style="font-size:.7rem">${c==='All'?'All Colleges':c}<span class="count-badge">${c==='All'?DB.resources.length:DB.resources.filter(r=>r.college===c).length}</span></li>`).join('');}

function buildSubjectTags(){
  const subjects=['All',...uniqueSubjects()];
  document.getElementById('subjectTags').innerHTML=subjects.map(s=>`<button class="tag${filterSubject===s?' active':''}" onclick="setSubjectFilter('${s}')">${s==='All'?'All':s}</button>`).join('');}

function setSubjectFilter(s){filterSubject=s;renderBrowse();}
function setTypeFilter(t){filterType=t;renderBrowse();}
function setCollegeFilter(c){filterCollege=c;renderBrowse();}
function setSort(s,btn){currentSort=s;document.querySelectorAll('.sort-btn').forEach(b=>b.classList.remove('active'));btn.classList.add('active');renderBrowse();}

// ── COLLEGES ──
let currentRegion = 'All';

function renderColleges(){
  const q = (document.getElementById('collegeSearch')||{}).value?.toLowerCase()||'';

  // Build region tabs
  const regions = ['All','India','USA','UK','Australia','Canada','Europe','Asia','Middle East','Africa','Latin America'];
  document.getElementById('regionTabs').innerHTML = regions.map(r =>
    `<button class="tag${currentRegion===r?' active':''}" onclick="currentRegion='${r}';renderColleges()">${r}</button>`
  ).join('');

  // Filter from the COLLEGES master list
  let list = COLLEGES.filter(c => {
    const matchQ = !q || c.name.toLowerCase().includes(q) || c.city.toLowerCase().includes(q) || c.country.toLowerCase().includes(q);
    const matchR = currentRegion==='All' || c.region===currentRegion;
    return matchQ && matchR;
  });

  document.getElementById('collegeCount').textContent = COLLEGES.length;
  const countInfo = document.getElementById('collegesCountInfo');
  if(countInfo) countInfo.textContent = `Showing ${list.length} institution${list.length!==1?'s':''} ${currentRegion!=='All'?'in '+currentRegion:'worldwide'}`;

  const flagMap = {India:'🇮🇳',USA:'🇺🇸',UK:'🇬🇧',Australia:'🇦🇺',Canada:'🇨🇦',Switzerland:'🇨🇭',Germany:'🇩🇪',France:'🇫🇷',Netherlands:'🇳🇱',Belgium:'🇧🇪',Denmark:'🇩🇰',Sweden:'🇸🇪',Finland:'🇫🇮',Norway:'🇳🇴',Italy:'🇮🇹',Spain:'🇪🇸',Singapore:'🇸🇬',China:'🇨🇳',Japan:'🇯🇵','South Korea':'🇰🇷',Malaysia:'🇲🇾',Philippines:'🇵🇭',Thailand:'🇹🇭',Indonesia:'🇮🇩','Hong Kong':'🇭🇰',Taiwan:'🇹🇼','Sri Lanka':'🇱🇰',Bangladesh:'🇧🇩',Nepal:'🇳🇵','Saudi Arabia':'🇸🇦',Lebanon:'🇱🇧',Iran:'🇮🇷',Egypt:'🇪🇬',Qatar:'🇶🇦',UAE:'🇦🇪',Kuwait:'🇰🇼','South Africa':'🇿🇦',Nigeria:'🇳🇬',Kenya:'🇰🇪',Ghana:'🇬🇭',Uganda:'🇺🇬',Brazil:'🇧🇷',Mexico:'🇲🇽',Argentina:'🇦🇷',Chile:'🇨🇱'};

  document.getElementById('collegesGrid').innerHTML = list.length ? list.map(c => {
    const res = DB.resources.filter(r => r.college === c.name);
    const subjects = [...new Set(res.map(r => r.subject))];
    const flag = flagMap[c.country] || '🏫';
    const totalDl = res.reduce((s,r) => s+r.downloads, 0);
    return `<div class="college-card" onclick="showCollegeDetail('${encodeURIComponent(c.name)}')">
      <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px;">
        <div class="college-initial" style="flex-shrink:0;">${c.name[0]}</div>
        <div>
          <div class="college-name" style="margin-bottom:2px;">${c.name}</div>
          <div class="college-location">${flag} ${c.city}, ${c.country}</div>
        </div>
      </div>
      <div class="college-stats">
        <div><span>${res.length||0}</span>Resources</div>
        <div><span>${subjects.length||0}</span>Subjects</div>
        <div><span>${totalDl>0?totalDl.toLocaleString():'—'}</span>Downloads</div>
      </div>
    </div>`;
  }).join('') : `<div class="empty-state" style="grid-column:1/-1"><div class="empty-icon">🏫</div><div class="empty-title">No colleges found</div><p class="empty-sub">Try a different search or region.</p></div>`;
}

// ── DETAIL ──
function showDetail(id){
  currentDetailId=id;
  const r=DB.resources.find(x=>x.id===id);
  if(!r)return;
  const related=DB.resources.filter(x=>x.id!==id&&(x.subject===r.subject||x.college===r.college)).slice(0,4);
  const sv=isSaved(id);
  document.getElementById('detailContent').innerHTML=`
    <button class="detail-back" onclick="history.back()">← Back</button>
    <span class="detail-type ${typeClass(r.type)}">${typeIcon(r.type)} ${r.type}</span>
    <div class="detail-title">${r.title}</div>
    <div class="detail-meta-row">
      <div class="detail-meta-item"><span class="detail-meta-label">College</span><span class="detail-meta-val">${r.college}</span></div>
      ${r.course?`<div class="detail-meta-item"><span class="detail-meta-label">Course</span><span class="detail-meta-val">${r.course}</span></div>`:''}
      <div class="detail-meta-item"><span class="detail-meta-label">Subject</span><span class="detail-meta-val">${r.subject}</span></div>
      ${r.semester?`<div class="detail-meta-item"><span class="detail-meta-label">Period</span><span class="detail-meta-val">${r.semester}</span></div>`:''}
      <div class="detail-meta-item"><span class="detail-meta-label">Uploaded by</span><span class="detail-meta-val">${r.author}</span></div>
      <div class="detail-meta-item"><span class="detail-meta-label">Downloads</span><span class="detail-meta-val">${r.downloads.toLocaleString()}</span></div>
      <div class="detail-meta-item"><span class="detail-meta-label">Rating</span><span class="detail-meta-val">★ ${r.rating.toFixed(1)}/5.0</span></div>
      <div class="detail-meta-item"><span class="detail-meta-label">Uploaded</span><span class="detail-meta-val">${timeAgo(r.createdAt)}</span></div>
    </div>
    ${r.desc?`<p class="detail-desc">${r.desc}</p>`:''}
    <div class="detail-actions">
      <button class="btn-primary" onclick="downloadResource('${r.id}',null);updateStats();">⬇ Download Resource</button>
      <button class="btn-outline" id="saveDetailBtn" onclick="toggleSaveDetail('${r.id}')">${sv?'🔖 Saved':'🏷 Save Resource'}</button>
      <button class="btn-outline" onclick="navTo('browse');setCollegeFilter('${r.college}')">Browse ${r.college}</button>
    </div>
    <div class="detail-preview">
      <span class="detail-preview-icon">${typeIcon(r.type)}</span>
      <div class="detail-preview-text"><strong>${r.title}</strong><br>File preview is available after download. Click the button above to access the full resource.</div>
    </div>
    ${related.length?`<div class="related-section"><div class="related-title">Related Resources</div><div class="resources-grid">${related.map(x=>cardHTML(x)).join('')}</div></div>`:''}
  `;
  showPage('detail');
}

function toggleSaveDetail(id){
  toggleSave(id,null);
  const btn=document.getElementById('saveDetailBtn');
  if(btn)btn.textContent=isSaved(id)?'🔖 Saved':'🏷 Save Resource';
}

// ── COLLEGE DETAIL ──
function showCollegeDetail(encodedName){
  const name=decodeURIComponent(encodedName);
  currentCollegeDetail=name;
  const res=DB.resources.filter(r=>r.college===name);
  const subjects=[...new Set(res.map(r=>r.subject))];
  document.getElementById('collegeDetailContent').innerHTML=`
    <button class="detail-back" onclick="history.back()">← Back to Colleges</button>
    <div class="college-initial" style="width:56px;height:56px;font-size:1.5rem;margin-bottom:20px;">${name[0]}</div>
    <div class="detail-title">${name}</div>
    <div class="detail-meta-row">
      <div class="detail-meta-item"><span class="detail-meta-label">Resources</span><span class="detail-meta-val">${res.length}</span></div>
      <div class="detail-meta-item"><span class="detail-meta-label">Subjects</span><span class="detail-meta-val">${subjects.length}</span></div>
      <div class="detail-meta-item"><span class="detail-meta-label">Total Downloads</span><span class="detail-meta-val">${res.reduce((s,r)=>s+r.downloads,0).toLocaleString()}</span></div>
    </div>
    <div class="detail-actions" style="margin-bottom:36px;">
      <button class="btn-primary" onclick="navTo('browse');setCollegeFilter('${name}')">Browse All Resources →</button>
      <button class="btn-outline" onclick="navTo('upload')">+ Upload for ${name}</button>
    </div>
    ${subjects.map(s=>{
      const sRes=res.filter(r=>r.subject===s);
      return`<div style="margin-bottom:32px;"><div class="section-header" style="margin-bottom:16px;"><div class="section-title" style="font-size:1.2rem;">${s}</div><span style="font-size:.7rem;color:var(--muted)">${sRes.length} resource${sRes.length!==1?'s':''}</span></div><div class="resources-grid">${sRes.map(r=>cardHTML(r)).join('')}</div></div>`;
    }).join('')}
    ${res.length===0?`<div class="empty-state"><div class="empty-icon">📭</div><div class="empty-title">No resources yet</div><p class="empty-sub">Be the first to upload for ${name}!</p><br><button class="btn-primary" style="margin-top:8px" onclick="navTo('upload')">Upload Now</button></div>`:''}
  `;
  showPage('college-detail');
}

// ── SAVED ──
function renderSaved(){
  const savedResources=DB.resources.filter(r=>DB.savedIds.includes(r.id));
  document.getElementById('savedGrid').innerHTML=savedResources.length?savedResources.map(r=>cardHTML(r)).join(''):`<div class="empty-state"><div class="empty-icon">🏷</div><div class="empty-title">Nothing saved yet</div><p class="empty-sub">Browse resources and click the save button to bookmark them here.</p><br><button class="btn-primary" style="margin-top:8px" onclick="navTo('browse')">Browse Library</button></div>`;}

// ── UPLOAD ──
function setupUpload(){
  const dz=document.getElementById('dropZone');
  const dl=document.getElementById('collegeDatalist');
  dl.innerHTML='';
  COLLEGES.forEach(c=>{const opt=document.createElement('option');opt.value=c.name;dl.appendChild(opt);});
  dz.addEventListener('dragover',e=>{e.preventDefault();dz.classList.add('drag-over');});
  dz.addEventListener('dragleave',()=>dz.classList.remove('drag-over'));
  dz.addEventListener('drop',e=>{e.preventDefault();dz.classList.remove('drag-over');const f=e.dataTransfer.files[0];if(f)setFile(f);});
  dz.addEventListener('click',()=>{const inp=document.createElement('input');inp.type='file';inp.accept='.pdf,.docx,.pptx,.doc,.ppt';inp.onchange=()=>{if(inp.files[0])setFile(inp.files[0]);};inp.click();});
}

function setFile(f){
  chosenFileName=f.name;
  const fc=document.getElementById('fileChosen');
  document.getElementById('fileChosenName').textContent=f.name+' ('+((f.size/1024/1024).toFixed(1))+' MB)';
  fc.classList.add('show');
  document.getElementById('dropZone').querySelector('.drop-text').innerHTML=`<strong>File selected</strong>${f.name}`;
}

function submitUpload(){
  const title=document.getElementById('upTitle').value.trim();
  const college=document.getElementById('upCollege').value.trim();
  const subject=document.getElementById('upSubject').value;
  const type=document.getElementById('upType').value;
  if(!title||!college||!subject||!type){toast('Please fill in all required fields (*)','error');return;}
  const collegeName=college;
  const colData=COLLEGES.find(c=>c.name.toLowerCase()===collegeName.toLowerCase());
  const r={
    id:genId(),
    title,
    course:document.getElementById('upCourse').value.trim(),
    college:colData?colData.name:college,
    country:colData?colData.country:'Other',
    city:colData?colData.city:'',
    region:colData?colData.region:'Other',
    subject,
    type,
    author:document.getElementById('upAuthor').value.trim()||'Anonymous',
    semester:document.getElementById('upSemester').value.trim(),
    desc:document.getElementById('upDesc').value.trim(),
    downloads:0,
    rating:4.0,
    saved:false,
    featured:false,
    createdAt:Date.now()
  };
  DB.resources.unshift(r);
  DB.downloads[r.id]=0;
  saveDB(DB);
  // reset form
  ['upTitle','upCourse','upCollege','upSemester','upAuthor','upDesc'].forEach(id=>{const el=document.getElementById(id);if(el)el.value='';});
  document.getElementById('upSubject').value='';
  document.getElementById('upType').value='';
  document.getElementById('fileChosen').classList.remove('show');
  document.getElementById('dropZone').querySelector('.drop-text').innerHTML='<strong>Drag & drop your file here</strong>or click to select a file<br>PDF, DOCX, PPTX · Max 50 MB';
  chosenFileName='';
  updateCounts();
  toast('✓ Resource uploaded successfully!','success');
  setTimeout(()=>navTo('browse'),1200);
}

// ── ADMIN ──
function renderAdmin(){
  const a=DB.resources;
  document.getElementById('aStat1').textContent=a.length;
  document.getElementById('aStat2').textContent=COLLEGES.length;
  document.getElementById('aStat3').textContent=a.reduce((s,r)=>s+r.downloads,0).toLocaleString();
  document.getElementById('aStat4').textContent=DB.savedIds.length;
  document.getElementById('adminTableBody').innerHTML=a.map(r=>`<tr>
    <td style="font-family:'Fraunces',serif;font-size:.82rem;max-width:220px;">${r.title}</td>
    <td><span class="card-type ${typeClass(r.type)}" style="font-size:.58rem;">${r.type}</span></td>
    <td>${r.subject}</td>
    <td>${r.college}</td>
    <td>${r.author}</td>
    <td>${r.downloads.toLocaleString()}</td>
    <td><button class="admin-delete" onclick="deleteResource('${r.id}')">Delete</button></td>
  </tr>`).join('');
  document.getElementById('adminCollegesBody').innerHTML=COLLEGES.map(c=>{
    const res=DB.resources.filter(r=>r.college===c.name);
    const subjects=[...new Set(res.map(r=>r.subject))];
    return`<tr><td style="font-weight:500">${c.name}</td><td>${c.city}, ${c.country}</td><td>${res.length}</td><td>${subjects.slice(0,3).join(', ')}</td></tr>`;
  }).join('');
}

function adminTab(tab,btn){
  document.querySelectorAll('.admin-tab').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  document.getElementById('adminResourcesTab').style.display=tab==='resources'?'block':'none';
  document.getElementById('adminCollegesTab').style.display=tab==='colleges'?'block':'none';
}

function deleteResource(id){
  if(!confirm('Delete this resource? This cannot be undone.'))return;
  DB.resources=DB.resources.filter(r=>r.id!==id);
  DB.savedIds=DB.savedIds.filter(s=>s!==id);
  saveDB(DB);
  updateCounts();
  renderAdmin();
  toast('Resource deleted','');
}

// ── NAVIGATION ──
function showPage(name){
  document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));
  const pg=document.getElementById('page-'+name);
  if(pg){pg.classList.add('active');window.scrollTo({top:0,behavior:'smooth'});}
  document.querySelectorAll('.nav-link').forEach(b=>{b.classList.toggle('active',b.dataset.page===name);});
}

function navTo(name){
  // Auth gate for protected pages
  if(['upload','saved','admin','take-test'].includes(name) && !currentUser){
    requireAuth(name); return;
  }
  window._curPage = name;
  showPage(name);
  if(name==='browse'){renderBrowse();}
  else if(name==='home'){renderHome();}
  else if(name==='colleges'){renderColleges();}
  else if(name==='saved'){renderSaved();}
  else if(name==='admin'){renderAdmin();}
  else if(name==='upload'){setupUpload();}
  else if(name==='profile'){renderProfile();}
  else if(name==='classes'){renderClasses();}
  else if(name==='tests'){renderTests();}
  else if(name==='watch'){/* handled by watchVideo() */}
  else if(name==='take-test'){/* handled by startTest() */}
  else if(name==='test-result'){/* handled by submitTest() */}
}

// Back navigation shim
window.history.pushState=new Proxy(window.history.pushState,{apply:(t,thisArg,argArray)=>{return t.apply(thisArg,argArray);}});
window.addEventListener('popstate',()=>{if(currentDetailId)navTo('browse');else if(currentCollegeDetail)navTo('colleges');});

// ── TOAST ──
function toast(msg,type){
  const t=document.getElementById('toast');
  t.textContent=msg;
  t.className='toast show'+(type?' '+type:'');
  clearTimeout(t._t);
  t._t=setTimeout(()=>t.classList.remove('show'),3200);
}

// ── INIT ──
document.addEventListener('DOMContentLoaded',()=>{
  loadUser();
  updateNavForAuth();
  updateCounts();
  renderHome();
  // Auth overlay: close on backdrop click
  document.getElementById('authOverlay').addEventListener('click', e => {
    if (e.target === document.getElementById('authOverlay')) closeAuth();
  });
  // Keyboard shortcuts
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') closeAuth();
    if (e.key === 'Enter' && document.getElementById('authOverlay').classList.contains('active')) {
      const panels = ['panelLogin','panelSignup','panelForgot','panelPhone','panelSuccess'];
      const active = panels.map(id=>document.getElementById(id)).find(p=>p&&p.style.display!=='none');
      if (active?.id === 'panelLogin') doLogin();
      else if (active?.id === 'panelSignup') doSignup();
    }
  });
});

// ═══════════════════════════════════════════
//  AUTH SYSTEM
// ═══════════════════════════════════════════
//  AUTH SYSTEM — Full Login / Signup / Profile
// ═══════════════════════════════════════════
const AUTH_KEY = 'studyvault_user';
const USERS_KEY = 'studyvault_users'; // stores registered email accounts
let currentUser = null;
let pendingNavTarget = null;

/* ── Persist user accounts in sessionStorage ── */
function getUsers() {
  try { return JSON.parse(sessionStorage.getItem(USERS_KEY) || '{}'); } catch(e) { return {}; }
}
function saveUsers(users) {
  try { sessionStorage.setItem(USERS_KEY, JSON.stringify(users)); } catch(e) {}
}

function loadUser() {
  try { const u = sessionStorage.getItem(AUTH_KEY); if (u) currentUser = JSON.parse(u); } catch(e) {}
}
function saveUser(u) {
  currentUser = u;
  try { sessionStorage.setItem(AUTH_KEY, JSON.stringify(u)); } catch(e) {}
}
function clearUser() {
  currentUser = null;
  try { sessionStorage.removeItem(AUTH_KEY); } catch(e) {}
}

function userInitials(u) {
  if (!u) return '?';
  return ((u.firstName||'')[0]||(u.name||'?')[0]).toUpperCase() + ((u.lastName||'')[0]||'').toUpperCase();
}

/* ── NAV UPDATE ── */
function updateNavForAuth() {
  const area = document.getElementById('navUserArea');
  const loginBtn = document.getElementById('navLoginBtn');
  if (!area) return;
  if (currentUser) {
    const col = avatarColor(currentUser.name || currentUser.email);
    const providerIcon = {'Google':'🔵','Facebook':'🔷','GitHub':'⚫','Microsoft':'🔲','Apple':'⬛','Twitter / X':'🐦','LinkedIn':'🔗','Phone':'📱','Email':'✉️'}[currentUser.provider] || '👤';
    area.innerHTML = `
      <div class="nav-user">
        <div class="nav-avatar" style="background:${col}" onclick="navTo('profile')" title="My Profile">${userInitials(currentUser)}</div>
        <span class="nav-username" onclick="navTo('profile')">${currentUser.firstName || currentUser.name.split(' ')[0]}</span>
        <button class="nav-logout" onclick="doLogout()">Sign out</button>
      </div>`;
    if (loginBtn) loginBtn.style.display = 'none';
  } else {
    area.innerHTML = `<button class="nav-cta" onclick="requireAuth('upload')">+ Upload</button>`;
    if (loginBtn) loginBtn.style.display = '';
  }
}

/* ── OPEN / CLOSE ── */
function openAuth(panel = 'login') {
  showPanel(panel);
  document.getElementById('authOverlay').classList.add('active');
  document.body.style.overflow = 'hidden';
  // populate college autocomplete
  const dl = document.getElementById('authCollegeList');
  if (dl && !dl.children.length) {
    COLLEGES.forEach(c => { const o = document.createElement('option'); o.value = c.name; dl.appendChild(o); });
  }
  // reset OTP state
  otpSent = false;
  document.getElementById('otpSection') && (document.getElementById('otpSection').style.display = 'none');
  document.getElementById('phoneNextBtn') && (document.getElementById('phoneNextBtn').textContent = 'Send OTP →');
}

function closeAuth() {
  document.getElementById('authOverlay').classList.remove('active');
  document.body.style.overflow = '';
  pendingNavTarget = null;
  clearAuthErrors();
}


/* ── PANEL SWITCHING ── */
function showPanel(name) {
  const panels = ['login','signup','forgot','phone','success'];
  panels.forEach(p => {
    const el = document.getElementById('panel' + p.charAt(0).toUpperCase() + p.slice(1));
    if (el) el.style.display = (p === name) ? '' : 'none';
  });
  // Update modal title
  const titles = {login:'Welcome back',signup:'Join StudyVault',forgot:'Reset password',phone:'Phone sign-in',success:'You\'re in!'};
  const titleEl = document.getElementById('authDynTitle');
  if (titleEl) titleEl.textContent = titles[name] || '';
}

/* ── SOCIAL LOGIN ── */
const SOCIAL_NAMES = [
  ['Arjun','Kumar'],['Priya','Sharma'],['Rahul','Verma'],['Neha','Patel'],
  ['Kavya','Singh'],['Amit','Nair'],['Divya','Menon'],['Riya','Joshi'],
  ['Siddharth','Rao'],['Ananya','Iyer'],['Vikram','Menon'],['Shreya','Das'],
  ['Karthik','Krishnan'],['Pooja','Reddy'],['Aditya','Gupta'],['Meera','Pillai']
];

function socialLogin(provider, btnEl) {
  const btn = btnEl || event?.currentTarget;
  if (!btn) return;
  const orig = btn.innerHTML;
  btn.disabled = true;
  btn.innerHTML = `<span style="display:inline-flex;align-items:center;gap:8px;"><span style="animation:spin .8s linear infinite;display:inline-block;">⏳</span> Connecting to ${provider}…</span>`;

  setTimeout(() => {
    const [fn, ln] = SOCIAL_NAMES[Math.floor(Math.random() * SOCIAL_NAMES.length)];
    const domain = {Google:'gmail.com',Facebook:'facebook.com',GitHub:'github.com',Microsoft:'outlook.com',Apple:'icloud.com','Twitter / X':'twitter.com',LinkedIn:'linkedin.com'}[provider] || 'example.com';
    const user = {
      name: fn + ' ' + ln,
      firstName: fn,
      lastName: ln,
      email: fn.toLowerCase() + '.' + ln.toLowerCase() + '@' + domain,
      college: COLLEGES[Math.floor(Math.random() * 80)].name,
      provider,
      avatar: null,
      bio: 'Student at ' + COLLEGES[Math.floor(Math.random() * 80)].name,
      joinedAt: Date.now(),
    };
    saveUser(user);
    closeAuth();
    updateNavForAuth();
    showSuccessToast(fn, provider);
    btn.disabled = false;
    btn.innerHTML = orig;
    if (pendingNavTarget) { const t = pendingNavTarget; pendingNavTarget = null; navTo(t); }
  }, 1400);
}

function showSuccessToast(name, provider) {
  toast(`🎉 Welcome, ${name}! Signed in via ${provider}.`, 'success');
}

/* ── PHONE / OTP ── */
let otpSent = false;
let generatedOTP = '';

function handlePhoneNext() {
  const phone = document.getElementById('phoneNumber').value.trim();
  if (!phone || phone.replace(/\D/g,'').length < 10) {
    document.getElementById('phoneNumber').classList.add('error');
    document.getElementById('phoneErr').textContent = 'Enter a valid 10-digit phone number.';
    document.getElementById('phoneErr').classList.add('show');
    return;
  }
  if (!otpSent) {
    // Generate 6-digit OTP and "send" it
    generatedOTP = String(Math.floor(100000 + Math.random() * 900000));
    otpSent = true;
    document.getElementById('otpSection').style.display = '';
    document.getElementById('phoneNextBtn').textContent = 'Verify OTP →';
    document.getElementById('phoneErr').classList.remove('show');
    document.getElementById('phoneNumber').classList.remove('error');
    // Show the OTP in a hint (demo only — in production this would be SMS)
    document.getElementById('otpHint').textContent = `Demo OTP: ${generatedOTP}`;
    toast('📱 OTP sent to ' + phone, 'success');
  } else {
    const entered = document.getElementById('otpInput').value.trim();
    if (entered !== generatedOTP) {
      document.getElementById('otpInput').classList.add('error');
      document.getElementById('otpErr').textContent = 'Incorrect OTP. Please try again.';
      document.getElementById('otpErr').classList.add('show');
      return;
    }
    // OTP correct — log in
    const user = {
      name: 'Phone User',
      firstName: 'Phone',
      lastName: 'User',
      email: phone + '@sms.studyvault.in',
      phone,
      college: '',
      provider: 'Phone',
      joinedAt: Date.now(),
    };
    saveUser(user);
    closeAuth();
    updateNavForAuth();
    showSuccessToast('there', 'Phone OTP');
    otpSent = false;
    if (pendingNavTarget) { const t = pendingNavTarget; pendingNavTarget = null; navTo(t); }
  }
}

/* ── EMAIL LOGIN ── */
function doLogin() {
  clearAuthErrors();
  const email = document.getElementById('loginEmail').value.trim();
  const pwd = document.getElementById('loginPwd').value;
  let ok = true;
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    markErr('loginEmail', 'loginEmailErr', 'Please enter a valid email address.'); ok = false;
  }
  if (!pwd || pwd.length < 4) {
    markErr('loginPwd', 'loginPwdErr', 'Please enter your password.'); ok = false;
  }
  if (!ok) return;

  const btn = document.getElementById('loginSubmit');
  setLoading(btn, 'Signing in…');

  setTimeout(() => {
    const users = getUsers();
    // Check if account exists
    if (users[email]) {
      if (users[email].pwd !== btoa(pwd)) {
        markErr('loginPwd', 'loginPwdErr', 'Incorrect password. Try again or reset it.');
        resetBtn(btn, 'Sign In →');
        return;
      }
      const u = users[email];
      saveUser(u);
    } else {
      // Auto-create account on first login (guest-style)
      const parts = email.split('@')[0].split(/[._-]/);
      const fn = cap(parts[0] || 'Student');
      const ln = cap(parts[1] || '');
      const u = { name:(fn+' '+ln).trim(), firstName:fn, lastName:ln, email, college:'', provider:'Email', joinedAt:Date.now() };
      saveUser(u);
    }
    closeAuth();
    updateNavForAuth();
    toast('✓ Welcome back, ' + (currentUser.firstName || 'there') + '!', 'success');
    resetBtn(btn, 'Sign In →');
    if (pendingNavTarget) { const t = pendingNavTarget; pendingNavTarget = null; navTo(t); }
  }, 900);
}

/* ── EMAIL SIGNUP ── */
function doSignup() {
  clearAuthErrors();
  const fn = document.getElementById('signupFirst').value.trim();
  const ln = document.getElementById('signupLast').value.trim();
  const email = document.getElementById('signupEmail').value.trim();
  const pwd = document.getElementById('signupPwd').value;
  const college = document.getElementById('signupCollege').value.trim();
  let ok = true;
  if (!fn) { markErr('signupFirst', 'signupFirstErr', 'First name is required.'); ok = false; }
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    markErr('signupEmail', 'signupEmailErr', 'Please enter a valid email address.'); ok = false;
  }
  if (!pwd || pwd.length < 8) {
    markErr('signupPwd', 'signupPwdErr', 'Password must be at least 8 characters.'); ok = false;
  }
  if (!ok) return;

  const users = getUsers();
  if (users[email]) {
    markErr('signupEmail', 'signupEmailErr', 'An account with this email already exists. Sign in instead.');
    return;
  }

  const btn = document.getElementById('signupSubmit');
  setLoading(btn, 'Creating account…');

  setTimeout(() => {
    const user = {
      name: ((fn||'Student') + ' ' + (ln||'')).trim(),
      firstName: fn || 'Student',
      lastName: ln || '',
      email, college,
      provider: 'Email',
      bio: college ? 'Student at ' + college : '',
      joinedAt: Date.now(),
    };
    // Save to users store
    users[email] = { ...user, pwd: btoa(pwd) };
    saveUsers(users);
    saveUser(user);
    closeAuth();
    updateNavForAuth();
    toast('🎉 Welcome to StudyVault, ' + (fn || 'there') + '!', 'success');
    resetBtn(btn, 'Create Account →');
    if (pendingNavTarget) { const t = pendingNavTarget; pendingNavTarget = null; navTo(t); }
  }, 900);
}

/* ── FORGOT PASSWORD ── */
function doForgot() {
  const email = document.getElementById('forgotEmail').value.trim();
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    document.getElementById('forgotEmail').classList.add('error');
    return;
  }
  toast('📧 Reset link sent to ' + email + ' (demo — check console)', 'success');
  setTimeout(() => showPanel('login'), 1800);
}

/* ── LOGOUT ── */
function doLogout() {
  const name = currentUser?.firstName || 'there';
  clearUser();
  updateNavForAuth();
  if (['saved','upload','profile','admin'].includes(window._curPage)) navTo('home');
  toast('👋 Goodbye, ' + name + '. See you soon!', '');
}

/* ── REQUIRE AUTH ── */
function requireAuth(target) {
  if (currentUser) { navTo(target); return; }
  pendingNavTarget = target;
  openAuth('login');
}

/* ── AUTH HELPERS ── */
function clearAuthErrors() {
  document.querySelectorAll('.auth-err').forEach(e => e.classList.remove('show'));
  document.querySelectorAll('.auth-input').forEach(i => i.classList.remove('error'));
}
function markErr(inputId, errId, msg) {
  const inp = document.getElementById(inputId);
  const err = document.getElementById(errId);
  if (inp) inp.classList.add('error');
  if (err) { err.textContent = msg; err.classList.add('show'); }
}
function showErr(id) { const el = document.getElementById(id); if (el) el.classList.add('show'); }
function setLoading(btn, label) { btn.disabled = true; btn.textContent = label; }
function resetBtn(btn, label) { btn.disabled = false; btn.textContent = label; }
function togglePwd(id, btn) {
  const inp = document.getElementById(id);
  if (!inp) return;
  if (inp.type === 'password') { inp.type = 'text'; btn.textContent = '🙈'; }
  else { inp.type = 'password'; btn.textContent = '👁'; }
}
function cap(s) { return s ? s.charAt(0).toUpperCase() + s.slice(1).toLowerCase() : ''; }
function checkPwdStrength(pwd) {
  const bar = document.getElementById('pwdBar');
  const txt = document.getElementById('pwdTxt');
  if (!bar) return;
  let score = 0;
  if (pwd.length >= 8) score++;
  if (/[A-Z]/.test(pwd)) score++;
  if (/[0-9]/.test(pwd)) score++;
  if (/[^A-Za-z0-9]/.test(pwd)) score++;
  const colors = ['#c0392b','#d4831a','#f0a835','#2d7a3a'];
  const labels = ['Weak','Fair','Good','Strong'];
  bar.style.width = (score * 25) + '%';
  bar.style.background = colors[score-1] || '#d4c9b0';
  txt.textContent = score > 0 ? labels[score-1] : '';
}

/* ── PROFILE PAGE ── */
function renderProfile() {
  if (!currentUser) { navTo('home'); return; }
  const saved = DB.savedIds.length;
  const myUploads = DB.resources.filter(r => r.author === currentUser.name);
  const col = avatarColor(currentUser.name || currentUser.email);
  const providerBadgeColor = {
    'Google':'#4285f4','Facebook':'#1877f2','GitHub':'#333','Microsoft':'#00a4ef',
    'Apple':'#000','Twitter / X':'#1da1f2','LinkedIn':'#0077b5','Phone':'#2d7a3a','Email':'#d4831a'
  }[currentUser.provider] || '#d4831a';

  document.getElementById('profileContent').innerHTML = `
    <div class="profile-header">
      <div class="profile-avatar-lg" style="background:${col}">${userInitials(currentUser)}</div>
      <div>
        <div class="profile-name">${currentUser.name}</div>
        <div class="profile-email">✉️ ${currentUser.email}</div>
        ${currentUser.phone ? `<div class="profile-email">📱 ${currentUser.phone}</div>` : ''}
        ${currentUser.college ? `<div class="profile-email">🏫 ${currentUser.college}</div>` : ''}
        ${currentUser.bio ? `<div class="profile-email" style="margin-top:4px;font-style:italic;">${currentUser.bio}</div>` : ''}
        <div class="profile-badge" style="background:${providerBadgeColor}15;color:${providerBadgeColor};">
          ✓ Signed in via ${currentUser.provider} · Joined ${new Date(currentUser.joinedAt).toLocaleDateString('en-IN',{month:'long',year:'numeric'})}
        </div>
      </div>
    </div>
    <div class="profile-stats">
      <div class="profile-stat"><span class="profile-stat-num">${myUploads.length}</span><span class="profile-stat-label">My Uploads</span></div>
      <div class="profile-stat"><span class="profile-stat-num">${saved}</span><span class="profile-stat-label">Saved</span></div>
      <div class="profile-stat"><span class="profile-stat-num">${myUploads.reduce((s,r)=>s+r.downloads,0).toLocaleString()}</span><span class="profile-stat-label">My Downloads</span></div>
    </div>

    <!-- Edit Profile Form -->
    <div style="background:var(--paper);border:1px solid var(--border);padding:28px;margin-bottom:32px;">
      <div style="font-size:.65rem;letter-spacing:.15em;text-transform:uppercase;color:var(--muted);margin-bottom:18px;padding-bottom:8px;border-bottom:1px solid var(--border);">Edit Profile</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px;">
        <div>
          <label class="auth-label">First Name</label>
          <input class="auth-input" id="editFirst" value="${currentUser.firstName||''}" placeholder="First name">
        </div>
        <div>
          <label class="auth-label">Last Name</label>
          <input class="auth-input" id="editLast" value="${currentUser.lastName||''}" placeholder="Last name">
        </div>
      </div>
      <div style="margin-bottom:14px;">
        <label class="auth-label">College / University</label>
        <input class="auth-input" id="editCollege" value="${currentUser.college||''}" placeholder="Your college" list="editCollegeList">
        <datalist id="editCollegeList">${COLLEGES.map(c=>`<option value="${c.name}">`).join('')}</datalist>
      </div>
      <div style="margin-bottom:18px;">
        <label class="auth-label">Bio</label>
        <input class="auth-input" id="editBio" value="${currentUser.bio||''}" placeholder="A short bio…">
      </div>
      <button class="btn-primary" onclick="saveProfile()" style="font-size:.75rem;padding:10px 24px;">Save Changes</button>
    </div>

    <div class="section-header" style="margin-bottom:20px;">
      <div class="section-title" style="font-size:1.2rem;">My Uploads</div>
      <button class="see-all" onclick="requireAuth('upload')">+ Upload new</button>
    </div>
    <div class="resources-grid">
      ${myUploads.length
        ? myUploads.map(r=>cardHTML(r)).join('')
        : '<div class="empty-state"><div class="empty-icon">📤</div><div class="empty-title">No uploads yet</div><p class="empty-sub">Share your notes and help fellow students!</p><br><button class="btn-primary" style="margin-top:8px" onclick="requireAuth(\'upload\')">Upload Now</button></div>'}
    </div>
    <div style="margin-top:40px;padding-top:28px;border-top:1px solid var(--border);display:flex;gap:12px;flex-wrap:wrap;">
      <button class="btn-outline" onclick="navTo('saved')" style="font-size:.72rem;">🔖 My Saved (${saved})</button>
      <button class="btn-outline" style="font-size:.72rem;color:var(--red);border-color:var(--red);" onclick="doLogout()">Sign Out</button>
    </div>`;
}

function saveProfile() {
  if (!currentUser) return;
  const fn = document.getElementById('editFirst').value.trim();
  const ln = document.getElementById('editLast').value.trim();
  const college = document.getElementById('editCollege').value.trim();
  const bio = document.getElementById('editBio').value.trim();
  currentUser.firstName = fn || currentUser.firstName;
  currentUser.lastName = ln || currentUser.lastName;
  currentUser.name = ((currentUser.firstName) + ' ' + (currentUser.lastName)).trim();
  currentUser.college = college;
  currentUser.bio = bio;
  saveUser(currentUser);
  updateNavForAuth();
  toast('✓ Profile updated!', 'success');
  renderProfile();
}

// ═══════════════════════════════════════════════════════════
//  CLASSES & TESTS — Data + Render Engine
// ═══════════════════════════════════════════════════════════

/* ── VIDEO DATA per College ── */
const VIDEO_SUBJECTS = ['Computer Science','Mathematics','Physics','Engineering','Chemistry','Biology','Economics','Law','Medicine','Business & Management','Psychology'];



// Fallback templates for subjects without specific YouTube mappings
const SUBJECT_YOUTUBE = {
  'Computer Science': [
    {ytId:'8mAITcNt710', title:'Introduction to CS & Programming — MIT 6.0001', instructor:'Prof. Eric Grimson (MIT)', duration:'51:29', views:4200000, desc:'MIT 6.0001 — computational thinking, Python and problem-solving from one of the world\'s top universities.'},
    {ytId:'ZA_D4O6l1ly', title:'Data Structures & Algorithms — Full Course', instructor:'freeCodeCamp', duration:'8:02:44', views:3800000, desc:'Arrays, stacks, queues, linked lists, trees, graphs and complexity analysis — fully comprehensive.'},
    {ytId:'vLnPwxZdW4Y', title:'Database Management Systems — Full Course', instructor:'freeCodeCamp', duration:'4:20:37', views:2900000, desc:'SQL, relational databases, normalization, indexing, transactions and ACID properties.'},
    {ytId:'_uQrJ0TkZlc', title:'Python Tutorial for Beginners — Full Course', instructor:'Mosh Hamedani', duration:'6:14:07', views:28000000, desc:'Python from scratch — OOP, data structures, file I/O and industry best practices.'},
    {ytId:'KJgsSFOSQv0', title:'C Programming Full Course', instructor:'freeCodeCamp', duration:'3:46:13', views:5100000, desc:'Variables, loops, functions, arrays, pointers and memory management fully explained.'},
    {ytId:'RBSGKlAvoiM', title:'Data Structures Easy to Advanced', instructor:'freeCodeCamp', duration:'8:02:44', views:4700000, desc:'All data structures — arrays, linked lists, trees, heaps, hash tables and graphs.'},
    {ytId:'Ke90Tje7VS0', title:'React JS Full Course for Beginners', instructor:'Dave Gray', duration:'9:09:30', views:3400000, desc:'Modern React — components, hooks, state, routing and best practices.'},
    {ytId:'pkYVOmU3MgA', title:'Operating Systems — Complete Course', instructor:'Neso Academy', duration:'7:32:15', views:2100000, desc:'Process management, memory, file systems, scheduling and concurrency.'},
  ],
  'Mathematics': [
    {ytId:'WUvTyaaNkzM', title:'The Essence of Calculus', instructor:'3Blue1Brown', duration:'17:04', views:8900000, desc:'A beautiful visual journey through calculus — derivatives, integrals and the fundamental theorem.'},
    {ytId:'fNk_zzaMoSs', title:'Essence of Linear Algebra — Chapter 1: Vectors', instructor:'3Blue1Brown', duration:'9:52', views:11000000, desc:'Visual intuition for vectors, linear combinations, spans and basis — foundational linear algebra.'},
    {ytId:'HfACrKJ_Y2w', title:'Statistics — Full University Course', instructor:'freeCodeCamp', duration:'8:15:00', views:2400000, desc:'Descriptive statistics, probability, distributions, hypothesis testing and regression.'},
    {ytId:'rfG8ce4nNh0', title:'Differential Equations — MIT 18.03', instructor:'Prof. Arthur Mattuck (MIT)', duration:'1:05:28', views:890000, desc:'Separable equations, linear ODEs, Laplace transforms and systems of equations.'},
    {ytId:'k7RM-ot2NWY', title:'Abstract Algebra — Full Course', instructor:'Socratica', duration:'3:30:00', views:1200000, desc:'Groups, rings, fields and more — abstract algebra presented with proofs and applications.'},
    {ytId:'LqbZpur38nw', title:'Number Theory — Full Lecture Series', instructor:'Prof. Richard Borcherds', duration:'5:30:00', views:650000, desc:'Divisibility, primes, modular arithmetic, Diophantine equations and quadratic reciprocity.'},
  ],
  'Physics': [
    {ytId:'IFKnq9QM6_A', title:'MIT Physics 8.01 — Classical Mechanics, Lecture 1', instructor:'Prof. Walter Lewin (MIT)', duration:'47:05', views:3200000, desc:'Prof. Walter Lewin\'s legendary MIT mechanics lectures — kinematics and Newton\'s laws.'},
    {ytId:'oRpERQA4Vik', title:'Electromagnetism — MIT 8.02', instructor:'Prof. Walter Lewin (MIT)', duration:'1:02:18', views:1900000, desc:'Electric fields, magnetic fields, Maxwell\'s equations and electromagnetic waves.'},
    {ytId:'mPhW6fXMD1o', title:'Quantum Mechanics — Full Introductory Course', instructor:'PBS Space Time', duration:'3:45:00', views:2100000, desc:'Wave-particle duality, Schrödinger equation and quantum measurement explained.'},
    {ytId:'j-kMn4zOAlk', title:'Thermodynamics — Stanford University', instructor:'Prof. Leonard Susskind (Stanford)', duration:'1:30:22', views:780000, desc:'Heat, work, entropy and the laws of thermodynamics from Susskind\'s Stanford lectures.'},
    {ytId:'Hj7OmZn7QCc', title:'Special Theory of Relativity — Full Course', instructor:'Eugene Khutoryansky', duration:'2:12:00', views:1600000, desc:'Time dilation, length contraction, mass-energy equivalence and spacetime geometry.'},
  ],
  'Engineering': [
    {ytId:'LtpMd5JKORE', title:'Engineering Mechanics: Statics — Full Course', instructor:'Prof. Jeff Hanson', duration:'14:30:00', views:1800000, desc:'Forces, moments, equilibrium, trusses, frames, distributed loads and friction.'},
    {ytId:'4i1MUWJoI0U', title:'Circuits I — Full DC Circuits Course', instructor:'Prof. Mitch Tyler', duration:'6:45:00', views:1200000, desc:'Ohm\'s law, KVL, KCL, mesh analysis, Thevenin\'s theorem — complete circuit toolkit.'},
    {ytId:'jkUt4uBBBd0', title:'Fluid Mechanics — Complete Course', instructor:'Prof. Steven Brunton', duration:'8:00:00', views:1100000, desc:'Bernoulli\'s equation, pipe flow, boundary layers, drag and lift.'},
    {ytId:'5sKah3pJnHI', title:'Strength of Materials — Full Course (NPTEL)', instructor:'NPTEL Prof.', duration:'10:00:00', views:890000, desc:'Stress, strain, beams, columns, shear force and bending moment diagrams.'},
  ],
  'Chemistry': [
    {ytId:'FSyAehMdpyI', title:'General Chemistry 1 — Complete Review', instructor:'The Organic Chemistry Tutor', duration:'2:00:16', views:3200000, desc:'Atomic structure, periodic trends, bonding, stoichiometry, gases and solutions.'},
    {ytId:'bka20Q9TN6M', title:'Organic Chemistry — Full Course', instructor:'Khan Academy', duration:'4:30:00', views:2800000, desc:'Functional groups, reaction mechanisms, stereochemistry and substitution reactions.'},
    {ytId:'0RRVV4Diomg', title:'Electrochemistry — Full Lesson', instructor:'The Organic Chemistry Tutor', duration:'1:46:37', views:1400000, desc:'Galvanic cells, electrolytic cells, Nernst equation and standard electrode potentials.'},
    {ytId:'HB5QFAhNaXM', title:'Physical Chemistry — Quantum Mechanics', instructor:'MIT OpenCourseWare', duration:'1:18:30', views:670000, desc:'Wavefunctions, Schrödinger equation, particle in a box and hydrogen atom.'},
  ],
  'Biology': [
    {ytId:'QnQe0xW_JY4', title:'Cell Structure & Function — Crash Course Biology', instructor:'Crash Course', duration:'14:03', views:6700000, desc:'Cell organelles, membrane transport, cell cycle and division with gorgeous animations.'},
    {ytId:'OAw2TLzKXXo', title:'Genetics — DNA Structure, Replication & Expression', instructor:'Professor Dave Explains', duration:'3:20:00', views:2100000, desc:'DNA, replication, transcription, translation, mutation and inheritance.'},
    {ytId:'tLYj7Fq0aZE', title:'Human Anatomy & Physiology I — Full Course', instructor:'Ninja Nerd', duration:'9:15:00', views:2400000, desc:'Body organization, tissues, skeletal, muscular and nervous systems.'},
    {ytId:'H-qIUSRMNGI', title:'Ecology — Ecosystems, Food Webs & Biodiversity', instructor:'Crash Course Ecology', duration:'45:00', views:3800000, desc:'Ecosystems, energy flow, nutrient cycles, population dynamics and biodiversity.'},
  ],
  'Economics': [
    {ytId:'d8RRE2rDw4k', title:'Supply and Demand — Crash Course Economics', instructor:'Crash Course', duration:'10:21', views:5600000, desc:'How prices emerge, what shifts supply/demand curves and how markets reach equilibrium.'},
    {ytId:'6AmLgBSGPmg', title:'Macroeconomics — Full University Course', instructor:'freeCodeCamp', duration:'4:44:49', views:1800000, desc:'GDP, inflation, unemployment, monetary policy, fiscal policy and international trade.'},
    {ytId:'O6MC9zu4pD0', title:'Microeconomics — Complete Course', instructor:'Jacob Clifford', duration:'3:30:00', views:2200000, desc:'Consumer theory, firm behaviour, market structures, externalities and game theory.'},
    {ytId:'sTCHmhYBpJQ', title:'Behavioural Economics — Full Lecture', instructor:'Yale University', duration:'1:15:22', views:890000, desc:'Biases, heuristics, nudge theory and the limits of rational choice.'},
  ],
  'Law': [
    {ytId:'7OEXZ9IbRAo', title:'Contract Law — The Essentials', instructor:'BARBRI Law School', duration:'2:15:00', views:540000, desc:'Offer, acceptance, consideration, breach and remedies — the building blocks of contract law.'},
    {ytId:'Nx5_WZ0KBUU', title:'Criminal Law — Full Overview', instructor:'Crash Course', duration:'11:52', views:2800000, desc:'Elements of crime, mens rea, actus reus, defences and the criminal justice process.'},
    {ytId:'CkpYa4FoZxc', title:'Constitutional Law — Introduction', instructor:'Yale Law School', duration:'1:30:00', views:670000, desc:'Judicial review, separation of powers, federalism and fundamental rights.'},
    {ytId:'anMiD9AmCeA', title:'International Law — Full Lecture Series', instructor:'Leiden University', duration:'1:45:00', views:380000, desc:'Sources of international law, treaties, state responsibility and human rights.'},
  ],
  'Medicine': [
    {ytId:'cb0SalRiAfE', title:'Human Anatomy — Complete Illustrated Course', instructor:'Armando Hasudungan', duration:'4:00:00', views:3200000, desc:'Detailed anatomy illustrations of all body systems used by medical students worldwide.'},
    {ytId:'_d8bX-6EMW4', title:'Pharmacology — Drug Classes & Mechanisms', instructor:'Ninja Nerd', duration:'5:30:00', views:1900000, desc:'Drug receptor theory, autonomic pharmacology, cardiovascular drugs and antibiotics.'},
    {ytId:'UXGkDR24oYI', title:'ECG Interpretation Masterclass', instructor:'Dr. John Campbell', duration:'3:00:00', views:2100000, desc:'Reading ECGs — rate, rhythm, axis, hypertrophy and major arrhythmias.'},
    {ytId:'6fFiMPGO7rg', title:'Pathology — Introduction to Disease', instructor:'Armando Hasudungan', duration:'2:45:00', views:1200000, desc:'Cell injury, inflammation, neoplasia and cardiovascular pathology.'},
  ],
  'Business & Management': [
    {ytId:'ZoqgAy3h4OM', title:'Financial Accounting — Complete Course', instructor:'AccountingStuff', duration:'5:30:00', views:2800000, desc:'Accounting equation, income statements, balance sheets and cash flow statements.'},
    {ytId:'dDevsO8Iy4g', title:'Marketing Management — Full Course', instructor:'Philip Kotler Lectures', duration:'3:00:00', views:980000, desc:'Segmentation, targeting, positioning, the 4Ps and digital marketing.'},
    {ytId:'SjMDSAXN30k', title:'Entrepreneurship — How to Start a Business', instructor:'Y Combinator', duration:'5:00:00', views:1700000, desc:'Finding a problem, building an MVP, product-market fit and fundraising.'},
    {ytId:'VrKW58MS12g', title:'Business Strategy — MBA Course', instructor:'Harvard Business Review', duration:'4:00:00', views:1400000, desc:'Porter\'s five forces, competitive advantage, business model canvas and strategy.'},
  ],
  'Psychology': [
    {ytId:'vo4pMVb0R6M', title:'Introduction to Psychology — Yale University', instructor:'Prof. Paul Bloom (Yale)', duration:'1:08:52', views:3900000, desc:'The science of mind and behaviour — perception, memory, learning and emotion from Yale.'},
    {ytId:'lDqOLotQ17Y', title:'Cognitive Psychology — Memory & Thinking', instructor:'Crash Course Psychology', duration:'1:30:00', views:2100000, desc:'How memory works, cognitive biases, problem solving and language.'},
    {ytId:'6rT5aLSGwDU', title:'Abnormal Psychology — Mental Disorders', instructor:'Prof. Todd Grande', duration:'2:15:00', views:890000, desc:'Depression, anxiety, schizophrenia, personality disorders and the DSM.'},
    {ytId:'PhQFTaKCsLg', title:'Social Psychology — Influence & Conformity', instructor:'Crash Course Psychology', duration:'45:00', views:2700000, desc:'Obedience, conformity, groupthink and social influence.'},
  ],
};

const VIDEO_TEMPLATES = [
  {title:'Introduction to {subject}',duration:'48:12',instructor:'Dr. Amit Sharma',views:3200},
  {title:'Core Concepts of {subject} — Part 1',duration:'55:40',instructor:'Prof. Priya Iyer',views:2800},
  {title:'Core Concepts of {subject} — Part 2',duration:'62:05',instructor:'Prof. Priya Iyer',views:2100},
  {title:'Problem Solving Workshop: {subject}',duration:'72:30',instructor:'Dr. Ravi Menon',views:4100},
  {title:'Fundamentals & Theory of {subject}',duration:'44:18',instructor:'Prof. Sunita Rao',views:1900},
  {title:'Advanced Topics in {subject}',duration:'58:55',instructor:'Dr. Arun Nair',views:1400},
  {title:'Exam Preparation — {subject}',duration:'90:00',instructor:'Prof. Kavitha Pillai',views:5600},
  {title:'Live Q&A Session: {subject}',duration:'38:45',instructor:'Dr. Amit Sharma',views:2200},
];

const SUBJECT_COLORS = {
  'Computer Science':'#5342a6','Mathematics':'#1a6b6b','Physics':'#d4831a',
  'Engineering':'#c0392b','Chemistry':'#1877f2','Biology':'#2d7a3a',
  'Economics':'#8e44ad','Law':'#2c3e50','Medicine':'#e74c3c',
  'Business & Management':'#16a085','Psychology':'#d35400'
};

// Generate video library: top colleges get more content
let VIDEO_LIBRARY = {};
const TOP_COLLEGES = COLLEGES.slice(0, 60);

TOP_COLLEGES.forEach((col, ci) => {
  const numSubjects = 2 + (ci % 4);
  const subjects = VIDEO_SUBJECTS.slice(ci % VIDEO_SUBJECTS.length, ci % VIDEO_SUBJECTS.length + numSubjects)
    .concat(VIDEO_SUBJECTS.slice(0, Math.max(0, (ci % VIDEO_SUBJECTS.length + numSubjects) - VIDEO_SUBJECTS.length)));
  
  VIDEO_LIBRARY[col.name] = subjects.map((subj, si) => {
    const ytVids = SUBJECT_YOUTUBE[subj] || [];
    const numVideos = Math.max(3, Math.min(ytVids.length, 3 + (si % 5)));
    const baseVids = ytVids.length > 0 ? ytVids : VIDEO_TEMPLATES.slice(0, numVideos).map(t=>({
      ytId: null, title: t.title.replace('{subject}', subj), instructor: t.instructor,
      duration: t.duration, views: t.views, desc: `Core ${subj} lecture from ${col.name}.`
    }));
    return {
      subject: subj,
      color: SUBJECT_COLORS[subj] || '#555',
      videos: baseVids.slice(0, numVideos).map((t, vi) => ({
        id: col.name.replace(/\s/g,'-') + '-' + si + '-' + vi,
        ytId: t.ytId || null,
        college: col.name,
        subject: subj,
        title: t.title,
        duration: t.duration,
        instructor: t.instructor,
        views: (t.views || 1000) + Math.floor(Math.random() * 500) + ci * 10,
        description: t.desc || `This lecture covers essential concepts in ${subj} as taught at ${col.name}.`,
        uploadedAt: Date.now() - (vi * 7 + ci) * 86400000,
        thumbColor: SUBJECT_COLORS[subj] || '#1a6b6b',
      }))
    };
  });
});

/* ── TEST DATA per College ── */
const generateQuestions = (subject, count) => {
  const questionBank = {
    'Computer Science': [
      {q:'What is the time complexity of binary search?', opts:['O(n)','O(log n)','O(n²)','O(1)'], ans:1, exp:'Binary search divides the search space in half at each step, giving O(log n) time complexity.'},
      {q:'Which data structure uses LIFO order?', opts:['Queue','Stack','Tree','Graph'], ans:1, exp:'Stack follows Last In, First Out (LIFO) order — the last element pushed is the first to be popped.'},
      {q:'What does SQL stand for?', opts:['Standard Query Language','Structured Query Language','Simple Query Logic','System Query Layer'], ans:1, exp:'SQL stands for Structured Query Language, used to manage and query relational databases.'},
      {q:'Which of the following is NOT an OOP concept?', opts:['Encapsulation','Polymorphism','Compilation','Inheritance'], ans:2, exp:'Compilation is a process, not an OOP concept. The four OOP pillars are encapsulation, abstraction, polymorphism, and inheritance.'},
      {q:'What is a deadlock in operating systems?', opts:['Memory overflow','Process waiting indefinitely for resources held by other waiting processes','CPU overheating','Hard disk failure'], ans:1, exp:'A deadlock occurs when two or more processes are each waiting for resources held by the other, creating a cycle of dependency.'},
      {q:'Which sorting algorithm has best average-case performance?', opts:['Bubble Sort','Insertion Sort','Quick Sort','Selection Sort'], ans:2, exp:'Quick Sort has an average time complexity of O(n log n), making it one of the fastest sorting algorithms in practice.'},
      {q:'What is the purpose of a pointer in C?', opts:['To store text','To store the address of a variable','To define functions','To create loops'], ans:1, exp:'A pointer is a variable that stores the memory address of another variable, enabling dynamic memory management.'},
      {q:'Which HTTP method is used to update existing data?', opts:['GET','POST','PUT','DELETE'], ans:2, exp:'PUT is used to update or replace an existing resource. POST creates new resources, GET retrieves them, DELETE removes them.'},
    ],
    'Mathematics': [
      {q:'What is the derivative of sin(x)?', opts:['cos(x)','-cos(x)','tan(x)','-sin(x)'], ans:0, exp:'The derivative of sin(x) is cos(x). This is a fundamental result in calculus.'},
      {q:'What is the value of i² where i is imaginary?', opts:['1','-1','i','0'], ans:1, exp:'By definition, i = √(-1), therefore i² = -1. This is the fundamental property of imaginary numbers.'},
      {q:'Which of the following is a prime number?', opts:['9','15','17','21'], ans:2, exp:'17 is a prime number as it has only two divisors: 1 and itself. 9=3×3, 15=3×5, 21=3×7.'},
      {q:'What is the integral of 1/x?', opts:['x²/2','1/x²','ln|x| + C','e^x'], ans:2, exp:'∫(1/x)dx = ln|x| + C. This is because the derivative of ln(x) is 1/x.'},
      {q:'In a right triangle, if sin θ = 3/5, what is cos θ?', opts:['4/5','3/4','5/3','1/5'], ans:0, exp:'Using the Pythagorean identity: sin²θ + cos²θ = 1. So cos²θ = 1 - 9/25 = 16/25, thus cos θ = 4/5.'},
    ],
    'Physics': [
      {q:'What is Newton\'s Second Law?', opts:['Every action has equal reaction','F = ma','Energy cannot be created or destroyed','Objects in motion stay in motion'], ans:1, exp:'Newton\'s Second Law states F = ma: Force equals mass times acceleration.'},
      {q:'What is the SI unit of electric charge?', opts:['Volt','Ampere','Coulomb','Ohm'], ans:2, exp:'The SI unit of electric charge is the Coulomb (C), named after physicist Charles-Augustin de Coulomb.'},
      {q:'The speed of light in vacuum is approximately:', opts:['3×10⁶ m/s','3×10⁸ m/s','3×10¹⁰ m/s','3×10⁴ m/s'], ans:1, exp:'The speed of light in vacuum is approximately 3×10⁸ m/s (299,792,458 m/s to be exact).'},
      {q:'Which type of wave does not require a medium?', opts:['Sound waves','Water waves','Electromagnetic waves','Seismic waves'], ans:2, exp:'Electromagnetic waves (light, radio, X-rays) can travel through a vacuum without any medium.'},
    ],
    'default': [
      {q:`Which approach is fundamental to ${subject}?`, opts:['Analytical thinking','Random guessing','Memorisation only','None of the above'], ans:0, exp:`Analytical thinking is fundamental to ${subject} as it helps in breaking down complex problems systematically.`},
      {q:`A key application of ${subject} in modern life is:`, opts:['Healthcare','Technology','Finance','All of the above'], ans:3, exp:`${subject} has broad applications across healthcare, technology, finance, and many other sectors.`},
      {q:`Research in ${subject} typically involves:`, opts:['Hypothesis formation','Data collection','Analysis','All of the above'], ans:3, exp:'Good research methodology includes forming hypotheses, collecting data, and rigorously analyzing results.'},
      {q:`Which is the most important skill for a ${subject} professional?`, opts:['Communication','Critical thinking','Collaboration','All equally important'], ans:3, exp:'Modern professionals need communication, critical thinking, and collaboration skills equally to succeed.'},
      {q:`A foundational text in ${subject} would cover:`, opts:['Historical context','Core theories','Practical applications','All of the above'], ans:3, exp:'A comprehensive foundation requires understanding history, theory, and practical application of the field.'},
    ]
  };
  const pool = questionBank[subject] || questionBank['default'];
  const shuffled = [...pool].sort(()=>Math.random()-0.5);
  return shuffled.slice(0, Math.min(count, shuffled.length)).concat(
    shuffled.slice(0, Math.max(0, count - shuffled.length))
  ).slice(0, count);
};

const TEST_TYPES = ['mcq','mcq','mixed','mixed','mcq'];
const TEST_DURATIONS = [15, 20, 30, 20, 25]; // minutes

let TEST_BANK = {};
TOP_COLLEGES.forEach((col, ci) => {
  const subjects = Object.keys(VIDEO_LIBRARY[col.name] || {});
  TEST_BANK[col.name] = VIDEO_SUBJECTS.slice(ci % 4, (ci % 4) + 3).map((subj, ti) => ({
    id: col.name.replace(/\s/g,'-') + '-test-' + ti,
    college: col.name,
    subject: subj,
    title: `${subj} — ${['Mid-Term Assessment','Unit Test','Chapter Quiz','Final Prep Test','Practice MCQs'][ti % 5]}`,
    type: TEST_TYPES[ti % 5],
    duration: TEST_DURATIONS[ti % 5],
    questions: generateQuestions(subj, 8 + (ti % 4) * 2),
    totalMarks: (8 + (ti % 4) * 2),
    attempts: Math.floor(Math.random() * 300) + 50,
    avgScore: 55 + Math.floor(Math.random() * 30),
    bestScore: null, // will be updated on attempt
  }));
});

/* ── STATE ── */
let classesState = { search:'', subject:'All', college:'All' };
let currentTestId = null;
let testSession = null; // {answers:[], current:0, startTime, timer}
let testResults = {}; // stored locally
let currentWatchId = null;
let watchProgress = {}; // id -> progress percent

/* ═══════════════════ CLASSES PAGE ═══════════════════ */
function renderClasses() {
  const html = `
    <div class="classes-hero">
      <div class="classes-hero-tag">Recorded Lectures</div>
      <h2>Learn from the <em>best professors</em><br>at your college.</h2>
      <p class="classes-hero-sub">Access recorded classes from ${TOP_COLLEGES.length}+ colleges. Watch at your own pace, pause, replay, and never miss a lecture.</p>
    </div>
    <div class="classes-filter-bar">
      <div class="classes-search">
        <input id="classSearch" type="text" placeholder="Search college, subject or topic…" value="${classesState.search}" oninput="filterClasses(this.value)">
        <button class="classes-search-btn">⌕</button>
      </div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;">
        ${['All',...VIDEO_SUBJECTS.slice(0,6)].map(s=>`<button class="cls-filter-btn${classesState.subject===s?' active':''}" onclick="filterClassSubject('${s}')">${s}</button>`).join('')}
      </div>
    </div>
    <div class="classes-body" id="classesBody">
      ${renderClassesList()}
    </div>`;
  document.getElementById('classesContent').innerHTML = html;
}

function renderClassesList() {
  const search = classesState.search.toLowerCase();
  const subj = classesState.subject;
  let blocks = '';
  let shown = 0;
  for (const col of TOP_COLLEGES) {
    if (search && !col.name.toLowerCase().includes(search) && !col.city.toLowerCase().includes(search)) {
      // check if any video matches search
      const hasMatch = (VIDEO_LIBRARY[col.name]||[]).some(s=>
        s.subject.toLowerCase().includes(search) || s.videos.some(v=>v.title.toLowerCase().includes(search))
      );
      if (!hasMatch) continue;
    }
    const subjects = (VIDEO_LIBRARY[col.name]||[]).filter(s=>subj==='All'||s.subject===subj);
    if (!subjects.length) continue;
    const totalVids = subjects.reduce((a,s)=>a+s.videos.length,0);
    if (shown >= 12) break;
    shown++;
    blocks += `
      <div class="college-class-block">
        <div class="college-class-header">
          <div>
            <div class="college-class-name">🏛 ${col.name}</div>
            <div class="college-class-meta">${col.city} · ${subjects.length} subjects · ${totalVids} lectures</div>
          </div>
          <button class="college-class-see-all" onclick="filterClassCollege('${col.name}')">View all →</button>
        </div>
        ${subjects.map(s => `
          <div style="margin-bottom:24px;">
            <div style="font-size:.62rem;letter-spacing:.15em;text-transform:uppercase;color:${s.color};margin-bottom:10px;display:flex;align-items:center;gap:8px;"><span style="width:8px;height:8px;background:${s.color};border-radius:50%;display:inline-block;"></span>${s.subject}</div>
            <div class="video-cards-row">
              ${s.videos.slice(0,4).map(v=>videoCardHTML(v)).join('')}
            </div>
          </div>`).join('')}
      </div>`;
  }
  return blocks || '<div class="empty-state"><div class="empty-icon">🎬</div><div class="empty-title">No classes found</div><p class="empty-sub">Try adjusting your search or filters.</p></div>';
}

function videoCardHTML(v) {
  const prog = watchProgress[v.id] || 0;
  const hasYt = !!v.ytId;
  // YouTube thumbnail URL (mqdefault = 320x180, hqdefault = 480x360)
  const thumbSrc = hasYt ? `https://img.youtube.com/vi/${v.ytId}/mqdefault.jpg` : null;
  return `
    <div class="video-card" onclick="watchVideo('${v.id}')">
      <div class="video-thumb" style="background:${v.thumbColor}15;">
        ${hasYt
          ? `<img src="${thumbSrc}" alt="${v.title}" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;" loading="lazy">
             <div style="position:absolute;inset:0;background:linear-gradient(to top,rgba(0,0,0,.55) 0%,transparent 50%);"></div>`
          : `<div style="position:absolute;inset:0;background:linear-gradient(135deg,${v.thumbColor}30,${v.thumbColor}10);display:flex;align-items:center;justify-content:center;">
               <div style="font-family:'Playfair Display',serif;font-size:1rem;font-weight:700;color:${v.thumbColor};opacity:.5;text-align:center;padding:8px;">${v.subject.split(' ').slice(0,2).join(' ')}</div>
             </div>`}
        <div class="video-play-btn"><div class="video-play-icon"></div></div>
        <div class="video-duration">${v.duration}</div>
        <div class="video-subject-tag" style="background:${v.thumbColor};">${v.subject.split(' ')[0]}</div>
        ${!hasYt ? '<div style="position:absolute;top:8px;right:8px;font-size:.55rem;letter-spacing:.1em;background:rgba(0,0,0,.6);color:#fff;padding:2px 7px;">COMING SOON</div>' : ''}
      </div>
      <div class="video-progress-bar"><div class="video-progress-fill" style="width:${prog}%"></div></div>
      <div class="video-info">
        <div class="video-title">${v.title}</div>
        <div class="video-meta">
          <span>👤 ${v.instructor.split(' ').slice(-1)[0]}</span>
          <span>👁 ${v.views.toLocaleString()}</span>
          <span>⏱ ${v.duration}</span>
          ${prog > 0 ? `<span style="color:var(--amber);">▶ ${prog}%</span>` : ''}
        </div>
      </div>
    </div>`;
}

function filterClasses(val) { classesState.search = val; document.getElementById('classesBody').innerHTML = renderClassesList(); }
function filterClassSubject(s) {
  classesState.subject = s;
  document.querySelectorAll('.cls-filter-btn').forEach(b=>b.classList.toggle('active',b.textContent===s));
  document.getElementById('classesBody').innerHTML = renderClassesList();
}
function filterClassCollege(name) {
  classesState.search = name;
  document.getElementById('classSearch') && (document.getElementById('classSearch').value = name);
  document.getElementById('classesBody').innerHTML = renderClassesList();
}

/* ═══════════════════ WATCH PAGE ═══════════════════ */
let watchInterval = null;

function watchVideo(videoId) {
  // find the video
  let video = null;
  let playlist = [];
  for (const col of TOP_COLLEGES) {
    for (const s of (VIDEO_LIBRARY[col.name]||[])) {
      const found = s.videos.find(v=>v.id===videoId);
      if (found) { video = found; playlist = s.videos; break; }
    }
    if (video) break;
  }
  if (!video) return;
  currentWatchId = videoId;
  navTo('watch');
  renderWatch(video, playlist);
}

function renderWatch(video, playlist) {
  const col = SUBJECT_COLORS[video.subject] || '#555';
  const initials = video.instructor.split(' ').filter(Boolean).map(w=>w[0]).join('').slice(0,2).toUpperCase();
  const collegeTests = TEST_BANK[video.college] || [];
  const relatedTest = collegeTests.find(t=>t.subject===video.subject);

  const playerSection = video.ytId
    ? `<!-- Real YouTube embed -->
       <div class="yt-player-wrap" id="ytPlayerWrap">
         <iframe
           id="ytIframe"
           src="https://www.youtube.com/embed/${video.ytId}?rel=0&modestbranding=1&color=white&enablejsapi=1&origin=${window.location.origin}"
           title="${video.title}"
           allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
           allowfullscreen
           style="position:absolute;top:0;left:0;width:100%;height:100%;border:none;">
         </iframe>
       </div>
       <div class="yt-meta-bar">
         <span>🎬 YouTube • ${video.duration}</span>
         <span>👁 ${video.views.toLocaleString()} views</span>
         <a href="https://www.youtube.com/watch?v=${video.ytId}" target="_blank" rel="noopener" class="yt-ext-link">Watch on YouTube ↗</a>
       </div>`
    : `<!-- No YouTube ID — show placeholder -->
       <div class="watch-no-video" style="background:${col}15;border:2px dashed ${col}40;">
         <div style="font-size:3.5rem;margin-bottom:16px;">🎬</div>
         <div style="font-family:'Playfair Display',serif;font-size:1.3rem;font-weight:700;margin-bottom:8px;">${video.title}</div>
         <div style="font-size:.8rem;color:var(--muted);line-height:1.7;max-width:420px;margin:0 auto 20px;">
           This lecture will be available soon. In the meantime, explore related resources or take the subject test to check your knowledge.
         </div>
         <button class="btn-primary" onclick="window.open('https://www.youtube.com/results?search_query=${encodeURIComponent(video.title)}','_blank')">Search on YouTube →</button>
       </div>`;

  document.getElementById('watchContent').innerHTML = `
    <div class="watch-layout">
      <div class="watch-main">
        <button class="watch-back-btn" onclick="navTo('classes')">
          <svg width="14" height="14" viewBox="0 0 24 24"><path fill="currentColor" d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"/></svg>
          Back to Classes
        </button>

        ${playerSection}

        <div class="watch-video-info">
          <div class="watch-title">${video.title}</div>
          <div class="watch-tags">
            <span class="watch-tag" style="border-color:${col};color:${col};background:${col}10;">${video.subject}</span>
            <span class="watch-tag">🏛 ${video.college}</span>
            <span class="watch-tag">⏱ ${video.duration}</span>
            <span class="watch-tag">👁 ${video.views.toLocaleString()} views</span>
            <span class="watch-tag" style="color:var(--success);border-color:var(--success);">🆓 Free</span>
          </div>
          <div style="border-top:1px solid var(--border);border-bottom:1px solid var(--border);padding:16px 0;margin:16px 0;">
            <div class="watch-instructor">
              <div class="watch-instr-avatar" style="background:${col}">${initials}</div>
              <div>
                <div class="watch-instr-name">${video.instructor}</div>
                <div class="watch-instr-role">📍 ${video.college}</div>
              </div>
            </div>
          </div>
          <div class="watch-desc">${video.description}</div>
          ${relatedTest ? `
            <button class="watch-take-test-btn" onclick="startTest('${relatedTest.id}')">
              📝 Take Test on ${relatedTest.subject} →
            </button>` : ''}
          <div class="watch-share-row">
            <span style="font-size:.68rem;color:var(--muted);letter-spacing:.1em;text-transform:uppercase;">Share:</span>
            ${video.ytId ? `
            <button class="share-btn" onclick="navigator.clipboard&&navigator.clipboard.writeText('https://youtu.be/${video.ytId}').then(()=>toast('Link copied!','success'))">📋 Copy Link</button>
            <a class="share-btn" href="https://twitter.com/intent/tweet?text=${encodeURIComponent('Watching: '+video.title)}&url=${encodeURIComponent('https://youtu.be/'+video.ytId)}" target="_blank">𝕏 Share</a>
            <a class="share-btn" href="https://wa.me/?text=${encodeURIComponent(video.title+' — https://youtu.be/'+video.ytId)}" target="_blank">💬 WhatsApp</a>
            ` : ''}
          </div>
        </div>
      </div>

      <div class="watch-sidebar">
        <div class="watch-sidebar-title">Up Next · ${playlist.length} Lectures</div>
        <div class="playlist-scroll">
          ${playlist.map((v,i) => {
            const isActive = v.id === video.id;
            const prog = watchProgress[v.id] || 0;
            const hasYt = !!v.ytId;
            return `
            <div class="playlist-item${isActive?' active':''}" onclick="watchVideo('${v.id}')">
              <div class="pl-thumb-wrap">
                ${hasYt
                  ? `<img class="pl-yt-thumb" src="https://img.youtube.com/vi/${v.ytId}/mqdefault.jpg" alt="${v.title}" loading="lazy">`
                  : `<div class="pl-thumb-placeholder" style="background:${v.thumbColor}20;"><span style="font-size:1.2rem;color:${v.thumbColor}80;">▶</span></div>`}
                ${isActive ? `<div class="pl-playing-badge">▶ NOW</div>` : `<div class="pl-num">${i+1}</div>`}
                ${prog>0 && !isActive ? `<div class="pl-prog-bar"><div style="width:${prog}%;height:100%;background:var(--amber);"></div></div>` : ''}
              </div>
              <div class="pl-info">
                <div class="playlist-item-title">${v.title}</div>
                <div class="playlist-item-meta">
                  <span>⏱ ${v.duration}</span>
                  ${prog>0 && !isActive ? `<span style="color:var(--amber);">▶ ${prog}%</span>` : ''}
                  ${!hasYt ? '<span style="color:var(--muted);">• Soon</span>' : ''}
                </div>
              </div>
            </div>`;
          }).join('')}
        </div>
      </div>
    </div>`;
}

/* helper kept for backward compat */
function parseDuration(str) {
  const parts = str.split(':').map(Number);
  return parts.length === 3 ? parts[0]*3600+parts[1]*60+parts[2] : parts[0]*60+parts[1];
}


/* ═══════════════════ TESTS PAGE ═══════════════════ */
function renderTests() {
  let blocks = '';
  let shown = 0;
  for (const col of TOP_COLLEGES) {
    const tests = TEST_BANK[col.name] || [];
    if (!tests.length) continue;
    if (shown >= 10) break;
    shown++;
    blocks += `
      <div class="test-college-section">
        <div class="test-col-header">
          <div>
            <div class="test-col-name">🏛 ${col.name}</div>
            <div style="font-size:.68rem;color:var(--muted);">${col.city} · ${tests.length} tests available</div>
          </div>
        </div>
        <div class="test-cards">
          ${tests.map(t=>testCardHTML(t)).join('')}
        </div>
      </div>`;
  }
  document.getElementById('testsContent').innerHTML = `
    <div class="tests-hero">
      <div style="font-size:.65rem;letter-spacing:.2em;text-transform:uppercase;color:var(--amber-light);margin-bottom:14px;position:relative;">📝 Assessments & Quizzes</div>
      <h2>Test your knowledge.<br><em>Track your progress.</em></h2>
      <p class="tests-hero-sub">College-specific quizzes, MCQs and mixed tests. Instant results with detailed explanations to help you learn from mistakes.</p>
    </div>
    <div class="tests-body">${blocks}</div>`;
}

function testCardHTML(t) {
  const best = testResults[t.id];
  let scoreBadge = '';
  if (best !== undefined) {
    const pct = Math.round((best / t.questions.length) * 100);
    const cls = pct>=75?'test-score-good':pct>=50?'test-score-ok':'test-score-bad';
    scoreBadge = `<div class="test-score-badge ${cls}">Best: ${pct}%</div>`;
  }
  return `
    <div class="test-card">
      ${scoreBadge}
      <div class="test-card-badge ${t.type}">${t.type==='mcq'?'MCQ':t.type==='mixed'?'Mixed':'Coding'}</div>
      <div class="test-card-title">${t.title}</div>
      <div class="test-card-meta">
        <span>📚 ${t.subject}</span>
        <span>❓ ${t.questions.length} Qs</span>
        <span>⏱ ${t.duration} min</span>
        <span>🏅 ${t.totalMarks} marks</span>
      </div>
      <div style="font-size:.65rem;color:var(--muted);margin-bottom:14px;">👥 ${t.attempts.toLocaleString()} attempts · Avg: ${t.avgScore}%</div>
      <button class="test-start-btn" onclick="startTest('${t.id}')">
        ${best !== undefined ? '🔁 Retake Test' : '▶ Start Test'}
      </button>
    </div>`;
}

/* ═══════════════════ TAKE TEST ═══════════════════ */
function startTest(testId) {
  let test = null;
  for (const col of TOP_COLLEGES) {
    const found = (TEST_BANK[col.name]||[]).find(t=>t.id===testId);
    if (found) { test = found; break; }
  }
  if (!test) return;
  
  if (!currentUser) { requireAuth('tests'); return; }
  
  currentTestId = testId;
  testSession = {
    test,
    answers: new Array(test.questions.length).fill(null),
    current: 0,
    startTime: Date.now(),
    timeLeft: test.duration * 60, // seconds
  };
  navTo('take-test');
  renderTakeTest();
  startTestTimer();
}

let testTimerInterval = null;
function startTestTimer() {
  clearInterval(testTimerInterval);
  testTimerInterval = setInterval(() => {
    if (!testSession) { clearInterval(testTimerInterval); return; }
    testSession.timeLeft--;
    updateTimerDisplay();
    if (testSession.timeLeft <= 0) {
      clearInterval(testTimerInterval);
      submitTest();
    }
  }, 1000);
}

function updateTimerDisplay() {
  const el = document.getElementById('testTimerEl');
  if (!el || !testSession) return;
  const m = Math.floor(testSession.timeLeft / 60);
  const s = testSession.timeLeft % 60;
  el.textContent = `⏱ ${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
  if (testSession.timeLeft <= 60) el.parentElement?.classList.add('warning');
}

function renderTakeTest() {
  if (!testSession) return;
  const { test, current, answers } = testSession;
  const q = test.questions[current];
  
  document.getElementById('takeTestContent').innerHTML = `
    <div class="take-test-layout">
      <div class="test-header-bar">
        <div>
          <div style="font-size:.62rem;letter-spacing:.12em;text-transform:uppercase;color:var(--muted);margin-bottom:4px;">${test.college}</div>
          <div class="test-header-title">${test.title}</div>
        </div>
        <div class="test-timer" id="testTimerEl">⏱ ${String(Math.floor(testSession.timeLeft/60)).padStart(2,'0')}:${String(testSession.timeLeft%60).padStart(2,'0')}</div>
      </div>
      
      <div class="test-progress-info">
        <span>Question ${current+1} of ${test.questions.length}</span>
        <span>·</span>
        <span>${answers.filter(a=>a!==null).length} answered</span>
        <div class="test-progress-dots">
          ${test.questions.map((_,i)=>`<div class="test-dot${i===current?' current':answers[i]!==null?' answered':''}" onclick="goToQuestion(${i})" title="Q${i+1}"></div>`).join('')}
        </div>
      </div>
      
      <div class="question-card">
        <div class="question-num">Question ${current+1} · ${test.subject}</div>
        <div class="question-text">${q.q}</div>
        <div class="options-list" id="optionsList">
          ${q.opts.map((opt,oi)=>`
            <div class="option-item${answers[current]===oi?' selected':''}" onclick="selectAnswer(${oi})" id="opt-${oi}">
              <div class="option-letter">${'ABCD'[oi]}</div>
              <div class="option-text">${opt}</div>
            </div>`).join('')}
        </div>
      </div>
      
      <div class="test-nav-btns">
        <button class="test-nav-btn" onclick="prevQuestion()" ${current===0?'disabled':''}>← Previous</button>
        <div style="display:flex;gap:10px;">
          ${current < test.questions.length-1
            ? `<button class="test-nav-btn primary" onclick="nextQuestion()">Next →</button>`
            : `<button class="test-nav-btn primary" onclick="confirmSubmit()" style="background:var(--teal);border-color:var(--teal);">Submit Test ✓</button>`}
        </div>
      </div>
      
      <div style="text-align:center;margin-top:16px;">
        <button style="font-size:.65rem;color:var(--muted);background:none;border:none;cursor:pointer;font-family:'DM Mono',monospace;letter-spacing:.08em;text-transform:uppercase;" onclick="confirmSubmit()">
          Submit early (${answers.filter(a=>a!==null).length}/${test.questions.length} answered)
        </button>
      </div>
    </div>`;
}

function selectAnswer(optIdx) {
  if (!testSession) return;
  testSession.answers[testSession.current] = optIdx;
  document.querySelectorAll('.option-item').forEach((el,i)=>{
    el.classList.toggle('selected', i===optIdx);
  });
  // Update progress dot
  const dots = document.querySelectorAll('.test-dot');
  if (dots[testSession.current]) dots[testSession.current].classList.add('answered');
}

function nextQuestion() {
  if (!testSession || testSession.current >= testSession.test.questions.length-1) return;
  testSession.current++;
  renderTakeTest();
}
function prevQuestion() {
  if (!testSession || testSession.current <= 0) return;
  testSession.current--;
  renderTakeTest();
}
function goToQuestion(idx) {
  if (!testSession) return;
  testSession.current = idx;
  renderTakeTest();
}

function confirmSubmit() {
  const unanswered = testSession.answers.filter(a=>a===null).length;
  if (unanswered > 0) {
    if (!confirm(`You have ${unanswered} unanswered question(s). Submit anyway?`)) return;
  }
  submitTest();
}

function submitTest() {
  clearInterval(testTimerInterval);
  if (!testSession) return;
  const { test, answers, startTime } = testSession;
  
  // Calculate score
  let correct = 0;
  answers.forEach((ans, i) => { if (ans === test.questions[i].ans) correct++; });
  
  const result = {
    testId: test.id,
    college: test.college,
    subject: test.subject,
    title: test.title,
    total: test.questions.length,
    correct,
    incorrect: answers.filter((a,i) => a !== null && a !== test.questions[i].ans).length,
    skipped: answers.filter(a => a === null).length,
    timeTaken: Math.round((Date.now() - startTime) / 1000),
    answers: [...answers],
    questions: test.questions,
    date: new Date().toLocaleDateString('en-IN'),
  };
  
  // Store best score
  testResults[test.id] = Math.max(testResults[test.id] || 0, correct);
  
  navTo('test-result');
  renderTestResult(result);
}

/* ═══════════════════ TEST RESULT ═══════════════════ */
function renderTestResult(result) {
  const pct = Math.round((result.correct / result.total) * 100);
  const grade = pct>=90?'A+':pct>=80?'A':pct>=70?'B+':pct>=60?'B':pct>=50?'C':'F';
  const gradeColor = pct>=70?'var(--success)':pct>=50?'var(--amber)':'var(--red)';
  const msg = pct>=90?'Outstanding! You have mastered this topic.':pct>=75?'Excellent work! You are well-prepared.':pct>=60?'Good effort! Review the explanations below.':pct>=40?'Keep practising — you are getting there.':'Needs more study. Review the material and retry.';
  const mins = Math.floor(result.timeTaken / 60), secs = result.timeTaken % 60;
  
  // Score ring circumference calculation
  const radius = 68, circ = 2 * Math.PI * radius;
  const dashOffset = circ * (1 - pct/100);
  
  document.getElementById('testResultContent').innerHTML = `
    <div class="result-layout">
      <div style="text-align:center;margin-bottom:8px;">
        <div style="font-size:.65rem;letter-spacing:.18em;text-transform:uppercase;color:var(--muted);">${result.college} · ${result.subject}</div>
      </div>
      <div class="result-score-ring">
        <svg width="160" height="160" viewBox="0 0 160 160">
          <circle cx="80" cy="80" r="${radius}" fill="none" stroke="var(--border)" stroke-width="10"/>
          <circle cx="80" cy="80" r="${radius}" fill="none" stroke="${gradeColor}" stroke-width="10"
            stroke-dasharray="${circ}" stroke-dashoffset="${dashOffset}" stroke-linecap="round"
            style="transition:stroke-dashoffset 1.2s ease;"/>
        </svg>
        <div class="result-score-text">
          <div class="result-score-pct" style="color:${gradeColor}">${pct}%</div>
          <div class="result-score-label">${result.correct}/${result.total}</div>
        </div>
      </div>
      <div class="result-grade" style="color:${gradeColor}">Grade: ${grade}</div>
      <p class="result-message">${msg}</p>
      <div class="result-stats">
        <div class="result-stat"><span class="result-stat-num" style="color:var(--success)">${result.correct}</span><span class="result-stat-label">Correct</span></div>
        <div class="result-stat"><span class="result-stat-num" style="color:var(--red)">${result.incorrect}</span><span class="result-stat-label">Incorrect</span></div>
        <div class="result-stat"><span class="result-stat-num" style="color:var(--muted)">${result.skipped}</span><span class="result-stat-label">Skipped</span></div>
        <div class="result-stat"><span class="result-stat-num" style="color:var(--amber)">${mins}m ${secs}s</span><span class="result-stat-label">Time taken</span></div>
      </div>
      <div class="result-actions">
        <button class="btn-primary" onclick="startTest('${result.testId}')" style="font-size:.75rem;">🔁 Retake Test</button>
        <button class="btn-outline" onclick="navTo('tests')" style="font-size:.75rem;">← All Tests</button>
        <button class="btn-outline" onclick="navTo('classes')" style="font-size:.75rem;">🎬 Watch Classes</button>
      </div>
      
      <div class="result-review-title">📋 Review Your Answers</div>
      ${result.questions.map((q,i)=>{
        const userAns = result.answers[i];
        const isCorrect = userAns === q.ans;
        const wasSkipped = userAns === null;
        return `
          <div style="margin-bottom:20px;border:1px solid ${isCorrect?'rgba(45,122,58,.3)':wasSkipped?'var(--border)':'rgba(192,57,43,.3)'};padding:20px;background:${isCorrect?'rgba(45,122,58,.03)':wasSkipped?'var(--cream)':'rgba(192,57,43,.03)'};">
            <div style="font-size:.6rem;letter-spacing:.12em;text-transform:uppercase;color:var(--muted);margin-bottom:8px;">Question ${i+1} · ${isCorrect?'✅ Correct':wasSkipped?'⏭ Skipped':'❌ Incorrect'}</div>
            <div style="font-size:.88rem;font-weight:600;margin-bottom:14px;">${q.q}</div>
            <div style="display:flex;flex-direction:column;gap:6px;">
              ${q.opts.map((opt,oi)=>{
                let style = 'padding:8px 12px;font-size:.78rem;border:1px solid var(--border);';
                if (oi === q.ans) style += 'border-color:var(--success);background:rgba(45,122,58,.08);';
                else if (oi === userAns && !isCorrect) style += 'border-color:var(--red);background:rgba(192,57,43,.06);';
                return `<div style="${style}">${'ABCD'[oi]}. ${opt}${oi===q.ans?' ✅':''}${oi===userAns&&!isCorrect?' ❌':''}</div>`;
              }).join('')}
            </div>
            ${q.exp?`<div class="question-explanation">${q.exp}</div>`:''}
          </div>`;
      }).join('')}
    </div>`;
}