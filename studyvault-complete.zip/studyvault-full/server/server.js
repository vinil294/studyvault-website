// ═══════════════════════════════════════════════════════════
//  StudyVault — Backend Server
//  Stack: Node.js + Express + MongoDB (Mongoose) + bcrypt
// ═══════════════════════════════════════════════════════════

const express    = require("express");
const mongoose   = require("mongoose");
const cors       = require("cors");
const bcrypt     = require("bcrypt");
require("dotenv").config();

const app  = express();
const PORT = process.env.PORT || 5000;

// ── Middleware ──────────────────────────────────────────────
app.use(cors());
app.use(express.json());
app.use(express.static(__dirname + "/../")); // serve frontend from root

// ── Database ────────────────────────────────────────────────
mongoose
  .connect(process.env.MONGO_URI)
  .then(() => console.log("✅  MongoDB Connected"))
  .catch((err) => console.error("❌  MongoDB Error:", err));

// ═══════════════════════════════════════════════════════════
//  SCHEMAS & MODELS
// ═══════════════════════════════════════════════════════════

// ── User ────────────────────────────────────────────────────
const UserSchema = new mongoose.Schema(
  {
    firstName : { type: String, required: true },
    lastName  : { type: String, default: "" },
    email     : { type: String, required: true, unique: true, lowercase: true },
    password  : { type: String },           // null for social-login users
    phone     : { type: String, default: "" },
    college   : { type: String, default: "" },
    bio       : { type: String, default: "" },
    provider  : { type: String, default: "email" }, // email | google | github | etc.
    savedItems: [{ type: String }],         // array of resource IDs
  },
  { timestamps: true }
);

const User = mongoose.model("User", UserSchema);

// ── Resource ────────────────────────────────────────────────
const ResourceSchema = new mongoose.Schema(
  {
    title      : { type: String, required: true },
    subject    : { type: String, required: true },
    type       : { type: String, required: true }, // Lecture Notes | Past Exam | etc.
    college    : { type: String, required: true },
    semester   : { type: String, default: "" },
    description: { type: String, default: "" },
    tags       : [String],
    author     : { type: String, default: "Anonymous" },
    authorId   : { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    downloads  : { type: Number, default: 0 },
    fileUrl    : { type: String, default: "" },    // cloud storage URL
    featured   : { type: Boolean, default: false },
  },
  { timestamps: true }
);

const Resource = mongoose.model("Resource", ResourceSchema);

// ── Test Result ─────────────────────────────────────────────
const TestResultSchema = new mongoose.Schema(
  {
    userId  : { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    testId  : { type: String, required: true },
    college : String,
    subject : String,
    title   : String,
    score   : Number,   // correct answers
    total   : Number,   // total questions
    percent : Number,
    timeTaken: Number,  // seconds
    answers : [Number], // selected option indices
  },
  { timestamps: true }
);

const TestResult = mongoose.model("TestResult", TestResultSchema);


// ═══════════════════════════════════════════════════════════
//  HELPERS
// ═══════════════════════════════════════════════════════════

// Simple JWT-less auth: in production replace with jsonwebtoken
// For demo we just return the user object; frontend stores in sessionStorage
const authMiddleware = async (req, res, next) => {
  const userId = req.headers["x-user-id"];
  if (!userId) return res.status(401).json({ message: "Not authenticated" });
  try {
    req.user = await User.findById(userId).select("-password");
    if (!req.user) return res.status(401).json({ message: "User not found" });
    next();
  } catch {
    res.status(401).json({ message: "Invalid user ID" });
  }
};


// ═══════════════════════════════════════════════════════════
//  AUTH ROUTES
// ═══════════════════════════════════════════════════════════

// Health check
app.get("/api/test", (_req, res) => res.json({ message: "StudyVault API is running ✅" }));

// ── Sign Up ─────────────────────────────────────────────────
app.post("/api/signup", async (req, res) => {
  const { firstName, lastName, email, password } = req.body;

  if (!firstName || !email || !password)
    return res.status(400).json({ message: "firstName, email and password are required" });

  try {
    const existing = await User.findOne({ email: email.toLowerCase() });
    if (existing) return res.status(409).json({ message: "Email already registered" });

    const hashed = await bcrypt.hash(password, 10);
    const user   = await User.create({ firstName, lastName, email, password: hashed, provider: "email" });

    res.status(201).json({
      message : "User registered successfully",
      user    : { id: user._id, firstName: user.firstName, lastName: user.lastName, email: user.email },
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Error creating user" });
  }
});

// ── Log In ──────────────────────────────────────────────────
app.post("/api/login", async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password)
    return res.status(400).json({ message: "Email and password are required" });

  try {
    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user) return res.status(404).json({ message: "No account found with this email" });

    const match = await bcrypt.compare(password, user.password || "");
    if (!match) return res.status(401).json({ message: "Incorrect password" });

    res.json({
      message : "Login successful",
      user    : {
        id        : user._id,
        firstName : user.firstName,
        lastName  : user.lastName,
        email     : user.email,
        phone     : user.phone,
        college   : user.college,
        bio       : user.bio,
        provider  : user.provider,
        savedItems: user.savedItems,
      },
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Login error" });
  }
});

// ── Social Login (Google / GitHub / etc.) ───────────────────
app.post("/api/social-login", async (req, res) => {
  const { provider, email, firstName, lastName, phone } = req.body;

  if (!provider || !email)
    return res.status(400).json({ message: "Provider and email are required" });

  try {
    let user = await User.findOne({ email: email.toLowerCase() });

    if (!user) {
      user = await User.create({ firstName, lastName, email, provider, phone: phone || "" });
    }

    res.json({
      message : "Social login successful",
      user    : {
        id        : user._id,
        firstName : user.firstName,
        lastName  : user.lastName,
        email     : user.email,
        phone     : user.phone,
        college   : user.college,
        bio       : user.bio,
        provider  : user.provider,
        savedItems: user.savedItems,
      },
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Social login error" });
  }
});

// ── Update Profile ───────────────────────────────────────────
app.put("/api/profile", authMiddleware, async (req, res) => {
  const { firstName, lastName, college, bio, phone } = req.body;
  try {
    const updated = await User.findByIdAndUpdate(
      req.user._id,
      { firstName, lastName, college, bio, phone },
      { new: true, select: "-password" }
    );
    res.json({ message: "Profile updated", user: updated });
  } catch (err) {
    res.status(500).json({ message: "Update failed" });
  }
});


// ═══════════════════════════════════════════════════════════
//  RESOURCES ROUTES
// ═══════════════════════════════════════════════════════════

// ── Get all resources (with optional filters) ───────────────
app.get("/api/resources", async (req, res) => {
  const { college, subject, type, search, page = 1, limit = 50 } = req.query;
  const query = {};

  if (college) query.college = { $regex: college, $options: "i" };
  if (subject) query.subject = { $regex: subject, $options: "i" };
  if (type)    query.type    = type;
  if (search)  query.$or = [
    { title      : { $regex: search, $options: "i" } },
    { description: { $regex: search, $options: "i" } },
    { tags       : { $in: [new RegExp(search, "i")] } },
  ];

  try {
    const total     = await Resource.countDocuments(query);
    const resources = await Resource.find(query)
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(Number(limit));

    res.json({ total, page: Number(page), resources });
  } catch (err) {
    res.status(500).json({ message: "Error fetching resources" });
  }
});

// ── Get single resource ──────────────────────────────────────
app.get("/api/resources/:id", async (req, res) => {
  try {
    const r = await Resource.findById(req.params.id);
    if (!r) return res.status(404).json({ message: "Resource not found" });
    res.json(r);
  } catch {
    res.status(500).json({ message: "Error fetching resource" });
  }
});

// ── Upload resource (auth required) ─────────────────────────
app.post("/api/resources", authMiddleware, async (req, res) => {
  const { title, subject, type, college, semester, description, tags, fileUrl } = req.body;

  if (!title || !subject || !type || !college)
    return res.status(400).json({ message: "title, subject, type and college are required" });

  try {
    const resource = await Resource.create({
      title, subject, type, college, semester, description,
      tags    : tags || [],
      author  : `${req.user.firstName} ${req.user.lastName}`.trim(),
      authorId: req.user._id,
      fileUrl : fileUrl || "",
    });
    res.status(201).json({ message: "Resource uploaded", resource });
  } catch (err) {
    res.status(500).json({ message: "Upload failed" });
  }
});

// ── Delete resource (author or admin) ───────────────────────
app.delete("/api/resources/:id", authMiddleware, async (req, res) => {
  try {
    const r = await Resource.findById(req.params.id);
    if (!r) return res.status(404).json({ message: "Not found" });
    if (String(r.authorId) !== String(req.user._id))
      return res.status(403).json({ message: "Not authorised" });
    await r.deleteOne();
    res.json({ message: "Resource deleted" });
  } catch {
    res.status(500).json({ message: "Delete failed" });
  }
});

// ── Increment download count ─────────────────────────────────
app.post("/api/resources/:id/download", async (req, res) => {
  try {
    await Resource.findByIdAndUpdate(req.params.id, { $inc: { downloads: 1 } });
    res.json({ message: "Download counted" });
  } catch {
    res.status(500).json({ message: "Error" });
  }
});


// ═══════════════════════════════════════════════════════════
//  SAVED ITEMS ROUTES
// ═══════════════════════════════════════════════════════════

// ── Toggle save/unsave ───────────────────────────────────────
app.post("/api/saved/:resourceId", authMiddleware, async (req, res) => {
  const { resourceId } = req.params;
  const user = req.user;

  const isSaved = user.savedItems.includes(resourceId);
  const update  = isSaved
    ? { $pull : { savedItems: resourceId } }
    : { $addToSet: { savedItems: resourceId } };

  try {
    const updated = await User.findByIdAndUpdate(user._id, update, { new: true }).select("savedItems");
    res.json({ saved: !isSaved, savedItems: updated.savedItems });
  } catch {
    res.status(500).json({ message: "Error updating saved items" });
  }
});

// ── Get saved resources ──────────────────────────────────────
app.get("/api/saved", authMiddleware, async (req, res) => {
  try {
    const user      = await User.findById(req.user._id).select("savedItems");
    const resources = await Resource.find({ _id: { $in: user.savedItems } });
    res.json({ resources });
  } catch {
    res.status(500).json({ message: "Error fetching saved items" });
  }
});


// ═══════════════════════════════════════════════════════════
//  TEST RESULTS ROUTES
// ═══════════════════════════════════════════════════════════

// ── Save test result ─────────────────────────────────────────
app.post("/api/test-results", authMiddleware, async (req, res) => {
  const { testId, college, subject, title, score, total, timeTaken, answers } = req.body;
  try {
    const percent = Math.round((score / total) * 100);
    const result  = await TestResult.create({
      userId: req.user._id, testId, college, subject, title,
      score, total, percent, timeTaken, answers,
    });
    res.status(201).json({ message: "Result saved", result });
  } catch {
    res.status(500).json({ message: "Error saving result" });
  }
});

// ── Get my test results ──────────────────────────────────────
app.get("/api/test-results", authMiddleware, async (req, res) => {
  try {
    const results = await TestResult
      .find({ userId: req.user._id })
      .sort({ createdAt: -1 });
    res.json({ results });
  } catch {
    res.status(500).json({ message: "Error fetching results" });
  }
});

// ── Get best score for a specific test ──────────────────────
app.get("/api/test-results/:testId/best", authMiddleware, async (req, res) => {
  try {
    const best = await TestResult
      .findOne({ userId: req.user._id, testId: req.params.testId })
      .sort({ percent: -1 });
    res.json({ best: best ? best.percent : null });
  } catch {
    res.status(500).json({ message: "Error" });
  }
});


// ═══════════════════════════════════════════════════════════
//  ADMIN ROUTES
// ═══════════════════════════════════════════════════════════

// ── Platform stats ───────────────────────────────────────────
app.get("/api/admin/stats", async (_req, res) => {
  try {
    const [totalResources, totalUsers, downloadsAgg] = await Promise.all([
      Resource.countDocuments(),
      User.countDocuments(),
      Resource.aggregate([{ $group: { _id: null, total: { $sum: "$downloads" } } }]),
    ]);
    const totalDownloads = downloadsAgg[0]?.total || 0;
    res.json({ totalResources, totalUsers, totalDownloads });
  } catch {
    res.status(500).json({ message: "Stats error" });
  }
});

// ── List all users (admin) ───────────────────────────────────
app.get("/api/admin/users", async (_req, res) => {
  try {
    const users = await User.find().select("-password").sort({ createdAt: -1 });
    res.json({ users });
  } catch {
    res.status(500).json({ message: "Error fetching users" });
  }
});


// ═══════════════════════════════════════════════════════════
//  SPA FALLBACK — serve index.html for all non-API routes
// ═══════════════════════════════════════════════════════════
app.get("*", (_req, res) => {
  res.sendFile(require("path").join(__dirname, "../index.html"));
});


// ── Start ────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`🚀  StudyVault server running at http://localhost:${PORT}`);
});
